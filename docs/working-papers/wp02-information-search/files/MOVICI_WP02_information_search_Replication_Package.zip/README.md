# MOVICI Article 1 reproducibility package

## Article

**Prior Knowledge and Learning from Open Web Search**

Preprint not peer reviewed.

This package reproduces the article analyses from a minimized, article-specific dataset.

## Data scope and privacy

`data/MOVICI_Article1_Analysis_Data.csv` contains 96 pseudonymized participants and 34 pseudonymized experimental-session clusters. It is not the complete MOVICI database.

The package contains only the variables required for the reported analyses. Exact dates and time slots, workstation identifiers, raw demographic variables, internal group identifiers, debate and dyadic variables, raw URLs, and free-text data are omitted. Public identifiers have no mapping to the internal identifiers.

Participant-level T3 data are omitted because Article 1 analyses T1 and T2. The aggregate T2-to-T3 sensitivity result reported in the manuscript is documented in `documentation/MOVICI_Article1_T3_Sensitivity_Summary.csv`.

## Contents

- `MOVICI_Article1_OSF.Rproj`: RStudio project.
- `MOVICI_Article1_Analysis.R`: analysis script.
- `data/MOVICI_Article1_Analysis_Data.csv`: minimized analytic dataset.
- `documentation/MOVICI_Article1_Data_Dictionary.xlsx`: public-variable dictionary.
- `documentation/MOVICI_Article1_T3_Sensitivity_Summary.csv`: aggregate sensitivity result.
- `materials/MOVICI_Article1_Measures_and_Items.xlsx`: measures and scoring notes.
- `results/MOVICI_Article1_Final_Results.xlsx`: deposited result workbook.
- `results/README.txt`: output instructions.
- `SHA256SUMS.txt`: integrity hashes.
- `LICENSE_DATA_CC_BY_4.0.txt`: data and documentation license.
- `LICENSE_CODE_MIT.txt`: code license.

## Reproduction

1. Open `MOVICI_Article1_OSF.Rproj` in RStudio.
2. Open `MOVICI_Article1_Analysis.R`.
3. Keep `RUN_MODE <- "FINAL"` for the deposited results. This mode uses 20,000 session-cluster bootstrap resamples for the exploratory P5 indirect statistical path.
4. Source the full script.

The script writes `results/MOVICI_Article1_Final_Results.xlsx` and `results/sessionInfo.txt`. `RUN_MODE <- "CHECK"` uses 500 resamples for installation and code verification only.

The script requires `clubSandwich` and `openxlsx`.

## Interpretation notes

- Search traces are behavioral indicators, not direct measures of internal cognitive processes.
- T1-to-T2 change spans Web search, active recall, and source evaluation.
- The indirect path is exploratory and does not establish causal mediation.
- The study was not preregistered.

## Licenses

Data and documentation: CC BY 4.0. R code: MIT License.
