# ==============================================================================
# MOVICI — ARTICLE 1
# Reproducible analysis pipeline for P1–P6 and documented T2-to-T3 sensitivity check
# ==============================================================================
# Public data source: data/MOVICI_Article1_Analysis_Data.csv
# Unit of analysis: participant (N = 96)
# Cluster for robust inference: pseudonymized experimental session (34 sessions)
# Inference: OLS + CR2 cluster-robust SEs, Satterthwaite df, HTZ block tests
# Multiplicity: Benjamini-Hochberg correction within prespecified functional families
# One targeted exploratory cluster bootstrap is used for the P5 indirect statistical path.
#
# IMPORTANT
# The public dataset is article-specific and derived from the controlled internal
# canonical MOVICI archive. Historical metric-specific exclusions used in an older
# pipeline are NOT applied here. Navigation and time measures come from the corrected
# canonical reconstruction and all 96 participants are retained whenever data are defined.
# ==============================================================================

rm(list = ls())
options(stringsAsFactors = FALSE, scipen = 999)
set.seed(20260824)
SCRIPT_VERSION <- "OSF_PREPRINT_FINAL_2026-08-26_v3"

# Run mode ---------------------------------------------------------------
# FINAL reproduces the article-ready analysis, including the 20,000-resample
# session-cluster bootstrap. CHECK runs the same pipeline with 500 bootstrap
# resamples to verify installation, data import, QC and all model code quickly.
# For manuscript/OSF numbers, keep RUN_MODE = "FINAL".
RUN_MODE <- "FINAL"   # allowed values: "FINAL", "CHECK"
if (!RUN_MODE %in% c("FINAL", "CHECK")) stop("RUN_MODE must be 'FINAL' or 'CHECK'.")
P5_INDIRECT_REPS <- if (RUN_MODE == "FINAL") 20000L else 500L
P5_INDIRECT_SEED <- 20260824L

# ------------------------------------------------------------------------------
# 1. Dependencies and paths
# ------------------------------------------------------------------------------
required_packages <- c("clubSandwich", "openxlsx")
options(repos = c(CRAN = "https://cloud.r-project.org"))
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]
if (length(missing_packages) > 0L) install.packages(missing_packages)
invisible(lapply(required_packages, library, character.only = TRUE))

PROJECT_ROOT <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
DATA_FILE <- file.path(PROJECT_ROOT, "data", "MOVICI_Article1_Analysis_Data.csv")
OUT_DIR <- file.path(PROJECT_ROOT, "results")
dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)
RESULTS_FILE <- file.path(OUT_DIR, "MOVICI_Article1_Final_Results.xlsx")
SESSION_FILE <- file.path(OUT_DIR, "sessionInfo.txt")
T3_SUMMARY_FILE <- file.path(PROJECT_ROOT, "documentation", "MOVICI_Article1_T3_Sensitivity_Summary.csv")

if (!file.exists(DATA_FILE)) {
  stop("Data file not found: ", DATA_FILE,
       "\nOpen MOVICI_Article1_OSF.Rproj before sourcing this script.")
}

cat("\nMOVICI Article 1 — reproducible analysis P1–P6\n")
cat("Reading the article-specific public dataset...\n")

# T3 follows the debate and is outside the minimized participant-level Article 1 table.
# The preprint uses it only as an aggregate internal sensitivity check.
if (!file.exists(T3_SUMMARY_FILE)) stop("T3 sensitivity summary not found: ", T3_SUMMARY_FILE)
T3_Sensitivity <- read.csv(T3_SUMMARY_FILE, check.names = FALSE, stringsAsFactors = FALSE)

# ------------------------------------------------------------------------------
# 2. Helper functions
# ------------------------------------------------------------------------------
num <- function(x) suppressWarnings(as.numeric(x))

z <- function(x) {
  x <- as.numeric(x)
  m <- mean(x, na.rm = TRUE)
  s <- sd(x, na.rm = TRUE)
  if (!is.finite(s) || s == 0) return(rep(NA_real_, length(x)))
  (x - m) / s
}

transform_metric <- function(x, transform = "identity") {
  if (transform == "identity") return(as.numeric(x))
  if (transform == "log1p") return(log1p(as.numeric(x)))
  stop("Unknown transformation: ", transform)
}

add_terms <- function(x, model) {
  x <- as.data.frame(x, check.names = FALSE)
  if ("Coef." %in% names(x)) names(x)[names(x) == "Coef."] <- "term"
  if ("Coef" %in% names(x)) names(x)[names(x) == "Coef"] <- "term"
  if (!"term" %in% names(x)) {
    x <- data.frame(term = names(coef(model)), x, check.names = FALSE, row.names = NULL)
  }
  x
}

cr2_analysis <- function(model, data, label) {
  V <- clubSandwich::vcovCR(model, cluster = data$session_id, type = "CR2")
  tests <- add_terms(clubSandwich::coef_test(model, vcov = V, test = "Satterthwaite"), model)
  if (all(c("beta", "SE", "df_Satt") %in% names(tests))) {
    crit <- qt(0.975, df = tests$df_Satt)
    tests$CI_low <- tests$beta - crit * tests$SE
    tests$CI_high <- tests$beta + crit * tests$SE
  } else {
    tests$CI_low <- NA_real_
    tests$CI_high <- NA_real_
  }
  tests$model <- label
  list(V = V, tests = tests)
}

extract_term <- function(cr2_obj, term) {
  cr2_obj$tests[cr2_obj$tests$term == term, , drop = FALSE]
}

block_test <- function(model, V, terms, label) {
  constraints <- clubSandwich::constrain_zero(constraints = terms, coefs = coef(model))
  ans <- as.data.frame(clubSandwich::Wald_test(
    model, constraints = constraints, vcov = V, test = "HTZ", tidy = TRUE
  ))
  ans$analysis <- label
  ans$terms_tested <- paste(terms, collapse = " + ")
  ans
}

model_fit <- function(model, label) {
  s <- summary(model)
  data.frame(
    analysis = label,
    N = nobs(model),
    R2 = s$r.squared,
    adjusted_R2 = s$adj.r.squared,
    AIC = AIC(model),
    BIC = BIC(model),
    stringsAsFactors = FALSE
  )
}

pearson_row <- function(x, y, label) {
  ok <- complete.cases(x, y)
  tt <- cor.test(x[ok], y[ok], method = "pearson")
  data.frame(
    analysis = label,
    N = sum(ok),
    r = unname(tt$estimate),
    p = tt$p.value,
    stringsAsFactors = FALSE
  )
}

describe_variable <- function(x, variable, level) {
  x <- as.numeric(x)
  ok <- is.finite(x)
  data.frame(
    analysis = paste0("Descriptive: ", variable),
    variable = variable,
    conceptual_level = level,
    N = sum(ok),
    missing = sum(!ok),
    mean = mean(x[ok]),
    SD = sd(x[ok]),
    median = median(x[ok]),
    Q1 = unname(quantile(x[ok], .25)),
    Q3 = unname(quantile(x[ok], .75)),
    min = min(x[ok]),
    max = max(x[ok]),
    stringsAsFactors = FALSE
  )
}

key_term <- function(obj, term, analysis, status = "") {
  x <- extract_term(obj, term)
  x$analysis <- analysis
  x$status <- status
  x
}

bind_fill <- function(...) {
  dfs <- list(...)
  dfs <- dfs[vapply(dfs, function(x) !is.null(x) && nrow(as.data.frame(x)) > 0L, logical(1))]
  if (!length(dfs)) return(data.frame())
  dfs <- lapply(dfs, function(x) as.data.frame(x, check.names = FALSE, stringsAsFactors = FALSE))
  all_names <- unique(unlist(lapply(dfs, names), use.names = FALSE))
  dfs <- lapply(dfs, function(d) {
    miss <- setdiff(all_names, names(d))
    for (m in miss) d[[m]] <- NA
    d[, all_names, drop = FALSE]
  })
  rownames_df <- do.call(rbind, dfs)
  rownames(rownames_df) <- NULL
  rownames_df
}

write_workbook <- function(path, sheets) {
  wb <- openxlsx::createWorkbook()
  header <- openxlsx::createStyle(
    fontColour = "#FFFFFF", fgFill = "#1F4E78", textDecoration = "bold",
    halign = "center", valign = "center", wrapText = TRUE
  )
  wrap <- openxlsx::createStyle(wrapText = TRUE, valign = "top")
  num_style <- openxlsx::createStyle(numFmt = "0.000")
  p_style <- openxlsx::createStyle(numFmt = "0.0000")

  for (nm in names(sheets)) {
    df <- as.data.frame(sheets[[nm]], check.names = FALSE, stringsAsFactors = FALSE)
    sh <- substr(nm, 1, 31)
    openxlsx::addWorksheet(wb, sh, gridLines = FALSE)
    if (ncol(df) == 0L) {
      openxlsx::writeData(wb, sh, "No output")
      next
    }
    if (nrow(df) == 0L) {
      openxlsx::writeData(wb, sh, as.list(names(df)), colNames = FALSE)
    } else {
      openxlsx::writeDataTable(wb, sh, df, tableStyle = "TableStyleMedium2", withFilter = TRUE)
    }
    openxlsx::addStyle(wb, sh, header, rows = 1, cols = seq_len(ncol(df)), gridExpand = TRUE)
    if (nrow(df) > 0L) {
      openxlsx::addStyle(wb, sh, wrap, rows = 2:(nrow(df) + 1L), cols = seq_len(ncol(df)), gridExpand = TRUE, stack = TRUE)
      numeric_cols <- which(vapply(df, is.numeric, logical(1)))
      p_cols <- grep("(^p$|^q$|p_|p\\.|p_Satt|q_BH|CI95)", names(df), ignore.case = TRUE)
      if (length(numeric_cols)) {
        openxlsx::addStyle(wb, sh, num_style, rows = 2:(nrow(df)+1L), cols = numeric_cols, gridExpand = TRUE, stack = TRUE)
      }
      if (length(p_cols)) {
        openxlsx::addStyle(wb, sh, p_style, rows = 2:(nrow(df)+1L), cols = p_cols, gridExpand = TRUE, stack = TRUE)
      }
    }
    openxlsx::freezePane(wb, sh, firstActiveRow = 2)
    widths <- vapply(seq_len(ncol(df)), function(j) {
      vals <- c(names(df)[j], as.character(df[[j]]))
      vals <- vals[!is.na(vals)]
      mx <- if (length(vals)) max(nchar(vals)) else 10
      max(10, min(36, mx + 2))
    }, numeric(1))
    openxlsx::setColWidths(wb, sh, seq_len(ncol(df)), widths)
  }
  openxlsx::saveWorkbook(wb, path, overwrite = TRUE)
}

# ------------------------------------------------------------------------------
# 3. Import, derived variables and automatic QC
# ------------------------------------------------------------------------------
raw <- read.csv(DATA_FILE, check.names = FALSE, na.strings = c("", "NA"), fileEncoding = "UTF-8")

required <- c(
  "participant_id", "session_id", "condition", "knowledge_t1", "knowledge_t2", "family_ses",
  "crt2", "intellectual_humility", "epistemic_beliefs",
  "search_learning_habit", "search_verification_habit",
  "subjective_knowledge_t1", "subjective_knowledge_t2",
  "ri_action_count", "ri_exploitation_actions", "ri_visit_count", "ri_dta_seconds", "ri_scientific_actions",
  "nav_new_serps", "nav_new_documents", "nav_new_urls", "nav_exploration_ratio", "nav_exploitation_ratio",
  "time_serp_seconds", "time_document_seconds", "time_total_seconds", "time_exploration_ratio", "time_exploitation_ratio",
  "serp_revisits", "document_revisits", "mean_serp_time_seconds", "mean_document_time_seconds",
  "query_count", "thematic_exploration_count", "thematic_exploitation_count", "thematic_reexploitation_count",
  "thematic_exploration_prop", "thematic_exploitation_prop", "thematic_reexploitation_prop",
  "thematic_exploitation_reexploitation_count", "thematic_exploration_ratio", "thematic_exploitation_ratio",
  "sources_recalled", "sources_encountered",
  "ve_exp_item1_sum", "ve_exp_item2_sum", "ve_exp_item3_sum", "ve_exp_item4_reverse_sum", "ve_exp_item5_sum",
  "ve_ben_item1_sum", "ve_ben_item2_reverse_sum", "ve_ben_item3_reverse_sum", "ve_ben_item4_sum", "ve_ben_item5_sum"
)
missing_columns <- setdiff(required, names(raw))
if (length(missing_columns) > 0L) stop("Missing required columns: ", paste(missing_columns, collapse = ", "))
if (nrow(raw) != 96L) stop("Expected N = 96; found N = ", nrow(raw))
if (anyDuplicated(raw$participant_id)) stop("Duplicate participant_id values detected.")

D <- raw
D$condition <- factor(D$condition, levels = c("Competition", "Cooperation"))
D$session_id <- factor(D$session_id)

numeric_variables <- setdiff(required, c("participant_id", "session_id", "condition"))
for (v in numeric_variables) D[[v]] <- num(D[[v]])

D$knowledge_gain <- D$knowledge_t2 - D$knowledge_t1
D$subjective_change <- D$subjective_knowledge_t2 - D$subjective_knowledge_t1
D$recall_proportion <- ifelse(D$sources_encountered > 0,
                              D$sources_recalled / D$sources_encountered, NA_real_)
D$scientific_action_share <- ifelse(D$ri_action_count > 0,
                                    D$ri_scientific_actions / D$ri_action_count, NA_real_)

D$ve_expertise <- ifelse(
  D$sources_recalled > 0,
  (D$ve_exp_item1_sum + D$ve_exp_item2_sum + D$ve_exp_item3_sum -
     D$ve_exp_item4_reverse_sum + D$ve_exp_item5_sum) / D$sources_recalled,
  NA_real_
)
D$ve_benevolence <- ifelse(
  D$sources_recalled > 0,
  (D$ve_ben_item1_sum - D$ve_ben_item2_reverse_sum - D$ve_ben_item3_reverse_sum +
     D$ve_ben_item4_sum + D$ve_ben_item5_sum) / D$sources_recalled,
  NA_real_
)
D$ve_composite <- rowMeans(cbind(z(D$ve_expertise), z(D$ve_benevolence)), na.rm = FALSE)

max_abs <- function(x) {
  x <- abs(as.numeric(x))
  x <- x[is.finite(x)]
  if (!length(x)) return(NA_real_)
  max(x)
}

qc <- data.frame(
  check = c(
    "Participants",
    "Unique public participant IDs",
    "Session clusters",
    "Family SES available",
    "VE composite available",
    "Knowledge T1 in 0-20",
    "Knowledge T2 in 0-20",
    "New URL identity",
    "Navigation ratios complementary",
    "Total time identity",
    "Time ratios complementary",
    "DTA identity: total time / actions",
    "Thematic query-count identity",
    "Thematic exploitation+re-exploitation count identity",
    "Thematic proportions sum to one",
    "Thematic E/E ratios complementary",
    "Recalled sources never exceed encountered sources"
  ),
  observed = c(
    nrow(D),
    length(unique(D$participant_id)),
    nlevels(D$session_id),
    sum(is.finite(D$family_ses)),
    sum(is.finite(D$ve_composite)),
    paste(range(D$knowledge_t1, na.rm = TRUE), collapse = " to "),
    paste(range(D$knowledge_t2, na.rm = TRUE), collapse = " to "),
    max_abs(D$nav_new_urls - (D$nav_new_serps + D$nav_new_documents)),
    max_abs((D$nav_exploration_ratio + D$nav_exploitation_ratio) - 1),
    max_abs(D$time_total_seconds - (D$time_serp_seconds + D$time_document_seconds)),
    max_abs((D$time_exploration_ratio + D$time_exploitation_ratio) - 1),
    max_abs(D$ri_dta_seconds - D$time_total_seconds / D$ri_action_count),
    max_abs(D$query_count - (D$thematic_exploration_count + D$thematic_exploitation_count + D$thematic_reexploitation_count)),
    max_abs(D$thematic_exploitation_reexploitation_count - (D$thematic_exploitation_count + D$thematic_reexploitation_count)),
    max_abs((D$thematic_exploration_prop + D$thematic_exploitation_prop + D$thematic_reexploitation_prop) - 1),
    max_abs((D$thematic_exploration_ratio + D$thematic_exploitation_ratio) - 1),
    max(D$sources_recalled - D$sources_encountered, na.rm = TRUE)
  ),
  expected = c(
    "96", "96", "34", "95", "92", "within 0-20", "within 0-20",
    "max error < 1e-10", "max error < 1e-10", "max error < 1e-10",
    "max error < 1e-10", "max error < 1e-10", "max error < 1e-10",
    "max error < 1e-10", "max error < 1e-10", "max error < 1e-10", "<= 0"
  ),
  PASS = c(
    nrow(D) == 96,
    length(unique(D$participant_id)) == 96,
    nlevels(D$session_id) == 34,
    sum(is.finite(D$family_ses)) == 95,
    sum(is.finite(D$ve_composite)) == 92,
    all(D$knowledge_t1 >= 0 & D$knowledge_t1 <= 20, na.rm = TRUE),
    all(D$knowledge_t2 >= 0 & D$knowledge_t2 <= 20, na.rm = TRUE),
    max_abs(D$nav_new_urls - (D$nav_new_serps + D$nav_new_documents)) < 1e-10,
    max_abs((D$nav_exploration_ratio + D$nav_exploitation_ratio) - 1) < 1e-10,
    max_abs(D$time_total_seconds - (D$time_serp_seconds + D$time_document_seconds)) < 1e-10,
    max_abs((D$time_exploration_ratio + D$time_exploitation_ratio) - 1) < 1e-10,
    max_abs(D$ri_dta_seconds - D$time_total_seconds / D$ri_action_count) < 1e-10,
    max_abs(D$query_count - (D$thematic_exploration_count + D$thematic_exploitation_count + D$thematic_reexploitation_count)) < 1e-10,
    max_abs(D$thematic_exploitation_reexploitation_count - (D$thematic_exploitation_count + D$thematic_reexploitation_count)) < 1e-10,
    max_abs((D$thematic_exploration_prop + D$thematic_exploitation_prop + D$thematic_reexploitation_prop) - 1) < 1e-10,
    max_abs((D$thematic_exploration_ratio + D$thematic_exploitation_ratio) - 1) < 1e-10,
    all(D$sources_recalled <= D$sources_encountered, na.rm = TRUE)
  ),
  stringsAsFactors = FALSE
)
if (!all(qc$PASS)) {
  print(qc)
  stop("Automatic QC failed. No final results were written.")
}

cat("QC passed: N = 96, 34 session clusters, corrected canonical RI metrics.\n")

# ------------------------------------------------------------------------------
# 4. P1 — learning, convergence and prior knowledge
# ------------------------------------------------------------------------------
cat("P1...\n")
paired <- D[complete.cases(D[, c("knowledge_t1", "knowledge_t2", "session_id")]), ]
paired$session_id <- droplevels(paired$session_id)

tt <- t.test(paired$knowledge_t2, paired$knowledge_t1, paired = TRUE)
ww <- suppressWarnings(wilcox.test(paired$knowledge_t2, paired$knowledge_t1, paired = TRUE, exact = FALSE))
dz <- mean(paired$knowledge_gain) / sd(paired$knowledge_gain)
var_ratio <- var(paired$knowledge_t2) / var(paired$knowledge_t1)
r_pm <- cor(paired$knowledge_t1 + paired$knowledge_t2, paired$knowledge_t1 - paired$knowledge_t2)
t_pm <- r_pm * sqrt((nrow(paired) - 2) / (1 - r_pm^2))
p_pm <- 2 * pt(abs(t_pm), df = nrow(paired) - 2, lower.tail = FALSE)

M_gain <- lm(knowledge_gain ~ 1, data = paired)
C_gain <- cr2_analysis(M_gain, paired, "P1 mean gain")

D_p1 <- D[complete.cases(D[, c("knowledge_t2", "knowledge_t1", "family_ses", "condition", "session_id")]), ]
D_p1$session_id <- droplevels(D_p1$session_id)
D_p1$z_t1 <- z(D_p1$knowledge_t1)
D_p1$z_ses <- z(D_p1$family_ses)
M_p1 <- lm(knowledge_t2 ~ z_t1 + z_ses + condition, data = D_p1)
C_p1 <- cr2_analysis(M_p1, D_p1, "P1 T2 ~ T1 + SES + condition")

P1_summary <- data.frame(
  analysis = "T1-to-T2 descriptive change and convergence",
  N = nrow(paired),
  mean_T1 = mean(paired$knowledge_t1),
  SD_T1 = sd(paired$knowledge_t1),
  mean_T2 = mean(paired$knowledge_t2),
  SD_T2 = sd(paired$knowledge_t2),
  mean_gain = mean(paired$knowledge_gain),
  SD_gain = sd(paired$knowledge_gain),
  paired_t = unname(tt$statistic),
  paired_t_df = unname(tt$parameter),
  paired_t_p = tt$p.value,
  dz = dz,
  Wilcoxon_V = unname(ww$statistic),
  Wilcoxon_p = ww$p.value,
  variance_ratio_T2_T1 = var_ratio,
  variance_reduction_percent = 100 * (1 - var_ratio),
  Pitman_Morgan_t = t_pm,
  Pitman_Morgan_p = p_pm,
  stringsAsFactors = FALSE
)
P1_terms <- bind_fill(
  key_term(C_gain, "(Intercept)", "CR2 mean gain", "main; a priori; theory-driven"),
  key_term(C_p1, "z_t1", "Adjusted prior knowledge -> T2", "main; a priori; theory-driven"),
  key_term(C_p1, "z_ses", "Adjusted SES -> T2", "secondary; theory-driven"),
  key_term(C_p1, "conditionCooperation", "Adjusted COOP/COMP -> T2", "a priori manipulation")
)
P1 <- bind_fill(P1_summary, P1_terms, model_fit(M_p1, "Adjusted T2 model"))

# ------------------------------------------------------------------------------
# 5. P2 — exploration/exploitation at three levels
# ------------------------------------------------------------------------------
cat("P2...\n")
nav_vars <- c("nav_new_serps", "nav_new_documents", "nav_new_urls", "nav_exploration_ratio", "nav_exploitation_ratio")
time_vars <- c("time_serp_seconds", "time_document_seconds", "time_total_seconds", "time_exploration_ratio", "time_exploitation_ratio")
theme_vars <- c("query_count", "thematic_exploration_count", "thematic_exploitation_count", "thematic_reexploitation_count",
                "thematic_exploration_prop", "thematic_exploitation_prop", "thematic_reexploitation_prop",
                "thematic_exploration_ratio", "thematic_exploitation_ratio")
revisit_vars <- c("serp_revisits", "document_revisits", "mean_serp_time_seconds", "mean_document_time_seconds")

P2_desc <- bind_fill(
  do.call(rbind, lapply(nav_vars, function(v) describe_variable(D[[v]], v, "navigation"))),
  do.call(rbind, lapply(time_vars, function(v) describe_variable(D[[v]], v, "time"))),
  do.call(rbind, lapply(theme_vars, function(v) describe_variable(D[[v]], v, "thematic query coding"))),
  do.call(rbind, lapply(revisit_vars, function(v) describe_variable(D[[v]], v, "revisit/intensity")))
)

p2b_specs <- data.frame(
  variable = c("nav_exploration_ratio", "time_exploration_ratio", "thematic_exploration_ratio"),
  level = c("navigation", "time", "thematic"),
  stringsAsFactors = FALSE
)
p2b_rows <- list()
for (i in seq_len(nrow(p2b_specs))) {
  v <- p2b_specs$variable[i]
  d <- D[complete.cases(D[, c(v, "knowledge_t1", "session_id")]), ]
  d$session_id <- droplevels(d$session_id)
  d$z_t1 <- z(d$knowledge_t1)
  d$z_ri <- z(d[[v]])
  m <- lm(z_ri ~ z_t1, data = d)
  c2 <- cr2_analysis(m, d, paste0("P2b ", v, " ~ T1"))
  row <- extract_term(c2, "z_t1")
  row$analysis <- paste0("P2b T1 -> ", v)
  row$variable <- v
  row$conceptual_level <- p2b_specs$level[i]
  row$N <- nrow(d)
  row$clusters <- nlevels(d$session_id)
  p2b_rows[[i]] <- row
}
P2b <- do.call(rbind, p2b_rows)
P2b$q_BH <- p.adjust(P2b$p_Satt, method = "BH")
P2b$multiplicity_family <- "P2b_global_EE_ratios"
P2b$status <- "theory-driven operationalisation"

p2c_specs <- data.frame(
  model_id = c("NAV_RATIO", "TIME_RATIO", "THEME_RATIO", "DTA", "NEW_URLS", "TOTAL_TIME", "REQUESTS", "DOC_REVISITS"),
  variable = c("nav_exploration_ratio", "time_exploration_ratio", "thematic_exploration_ratio", "ri_dta_seconds",
               "nav_new_urls", "time_total_seconds", "query_count", "document_revisits"),
  transform = c("identity", "identity", "identity", "identity", "log1p", "log1p", "log1p", "log1p"),
  family = c(rep("P2c_theory_guided_EE_ratios", 3), rep("P2c_exploratory_specific_indicators", 5)),
  status = c(rep("theory-driven operationalisation", 3), rep("exploratory", 5)),
  stringsAsFactors = FALSE
)
p2c_rows <- list()
p2_simple <- list()
kk <- 1L
for (i in seq_len(nrow(p2c_specs))) {
  spec <- p2c_specs[i, ]
  d <- D[complete.cases(D[, c("knowledge_t2", "knowledge_t1", "family_ses", "condition", "session_id", spec$variable)]), ]
  d$session_id <- droplevels(d$session_id)
  d$z_t1 <- z(d$knowledge_t1)
  d$z_ses <- z(d$family_ses)
  d$z_ri <- z(transform_metric(d[[spec$variable]], spec$transform))
  base <- lm(knowledge_t2 ~ z_t1 + z_ses + condition, data = d)
  m <- lm(knowledge_t2 ~ z_t1 + z_ses + condition + z_ri + z_t1:z_ri, data = d)
  c2 <- cr2_analysis(m, d, paste0("P2c ", spec$model_id))
  row <- extract_term(c2, "z_t1:z_ri")
  row$analysis <- paste0("P2c T1 x ", spec$variable, " -> T2")
  row$model_id <- spec$model_id
  row$variable <- spec$variable
  row$transform <- spec$transform
  row$multiplicity_family <- spec$family
  row$status <- spec$status
  row$N <- nrow(d)
  row$clusters <- nlevels(d$session_id)
  row$delta_R2 <- summary(m)$r.squared - summary(base)$r.squared
  p2c_rows[[i]] <- row

  if (spec$model_id %in% c("DTA", "REQUESTS")) {
    for (lev in c(-1, 0, 1)) {
      d$t1_centered <- d$z_t1 - lev
      ms <- lm(knowledge_t2 ~ t1_centered + z_ses + condition + z_ri + t1_centered:z_ri, data = d)
      cs <- cr2_analysis(ms, d, paste0(spec$model_id, " simple slope at T1 = ", lev, " SD"))
      sr <- extract_term(cs, "z_ri")
      sr$analysis <- paste0("Simple slope: ", spec$model_id, " at T1 = ", lev, " SD")
      sr$model_id <- spec$model_id
      sr$T1_level_SD <- lev
      sr$N <- nrow(d)
      p2_simple[[kk]] <- sr
      kk <- kk + 1L
    }
  }
}
P2c <- do.call(rbind, p2c_rows)
P2c$q_BH <- NA_real_
for (fam in unique(P2c$multiplicity_family)) {
  idx <- which(P2c$multiplicity_family == fam)
  P2c$q_BH[idx] <- p.adjust(P2c$p_Satt[idx], method = "BH")
}
P2_simple <- if (length(p2_simple)) do.call(rbind, p2_simple) else data.frame()
P2 <- bind_fill(P2_desc, P2b, P2c, P2_simple)

# ------------------------------------------------------------------------------
# 6. P3 — exposure, retention and T2 knowledge
# ------------------------------------------------------------------------------
cat("P3...\n")
D_p3 <- D[complete.cases(D[, c("sources_recalled", "sources_encountered", "knowledge_t1", "family_ses", "condition", "session_id")]), ]
D_p3$session_id <- droplevels(D_p3$session_id)
D_p3$z_encountered <- z(D_p3$sources_encountered)
D_p3$z_t1 <- z(D_p3$knowledge_t1)
D_p3$z_ses <- z(D_p3$family_ses)
M_p3_abs <- lm(sources_recalled ~ z_encountered + z_t1 + z_ses + condition, data = D_p3)
C_p3_abs <- cr2_analysis(M_p3_abs, D_p3, "P3 encountered -> recalled count")

# IMPORTANT: standardization is recomputed AFTER the denominator-positive filter.
# This fixes the previous recall-proportion standardization issue.
D_p3_prop <- D_p3[D_p3$sources_encountered > 0 & is.finite(D_p3$recall_proportion), ]
D_p3_prop$session_id <- droplevels(D_p3_prop$session_id)
D_p3_prop$z_encountered <- z(D_p3_prop$sources_encountered)
D_p3_prop$z_t1 <- z(D_p3_prop$knowledge_t1)
D_p3_prop$z_ses <- z(D_p3_prop$family_ses)
M_p3_prop <- lm(recall_proportion ~ z_encountered + z_t1 + z_ses + condition, data = D_p3_prop)
C_p3_prop <- cr2_analysis(M_p3_prop, D_p3_prop, "P3 encountered -> recall proportion")

# ri_visit_count is a cumulative browser-history visitCount sum across recorded action rows;
# it is not a count of unique pages or session revisits.
p3_activity_specs <- data.frame(
  variable = c("ri_action_count", "ri_exploitation_actions", "ri_visit_count"),
  transform = rep("log1p", 3),
  stringsAsFactors = FALSE
)
p3_activity_rows <- list()
for (i in seq_len(nrow(p3_activity_specs))) {
  v <- p3_activity_specs$variable[i]
  d <- D[complete.cases(D[, c("sources_recalled", v, "knowledge_t1", "family_ses", "condition", "session_id")]), ]
  d$session_id <- droplevels(d$session_id)
  d$z_activity <- z(transform_metric(d[[v]], p3_activity_specs$transform[i]))
  d$z_t1 <- z(d$knowledge_t1)
  d$z_ses <- z(d$family_ses)
  m <- lm(sources_recalled ~ z_activity + z_t1 + z_ses + condition, data = d)
  c2 <- cr2_analysis(m, d, paste0("P3 ", v, " -> recall"))
  row <- extract_term(c2, "z_activity")
  row$analysis <- paste0("Activity -> recalled sources: ", v)
  row$variable <- v
  row$N <- nrow(d)
  p3_activity_rows[[i]] <- row
}
P3_activity <- do.call(rbind, p3_activity_rows)
P3_activity$q_BH <- p.adjust(P3_activity$p_Satt, method = "BH")
P3_activity$multiplicity_family <- "P3_activity_to_recall"

D_p3k <- D[complete.cases(D[, c("knowledge_t2", "knowledge_t1", "family_ses", "condition", "sources_recalled", "session_id")]), ]
D_p3k$session_id <- droplevels(D_p3k$session_id)
D_p3k$z_t1 <- z(D_p3k$knowledge_t1)
D_p3k$z_ses <- z(D_p3k$family_ses)
D_p3k$z_recall <- z(D_p3k$sources_recalled)
M_p3_base <- lm(knowledge_t2 ~ z_t1 + z_ses + condition, data = D_p3k)
M_p3_recall <- lm(knowledge_t2 ~ z_t1 + z_ses + condition + z_recall, data = D_p3k)
C_p3_recall <- cr2_analysis(M_p3_recall, D_p3k, "P3 recall -> T2")
P3_fit <- bind_fill(model_fit(M_p3_base, "P3 base model"), model_fit(M_p3_recall, "P3 base + recall"))
P3_fit$delta_R2 <- c(NA, P3_fit$R2[2] - P3_fit$R2[1])

P3_core <- bind_fill(
  key_term(C_p3_abs, "z_encountered", "Encountered sources -> recalled count", "theory-driven secondary"),
  key_term(C_p3_prop, "z_encountered", "Encountered sources -> recall proportion", "theory-driven secondary"),
  key_term(C_p3_recall, "z_recall", "Recalled-source count -> T2", "theory-driven secondary")
)
P3 <- bind_fill(P3_core, P3_activity, P3_fit)

# ------------------------------------------------------------------------------
# 7. P4 — epistemic source evaluation
# ------------------------------------------------------------------------------
cat("P4...\n")
VE_corr <- pearson_row(D$ve_expertise, D$ve_benevolence, "Expertise/competence vs benevolence/honesty")

D_p4 <- D[complete.cases(D[, c("knowledge_t2", "knowledge_t1", "family_ses", "condition", "ve_composite", "session_id")]), ]
D_p4$session_id <- droplevels(D_p4$session_id)
D_p4$z_t1 <- z(D_p4$knowledge_t1)
D_p4$z_ses <- z(D_p4$family_ses)
D_p4$z_ve <- z(D_p4$ve_composite)
M_p4_base <- lm(knowledge_t2 ~ z_t1 + z_ses + condition, data = D_p4)
M_p4 <- lm(knowledge_t2 ~ z_t1 + z_ses + condition + z_ve, data = D_p4)
C_p4 <- cr2_analysis(M_p4, D_p4, "P4 VE composite -> T2")
P4_fit <- bind_fill(model_fit(M_p4_base, "P4 base model"), model_fit(M_p4, "P4 base + VE composite"))
P4_fit$delta_R2 <- c(NA, P4_fit$R2[2] - P4_fit$R2[1])

p4_components <- list()
for (v in c("ve_expertise", "ve_benevolence")) {
  d <- D[complete.cases(D[, c("knowledge_t2", "knowledge_t1", "family_ses", "condition", v, "session_id")]), ]
  d$session_id <- droplevels(d$session_id)
  d$z_t1 <- z(d$knowledge_t1)
  d$z_ses <- z(d$family_ses)
  d$z_component <- z(d[[v]])
  m <- lm(knowledge_t2 ~ z_t1 + z_ses + condition + z_component, data = d)
  c2 <- cr2_analysis(m, d, paste0("P4 component ", v))
  row <- extract_term(c2, "z_component")
  row$analysis <- paste0(v, " -> T2")
  row$component <- v
  row$N <- nrow(d)
  p4_components[[v]] <- row
}
P4_components <- do.call(rbind, p4_components)
P4_components$q_BH <- p.adjust(P4_components$p_Satt, method = "BH")
P4_components$multiplicity_family <- "P4_source_evaluation_components"

D_p4j <- D[complete.cases(D[, c("knowledge_t2", "knowledge_t1", "family_ses", "condition", "ve_expertise", "ve_benevolence", "session_id")]), ]
D_p4j$session_id <- droplevels(D_p4j$session_id)
D_p4j$z_t1 <- z(D_p4j$knowledge_t1)
D_p4j$z_ses <- z(D_p4j$family_ses)
D_p4j$z_exp <- z(D_p4j$ve_expertise)
D_p4j$z_ben <- z(D_p4j$ve_benevolence)
M_p4j <- lm(knowledge_t2 ~ z_t1 + z_ses + condition + z_exp + z_ben, data = D_p4j)
C_p4j <- cr2_analysis(M_p4j, D_p4j, "P4 expertise + benevolence")
P4_joint <- block_test(M_p4j, C_p4j$V, c("z_exp", "z_ben"), "Expertise + benevolence joint HTZ")

D_p4r <- D[complete.cases(D[, c("knowledge_t2", "knowledge_t1", "family_ses", "condition", "sources_recalled", "ve_composite", "session_id")]), ]
D_p4r$session_id <- droplevels(D_p4r$session_id)
D_p4r$z_t1 <- z(D_p4r$knowledge_t1)
D_p4r$z_ses <- z(D_p4r$family_ses)
D_p4r$z_recall <- z(D_p4r$sources_recalled)
D_p4r$z_ve <- z(D_p4r$ve_composite)
M_p4r <- lm(knowledge_t2 ~ z_t1 + z_ses + condition + z_recall + z_ve, data = D_p4r)
C_p4r <- cr2_analysis(M_p4r, D_p4r, "P4 recall + VE")

D_p4s <- D[complete.cases(D[, c("ve_composite", "knowledge_t1", "family_ses", "condition", "scientific_action_share", "session_id")]), ]
D_p4s$session_id <- droplevels(D_p4s$session_id)
D_p4s$z_ve <- z(D_p4s$ve_composite)
D_p4s$z_t1 <- z(D_p4s$knowledge_t1)
D_p4s$z_ses <- z(D_p4s$family_ses)
D_p4s$z_scientific <- z(D_p4s$scientific_action_share)
M_p4s <- lm(z_ve ~ z_t1 + z_ses + condition + z_scientific, data = D_p4s)
C_p4s <- cr2_analysis(M_p4s, D_p4s, "P4 scientific-source action share -> VE")

P4_core <- bind_fill(
  key_term(C_p4, "z_ve", "VE composite -> T2", "main; a priori; theory-driven"),
  key_term(C_p4r, "z_recall", "Recall -> T2 in recall + VE model", "retention/evaluation contrast"),
  key_term(C_p4r, "z_ve", "VE -> T2 in recall + VE model", "main robustness test"),
  key_term(C_p4s, "z_scientific", "Scientific-source action share -> VE", "secondary ecological association")
)
P4 <- bind_fill(VE_corr, P4_core, P4_components, P4_joint, P4_fit)

# ------------------------------------------------------------------------------
# 8. P5 — distal resources, habits, dispositions and condition
# ------------------------------------------------------------------------------
cat("P5...\n")
P5_SES_cor <- bind_fill(
  pearson_row(D$family_ses, D$knowledge_t1, "SES vs T1"),
  pearson_row(D$family_ses, D$knowledge_t2, "SES vs T2"),
  pearson_row(D$family_ses, D$knowledge_gain, "SES vs raw gain")
)

D_p5g <- D[complete.cases(D[, c("knowledge_gain", "family_ses", "session_id")]), ]
D_p5g$session_id <- droplevels(D_p5g$session_id)
D_p5g$z_ses <- z(D_p5g$family_ses)
M_p5g <- lm(knowledge_gain ~ z_ses, data = D_p5g)
C_p5g <- cr2_analysis(M_p5g, D_p5g, "P5 SES -> raw gain")
P5_SES_gain <- key_term(C_p5g, "z_ses", "SES -> raw gain", "theory-driven secondary")

p5_ses_ri_specs <- data.frame(
  variable = c("time_serp_seconds", "serp_revisits", "mean_serp_time_seconds", "ri_action_count"),
  transform = c("log1p", "log1p", "log1p", "log1p"),
  stringsAsFactors = FALSE
)
p5_ses_ri_rows <- list()
for (i in seq_len(nrow(p5_ses_ri_specs))) {
  v <- p5_ses_ri_specs$variable[i]
  d <- D[complete.cases(D[, c(v, "family_ses", "knowledge_t1", "condition", "session_id")]), ]
  d$session_id <- droplevels(d$session_id)
  d$z_ri <- z(transform_metric(d[[v]], p5_ses_ri_specs$transform[i]))
  d$z_ses <- z(d$family_ses)
  d$z_t1 <- z(d$knowledge_t1)
  m <- lm(z_ri ~ z_ses + z_t1 + condition, data = d)
  c2 <- cr2_analysis(m, d, paste0("P5 SES -> ", v))
  row <- extract_term(c2, "z_ses")
  row$analysis <- paste0("SES -> ", v)
  row$variable <- v
  row$transform <- p5_ses_ri_specs$transform[i]
  row$N <- nrow(d)
  p5_ses_ri_rows[[i]] <- row
}
P5_SES_RI <- do.call(rbind, p5_ses_ri_rows)
P5_SES_RI$q_BH <- p.adjust(P5_SES_RI$p_Satt, method = "BH")
P5_SES_RI$multiplicity_family <- "P5_SES_to_search_traces"

D_p5h <- D[complete.cases(D[, c("knowledge_t2", "knowledge_t1", "family_ses", "condition",
                                  "search_learning_habit", "search_verification_habit", "ve_composite", "session_id")]), ]
D_p5h$session_id <- droplevels(D_p5h$session_id)
D_p5h$z_t1 <- z(D_p5h$knowledge_t1)
D_p5h$z_ses <- z(D_p5h$family_ses)
D_p5h$z_learning <- z(D_p5h$search_learning_habit)
D_p5h$z_verify <- z(D_p5h$search_verification_habit)
D_p5h$z_ve <- z(D_p5h$ve_composite)
M_p5h_ve <- lm(z_ve ~ z_t1 + z_ses + condition + z_learning + z_verify, data = D_p5h)
C_p5h_ve <- cr2_analysis(M_p5h_ve, D_p5h, "P5 search habits -> VE")
M_p5h_t2 <- lm(knowledge_t2 ~ z_t1 + z_ses + condition + z_learning + z_verify, data = D_p5h)
C_p5h_t2 <- cr2_analysis(M_p5h_t2, D_p5h, "P5 search habits -> T2")
P5_habits <- bind_fill(
  transform(extract_term(C_p5h_ve, "z_learning"), analysis = "Search-for-learning habit -> VE", outcome = "VE", predictor = "search_learning_habit"),
  transform(extract_term(C_p5h_ve, "z_verify"), analysis = "Search-for-verification habit -> VE", outcome = "VE", predictor = "search_verification_habit"),
  transform(extract_term(C_p5h_t2, "z_learning"), analysis = "Search-for-learning habit -> T2", outcome = "T2", predictor = "search_learning_habit"),
  transform(extract_term(C_p5h_t2, "z_verify"), analysis = "Search-for-verification habit -> T2", outcome = "T2", predictor = "search_verification_habit")
)
P5_habits$multiplicity_family <- paste0("P5_search_habits_to_", P5_habits$outcome)
P5_habits$q_BH <- NA_real_
for (fam in unique(P5_habits$multiplicity_family)) {
  idx <- which(P5_habits$multiplicity_family == fam)
  P5_habits$q_BH[idx] <- p.adjust(P5_habits$p_Satt[idx], method = "BH")
}
P5_habits_HTZ <- bind_fill(
  block_test(M_p5h_ve, C_p5h_ve$V, c("z_learning", "z_verify"), "Search habits joint -> VE"),
  block_test(M_p5h_t2, C_p5h_t2$V, c("z_learning", "z_verify"), "Search habits joint -> T2")
)

# Exploratory indirect statistical path: search-for-learning -> VE -> T2.
# Variables are standardized on the common complete-case sample and restandardized
# inside every session-cluster bootstrap resample.
D_p5i <- D_p5h
D_p5i$z_t2 <- z(D_p5i$knowledge_t2)
M_p5i_a <- lm(z_ve ~ z_t1 + z_ses + condition + z_learning + z_verify, data = D_p5i)
M_p5i_b <- lm(z_t2 ~ z_t1 + z_ses + condition + z_learning + z_verify + z_ve, data = D_p5i)
M_p5i_total <- lm(z_t2 ~ z_t1 + z_ses + condition + z_learning + z_verify, data = D_p5i)

# Fast, deterministic cluster bootstrap. The statistical procedure is unchanged:
# 34 session clusters are sampled with replacement; all continuous variables are
# restandardized within each bootstrap sample; then the two OLS path models are fit.
# Using integer row indices + .lm.fit() avoids rebuilding data frames and formula
# objects 40,000 times, making the FINAL 20,000-resample run substantially faster.
set.seed(P5_INDIRECT_SEED)
cluster_rows_p5i <- split(seq_len(nrow(D_p5i)), droplevels(D_p5i$session_id), drop = TRUE)
K_p5i <- length(cluster_rows_p5i)
boot_indirect <- rep(NA_real_, P5_INDIRECT_REPS)

p5_raw <- cbind(
  t1 = D_p5i$knowledge_t1,
  t2 = D_p5i$knowledge_t2,
  ses = D_p5i$family_ses,
  learning = D_p5i$search_learning_habit,
  verify = D_p5i$search_verification_habit,
  ve = D_p5i$ve_composite
)
p5_condition_coop <- as.numeric(D_p5i$condition == "Cooperation")

fast_z <- function(x) {
  n <- length(x)
  mu <- sum(x) / n
  centered <- x - mu
  sx <- sqrt(sum(centered * centered) / (n - 1L))
  if (!is.finite(sx) || sx <= .Machine$double.eps) return(NULL)
  centered / sx
}

progress_every <- if (RUN_MODE == "FINAL") 2000L else 100L
cat("  P5 indirect cluster bootstrap: ", P5_INDIRECT_REPS,
    " resamples (", RUN_MODE, " mode; optimized engine)...\n", sep = "")

for (b in seq_len(P5_INDIRECT_REPS)) {
  sampled_clusters <- sample.int(K_p5i, K_p5i, replace = TRUE)
  idx <- unlist(cluster_rows_p5i[sampled_clusters], use.names = FALSE)
  rb <- p5_raw[idx, , drop = FALSE]

  z_t1_b <- fast_z(rb[, "t1"])
  z_t2_b <- fast_z(rb[, "t2"])
  z_ses_b <- fast_z(rb[, "ses"])
  z_learning_b <- fast_z(rb[, "learning"])
  z_verify_b <- fast_z(rb[, "verify"])
  z_ve_b <- fast_z(rb[, "ve"])

  if (!any(vapply(list(z_t1_b, z_t2_b, z_ses_b, z_learning_b, z_verify_b, z_ve_b), is.null, logical(1)))) {
    X_a <- cbind(
      `(Intercept)` = 1,
      z_t1 = z_t1_b,
      z_ses = z_ses_b,
      conditionCooperation = p5_condition_coop[idx],
      z_learning = z_learning_b,
      z_verify = z_verify_b
    )
    fit_a <- try(.lm.fit(X_a, z_ve_b), silent = TRUE)

    X_b <- cbind(X_a, z_ve = z_ve_b)
    fit_b <- try(.lm.fit(X_b, z_t2_b), silent = TRUE)

    if (!inherits(fit_a, "try-error") && !inherits(fit_b, "try-error")) {
      # Fixed positions: intercept, T1, SES, condition, learning, verify [, VE].
      aa <- unname(fit_a$coefficients[5L])
      bb <- unname(fit_b$coefficients[7L])
      if (is.finite(aa) && is.finite(bb)) boot_indirect[b] <- aa * bb
    }
  }

  if (b %% progress_every == 0L || b == P5_INDIRECT_REPS) {
    cat("    ", b, "/", P5_INDIRECT_REPS, " resamples completed\n", sep = "")
  }
}

a_obs <- unname(coef(M_p5i_a)["z_learning"])
b_obs <- unname(coef(M_p5i_b)["z_ve"])
direct_obs <- unname(coef(M_p5i_b)["z_learning"])
total_obs <- unname(coef(M_p5i_total)["z_learning"])
indirect_obs <- a_obs * b_obs
boot_ok <- boot_indirect[is.finite(boot_indirect)]
if (length(boot_ok) < 0.95 * P5_INDIRECT_REPS) stop("P5 indirect bootstrap: too many invalid replications.")
boot_ci <- unname(quantile(boot_ok, probs = c(.025, .975), names = FALSE, type = 7))

P5_indirect <- data.frame(
  analysis = "Exploratory statistical indirect path: search-for-learning -> epistemic evaluation -> T2",
  N = nrow(D_p5i),
  clusters = nlevels(droplevels(D_p5i$session_id)),
  a_learning_to_VE = a_obs,
  b_VE_to_T2 = b_obs,
  total_learning_to_T2 = total_obs,
  direct_learning_to_T2_given_VE = direct_obs,
  indirect_standardized = indirect_obs,
  bootstrap_mode = RUN_MODE,
  bootstrap_engine = "optimized base-R .lm.fit; session-cluster resampling",
  bootstrap_reps_requested = P5_INDIRECT_REPS,
  bootstrap_reps_valid = length(boot_ok),
  bootstrap_seed = P5_INDIRECT_SEED,
  CI95_percentile_low = boot_ci[1],
  CI95_percentile_high = boot_ci[2],
  causal_interpretation = "No — statistical indirect path only",
  stringsAsFactors = FALSE
)

P5_disposition_cor <- bind_fill(
  pearson_row(D$crt2, D$knowledge_t1, "CRT-2 vs T1"),
  pearson_row(D$intellectual_humility, D$knowledge_t1, "Intellectual humility vs T1"),
  pearson_row(D$epistemic_beliefs, D$knowledge_t1, "Epistemic beliefs vs T1"),
  pearson_row(D$crt2, D$knowledge_gain, "CRT-2 vs gain"),
  pearson_row(D$intellectual_humility, D$knowledge_gain, "Intellectual humility vs gain"),
  pearson_row(D$epistemic_beliefs, D$knowledge_gain, "Epistemic beliefs vs gain")
)
P5_disposition_cor$multiplicity_family <- c(rep("P5_dispositions_T1", 3), rep("P5_dispositions_gain", 3))
P5_disposition_cor$q_BH <- NA_real_
for (fam in unique(P5_disposition_cor$multiplicity_family)) {
  idx <- which(P5_disposition_cor$multiplicity_family == fam)
  P5_disposition_cor$q_BH[idx] <- p.adjust(P5_disposition_cor$p[idx], method = "BH")
}

D_p5d <- D[complete.cases(D[, c("knowledge_t1", "knowledge_t2", "family_ses", "condition",
                                  "crt2", "intellectual_humility", "epistemic_beliefs", "session_id")]), ]
D_p5d$session_id <- droplevels(D_p5d$session_id)
D_p5d$z_t1 <- z(D_p5d$knowledge_t1)
D_p5d$z_ses <- z(D_p5d$family_ses)
D_p5d$z_crt <- z(D_p5d$crt2)
D_p5d$z_hum <- z(D_p5d$intellectual_humility)
D_p5d$z_epi <- z(D_p5d$epistemic_beliefs)
M_p5d_t1 <- lm(knowledge_t1 ~ z_ses + condition + z_crt + z_hum + z_epi, data = D_p5d)
C_p5d_t1 <- cr2_analysis(M_p5d_t1, D_p5d, "P5 dispositions -> T1")
P5_HTZ_T1 <- block_test(M_p5d_t1, C_p5d_t1$V, c("z_crt", "z_hum", "z_epi"), "Dispositions joint -> T1")
M_p5d_t2 <- lm(knowledge_t2 ~ z_t1 + z_ses + condition + z_crt + z_hum + z_epi, data = D_p5d)
C_p5d_t2 <- cr2_analysis(M_p5d_t2, D_p5d, "P5 dispositions -> T2 adjusted")
P5_HTZ_T2 <- block_test(M_p5d_t2, C_p5d_t2$V, c("z_crt", "z_hum", "z_epi"), "Dispositions joint -> T2")

D_p5dv <- D[complete.cases(D[, c("ve_composite", "knowledge_t1", "family_ses", "condition",
                                   "crt2", "intellectual_humility", "epistemic_beliefs", "session_id")]), ]
D_p5dv$session_id <- droplevels(D_p5dv$session_id)
D_p5dv$z_ve <- z(D_p5dv$ve_composite)
D_p5dv$z_t1 <- z(D_p5dv$knowledge_t1)
D_p5dv$z_ses <- z(D_p5dv$family_ses)
D_p5dv$z_crt <- z(D_p5dv$crt2)
D_p5dv$z_hum <- z(D_p5dv$intellectual_humility)
D_p5dv$z_epi <- z(D_p5dv$epistemic_beliefs)
M_p5d_ve <- lm(z_ve ~ z_t1 + z_ses + condition + z_crt + z_hum + z_epi, data = D_p5dv)
C_p5d_ve <- cr2_analysis(M_p5d_ve, D_p5dv, "P5 dispositions -> VE")
P5_HTZ_VE <- block_test(M_p5d_ve, C_p5d_ve$V, c("z_crt", "z_hum", "z_epi"), "Dispositions joint -> VE")

P5_disposition_models <- bind_fill(C_p5d_t1$tests, C_p5d_t2$tests, C_p5d_ve$tests)
P5_disposition_models$analysis <- P5_disposition_models$model

p5_condition_specs <- data.frame(
  variable = c("knowledge_t2", "nav_exploration_ratio", "time_exploration_ratio", "thematic_exploration_ratio", "sources_recalled", "ve_composite"),
  family = c("primary_T2", rep("P5_condition_RI", 3), "recall", "VE"),
  stringsAsFactors = FALSE
)
p5_condition_rows <- list()
for (i in seq_len(nrow(p5_condition_specs))) {
  v <- p5_condition_specs$variable[i]
  d <- D[complete.cases(D[, c(v, "condition", "session_id")]), ]
  d$session_id <- droplevels(d$session_id)
  d$y <- d[[v]]
  if (v %in% c("knowledge_t2", "ve_composite")) {
    d <- d[complete.cases(d[, c("knowledge_t1", "family_ses")]), ]
    d$session_id <- droplevels(d$session_id)
    d$z_t1 <- z(d$knowledge_t1)
    d$z_ses <- z(d$family_ses)
    m <- lm(y ~ z_t1 + z_ses + condition, data = d)
  } else {
    m <- lm(y ~ condition, data = d)
  }
  c2 <- cr2_analysis(m, d, paste0("P5 condition -> ", v))
  row <- extract_term(c2, "conditionCooperation")
  row$analysis <- paste0("COOP/COMP -> ", v)
  row$variable <- v
  row$multiplicity_family <- p5_condition_specs$family[i]
  row$N <- nrow(d)
  row$mean_competition_raw <- mean(d[[v]][d$condition == "Competition"], na.rm = TRUE)
  row$mean_cooperation_raw <- mean(d[[v]][d$condition == "Cooperation"], na.rm = TRUE)
  p5_condition_rows[[i]] <- row
}
P5_condition <- do.call(rbind, p5_condition_rows)
P5_condition$q_BH <- NA_real_
idx <- which(P5_condition$multiplicity_family == "P5_condition_RI")
P5_condition$q_BH[idx] <- p.adjust(P5_condition$p_Satt[idx], method = "BH")

P5 <- bind_fill(
  P5_SES_cor,
  P5_SES_gain,
  key_term(C_p1, "z_ses", "SES -> T2 adjusted for T1 and condition", "also reported in P1"),
  P5_SES_RI,
  P5_habits,
  P5_habits_HTZ,
  P5_indirect,
  P5_disposition_cor,
  P5_disposition_models,
  P5_HTZ_T1,
  P5_HTZ_T2,
  P5_HTZ_VE,
  P5_condition
)

# ------------------------------------------------------------------------------
# 9. P6 — subjective monitoring
# ------------------------------------------------------------------------------
cat("P6...\n")
D_p6 <- D[complete.cases(D[, c("subjective_knowledge_t1", "subjective_knowledge_t2", "knowledge_t1", "knowledge_t2", "session_id")]), ]
subj_t <- t.test(D_p6$subjective_knowledge_t2, D_p6$subjective_knowledge_t1, paired = TRUE)
subj_w <- suppressWarnings(wilcox.test(D_p6$subjective_knowledge_t2, D_p6$subjective_knowledge_t1, paired = TRUE, exact = FALSE))
P6_change <- data.frame(
  analysis = "Subjective knowledge T1-to-T2 change",
  N = nrow(D_p6),
  mean_subjective_T1 = mean(D_p6$subjective_knowledge_t1),
  mean_subjective_T2 = mean(D_p6$subjective_knowledge_t2),
  mean_change = mean(D_p6$subjective_change),
  paired_t = unname(subj_t$statistic),
  paired_t_p = subj_t$p.value,
  Wilcoxon_V = unname(subj_w$statistic),
  Wilcoxon_p = subj_w$p.value,
  stringsAsFactors = FALSE
)
P6_correlations <- bind_fill(
  pearson_row(D$knowledge_t1, D$subjective_knowledge_t1, "Objective vs subjective T1"),
  pearson_row(D$knowledge_t2, D$subjective_knowledge_t2, "Objective vs subjective T2"),
  pearson_row(D$knowledge_gain, D$subjective_change, "Factual gain vs subjective change")
)
P6_correlations$q_BH <- p.adjust(P6_correlations$p, method = "BH")
P6_correlations$multiplicity_family <- "P6_objective_subjective_correlations"

D_p6s <- D[complete.cases(D[, c("subjective_knowledge_t2", "subjective_knowledge_t1", "knowledge_t2",
                                  "family_ses", "condition", "time_exploration_ratio", "session_id")]), ]
D_p6s$session_id <- droplevels(D_p6s$session_id)
D_p6s$z_obj_t2 <- z(D_p6s$knowledge_t2)
D_p6s$z_subj_t1 <- z(D_p6s$subjective_knowledge_t1)
D_p6s$z_ses <- z(D_p6s$family_ses)
D_p6s$z_serp <- z(D_p6s$time_exploration_ratio)
M_p6s <- lm(subjective_knowledge_t2 ~ z_obj_t2 + z_subj_t1 + z_ses + condition + z_serp, data = D_p6s)
C_p6s <- cr2_analysis(M_p6s, D_p6s, "P6 SERP-time share -> subjective T2")
P6_SERP <- key_term(C_p6s, "z_serp", "Exploratory SERP-time share -> subjective T2", "exploratory")
P6_SERP$N <- nrow(D_p6s)
P6 <- bind_fill(P6_change, P6_correlations, P6_SERP)

# ------------------------------------------------------------------------------
# 10. Multiplicity register
# ------------------------------------------------------------------------------
mult_rows <- list()
add_mult <- function(df, family_col, p_col, q_col, label_col = "analysis") {
  if (is.null(df) || !nrow(df)) return(NULL)
  if (!all(c(family_col, p_col, q_col) %in% names(df))) return(NULL)
  out <- data.frame(
    family = as.character(df[[family_col]]),
    analysis = if (label_col %in% names(df)) as.character(df[[label_col]]) else "",
    p_raw = as.numeric(df[[p_col]]),
    q_BH = as.numeric(df[[q_col]]),
    stringsAsFactors = FALSE
  )
  out[is.finite(out$p_raw), , drop = FALSE]
}
mult_rows[[1]] <- add_mult(P2b, "multiplicity_family", "p_Satt", "q_BH")
mult_rows[[2]] <- add_mult(P2c, "multiplicity_family", "p_Satt", "q_BH")
mult_rows[[3]] <- add_mult(P3_activity, "multiplicity_family", "p_Satt", "q_BH")
mult_rows[[4]] <- add_mult(P4_components, "multiplicity_family", "p_Satt", "q_BH")
mult_rows[[5]] <- add_mult(P5_SES_RI, "multiplicity_family", "p_Satt", "q_BH")
mult_rows[[6]] <- add_mult(P5_habits, "multiplicity_family", "p_Satt", "q_BH")
mult_rows[[7]] <- add_mult(P5_disposition_cor, "multiplicity_family", "p", "q_BH")
mult_rows[[8]] <- add_mult(P5_condition, "multiplicity_family", "p_Satt", "q_BH")
mult_rows[[9]] <- add_mult(P6_correlations, "multiplicity_family", "p", "q_BH")
Multiplicity <- do.call(rbind, mult_rows[!vapply(mult_rows, is.null, logical(1))])
rownames(Multiplicity) <- NULL

# ------------------------------------------------------------------------------
# 11. Sample sheet and final write
# ------------------------------------------------------------------------------
Sample <- data.frame(
  item = c(
    "Script version",
    "Participants",
    "Competition condition",
    "Cooperation condition",
    "Session clusters for CR2",
    "Family SES available",
    "VE expertise/benevolence composite available",
    "Historical metric-specific exclusions",
    "Run mode",
    "P5 indirect bootstrap",
    "P5 bootstrap engine",
    "Data-sharing scope",
    "T2-to-T3 sensitivity check"
  ),
  value = c(
    SCRIPT_VERSION,
    nrow(D),
    sum(D$condition == "Competition"),
    sum(D$condition == "Cooperation"),
    nlevels(D$session_id),
    sum(is.finite(D$family_ses)),
    sum(is.finite(D$ve_composite)),
    "None. Corrected canonical navigation/time metrics are used.",
    RUN_MODE,
    paste0(P5_INDIRECT_REPS, " session-cluster resamples; percentile CI; exploratory/non-causal"),
    "Optimized base-R .lm.fit; same cluster resampling and within-resample standardization as the reference implementation",
    "Article-specific public dataset derived from the controlled internal canonical archive",
    "Aggregate canonical record supplied separately; participant-level T3 is not in the Article 1 public table"
  ),
  stringsAsFactors = FALSE
)

write_workbook(
  RESULTS_FILE,
  list(
    Sample = Sample,
    P1 = P1,
    P2 = P2,
    P3 = P3,
    P4 = P4,
    P5 = P5,
    P6 = P6,
    T3_Sensitivity = T3_Sensitivity,
    Multiplicity = Multiplicity,
    QC = qc
  )
)

capture.output(sessionInfo(), file = SESSION_FILE)

cat("\n============================================================\n")
cat("ANALYSIS COMPLETE\n")
cat("Participants: ", nrow(D), "\n", sep = "")
cat("CR2 session clusters: ", nlevels(D$session_id), "\n", sep = "")
cat("VE composite available: ", sum(is.finite(D$ve_composite)), "\n", sep = "")
cat("Run mode: ", RUN_MODE, " (P5 bootstrap reps = ", P5_INDIRECT_REPS, ")\n", sep = "")
cat("P5 standardized indirect path: ", round(indirect_obs, 3),
    "  bootstrap 95% CI [", round(boot_ci[1], 3), ", ", round(boot_ci[2], 3), "]\n", sep = "")
cat("Historical metric-specific exclusions: NONE (corrected canonical RI metrics).\n")
cat("T2-to-T3 sensitivity: documented aggregate canonical check (see T3_Sensitivity sheet).\n")
cat("Results workbook: ", normalizePath(RESULTS_FILE, winslash = "/"), "\n", sep = "")
cat("Session information: ", normalizePath(SESSION_FILE, winslash = "/"), "\n", sep = "")
cat("============================================================\n")
