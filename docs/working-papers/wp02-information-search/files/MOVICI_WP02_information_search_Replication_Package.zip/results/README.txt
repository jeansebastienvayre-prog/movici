MOVICI Article 1 results

The included MOVICI_Article1_Final_Results.xlsx workbook corresponds to FINAL mode.

Running MOVICI_Article1_Analysis.R with RUN_MODE set to FINAL recreates this workbook and writes sessionInfo.txt. FINAL mode uses 20,000 session-cluster bootstrap resamples for the exploratory P5 indirect statistical path.

The aggregate T2-to-T3 sensitivity record is read from documentation/MOVICI_Article1_T3_Sensitivity_Summary.csv. It is not recomputed from participant-level T3 because T3 is intentionally absent from the minimized Article 1 dataset.
