# MOVICI Article 3 reproducibility package

**Release status: preprint/OSF reproducibility package (2026-09-18)**

## Article

**Working title: Learning from Documents and from Others: Knowledge Change and Epistemic Coordination**

Article in preparation.

This package implements the planned Article 3 analyses from minimized, article-specific datasets derived from the canonical MOVICI release.

## Data scope and privacy

`data/MOVICI_Article3_Participant_Data.csv` contains 96 pseudonymized participants in 34 pseudonymized debate clusters. It includes only the T1/T2/T3 factual, subjective and attitude outcomes, Web-source epistemic-evaluation variables, the experimental condition, group size, and the family-SES covariate required by the complementary C1 analysis.

`data/MOVICI_Article3_Dyad_Data.csv` contains 212 ordered evaluator-to-evaluatee relations involving 91 evaluators across 29 debates. It includes only pre-debate factual knowledge and the matched partner expertise/benevolence evaluations required for H3 and RQ1.

Exact dates and time slots, workstation identifiers, raw demographic variables, raw transcripts, free text, URLs, SDO, homophily variables, dispositional profiles, and debate-behavior indicators are omitted. Article 3 uses new public participant pseudonyms (`C001`–`C096`) and debate pseudonyms. No crosswalk to internal identifiers or to Article 1/Article 2 public identifiers is distributed.

## Canonical provenance

The package was derived from:

- `MOVICI_Canonical_Dataset_OSF_2026-09-06_FINAL/data/MOVICI_Canonical_Dataset_96.csv`
- `MOVICI_Canonical_Dataset_OSF_2026-09-06_FINAL/evaluation_matching/MOVICI_Evaluation_Matching.xlsx`, sheet `CANONICAL_ONLY_DYADS`

Family SES exactly reproduces the Article 1 construction from the canonical parental education, social-position and income components.

## Analysis architecture

The script is intentionally restricted to the Article 3 framework:

- **H1 — Factual trajectory.** Within-participant T1→T2 change is complemented by a common-baseline T1→T3 analysis and the incremental T2→T3 change. Score dispersion is examined for all three contrasts so that the end-of-protocol state can be compared with the same T1 baseline.
- **H2 — Distinct outcomes.** Subjective knowledge and attitudes now mirror H1 temporally: T1→T2, common-baseline T1→T3, and incremental T2→T3 changes are all estimated with CR2/Satterthwaite inference; dispersion is tested over the same three contrasts. Attitude subscales are tested over T1→T2, T1→T3, and T2→T3 with Benjamini–Hochberg correction within each family. Cross-outcome coupling is also reported for all three intervals.
- **H3 — Interactional reconfiguration.** Standardized Web-source versus human-source epistemic credit is compared as a function of Cooperation/Competition; self-calibration is analysed longitudinally. A sensitivity model additionally controls the number of Web sources recalled, with a stronger model allowing this covariate to differ by source type.
- **C1 — Complementary CAVL analysis.** T1 knowledge × Web-source credit predicts T2, with family SES and condition controlled; expertise and benevolence components are decomposed secondarily. This is not a main Article 3 hypothesis.
- **RQ1 — Human epistemic bottleneck.** Tests whether partners' pre-debate factual knowledge is recognized and whether knowledge available in partners predicts T3 beyond one's own T2. The primary group-knowledge predictor is the partner mean; robustness analyses additionally use the highest-scoring partner, the highest-scoring partner's advantage over the evaluator, and the proportion of partners scoring above the evaluator. Standardized CR2/Satterthwaite equivalence-sensitivity analyses are reported at symmetric ±0.10, ±0.20 and ±0.30 SD bounds; ±0.20 is the focal small-effect benchmark, not a preregistered SESOI.

SDO, homophily, dispositional-profile and debate-behavior analyses are deliberately excluded.

## Design and ecological-validity notes

MOVICI intentionally balances comparability with ecological validity. The documentary and interactional sequences share a parallel post-activity structure: source/partner evaluation plus active recall and evaluation of arguments. They are not forced into strict isomorphism. Free Web search retains self-generated queries, tool choice and source selection; live debate retains reciprocal partners, disagreement and coordination demands. These differences are treated both as constraints on pure causal comparison and as functionally meaningful properties of the environments being studied.

Cooperation/Competition assignment was implemented operationally according to participant enrollment/entry order rather than by simple random allocation. Debate-group composition also used T1 attitude positions, within practical constraints, to favor heterogeneous initial positions and make substantive disagreement possible. The analysis script retains descriptive baseline-balance diagnostics and explicitly notes that sequence position and environment type are confounded by the fixed order. These diagnostics do not transform the design into a randomized experiment.

## Contents

- `MOVICI_Article3_OSF.Rproj`: RStudio project.
- `MOVICI_Article3_Analysis.R`: complete analysis script.
- `data/MOVICI_Article3_Participant_Data.csv`: minimized participant dataset.
- `data/MOVICI_Article3_Dyad_Data.csv`: minimized ordered-dyad dataset.
- `documentation/MOVICI_Article3_Data_Dictionary.xlsx`: public-variable dictionary, derivations and analysis map.
- `materials/MOVICI_Article3_Measures_and_Scoring.xlsx`: design timeline, measure wording, scoring provenance and condition instructions.
- `results/README.txt`: output instructions.
- `DATA_AUDIT.txt`: derivation/minimization audit.
- `CHANGELOG_v5.txt`: changes introduced in the current working revision.
- `SHA256SUMS.txt`: integrity hashes.
- `LICENSE_DATA_CC_BY_4.0.txt`: data/documentation license.
- `LICENSE_CODE_MIT.txt`: code license.

## Reproduction

1. Open `MOVICI_Article3_OSF.Rproj` in RStudio.
2. Open `MOVICI_Article3_Analysis.R`.
3. Keep `RUN_MODE <- "CHECK"` for a quick run. CHECK uses 500 debate-cluster bootstrap resamples.
4. Use `RUN_MODE <- "FINAL"` for article/OSF numbers. FINAL uses 20,000 debate-cluster bootstrap resamples.
5. Source the complete script.

The script first writes `results/MOVICI_Article3_Core_Results.xlsx` containing all non-bootstrap analyses. It then adds the prespecified cluster-bootstrap variance/convergence checks and writes `results/MOVICI_Article3_Check_Results.xlsx`. It also writes `results/sessionInfo_CHECK.txt` or `sessionInfo_FINAL.txt`.

The script requires `clubSandwich` and `openxlsx` and installs them from CRAN if absent.

## Interpretation notes

- T1→T2 covers the full search–active-recall–source/argument-evaluation sequence; it is not a causal estimate of Web search alone.
- T2→T3 covers the full debate → partner evaluation → argument recall/evaluation → T3 sequence; it is not a causal estimate of debate alone.
- T1→T2 and T1→T3 are additionally shown against the same baseline. T2→T3 remains the incremental second-period change. The direct phase contrast remains the appropriate test of differential sequential change; significance in one period and nonsignificance in another is not itself a between-period test.
- Because every participant completed the documentary period before the interactional period, environment type and sequence position are perfectly confounded. No statistical adjustment in this dataset can identify an order-independent document-versus-interaction effect; the three-time-point analyses characterize trajectories rather than neutralize order.
- Pitman–Morgan tests compare paired variances across the same participants. The script now reports T1→T2, T1→T3 and T2→T3 variance comparisons. Dispersion is a property of the observed score distribution, not direct evidence about latent-knowledge variance.
- Web and human epistemic-credit composites are standardized within source type before cross-environment comparison. The environments are not treated as strictly isomorphic: Web sources are self-selected and recalled, whereas human partners are interactionally present. The H3 recalled-source-count sensitivity asks whether the core interaction is robust to this participant-level difference without treating ecological source selection as a nuisance to be eliminated.
- The minimized public participant file contains factual total scores rather than item-level QCM responses. The analysis script reports scale-distribution diagnostics at T1/T2/T3 for factual, subjective, and global-attitude outcomes. For the canonical stored global-attitude score it uses the correct theoretical range -42 to +22. Factual internal-consistency reliability remains not estimable from this minimized dataset because item-level QCM responses are not distributed.
- Attitude scores preserve the canonical signed scoring. The theoretical stored-score ranges are SSA -18 to -2, VAHC +2 to +18, VASA -18 to -2, EP -8 to +8, and overall -42 to +22. Lower/more negative overall scores indicate a more critical orientation toward animal-protein consumption/use and/or stronger animal-protection/environmental-regulation orientation; subscales should be interpreted from their item wording.
- RQ1 is a research-question block. Nonsignificant tests are not treated as evidence of absence. The package therefore adds standardized equivalence-sensitivity analyses for the two most important null-signal pathways (partner factual knowledge → perceived expertise; mean partner factual knowledge → T3), plus robustness analyses using the highest-scoring partner and potential factual-knowledge advantage.
- The Article 3 analysis was not preregistered. Its comparative hypotheses are theory-guided by CAVL and established literatures on documentary learning, distributed cognition, collaborative cognitive load, transactive memory, metacognition and epistemic vigilance. Equivalence analyses are explicitly post hoc sensitivity analyses rather than confirmatory equivalence tests.

## Licenses

Data and documentation: CC BY 4.0. R code: MIT License.
