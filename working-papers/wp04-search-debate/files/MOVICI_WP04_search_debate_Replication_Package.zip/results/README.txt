MOVICI Article 3 results

Running MOVICI_Article3_Analysis.R writes:

1. MOVICI_Article3_Core_Results.xlsx
   Contains all non-bootstrap analyses for H1-H3, complementary C1 and RQ1, QC, design notes, baseline-balance diagnostics, T1->T3 common-baseline change, T1/T2/T3 distribution diagnostics (including the corrected canonical global-attitude range -42 to +22), direct within-participant contrasts, CR2/Satterthwaite models, Pitman-Morgan paired-variance tests, H3 recalled-source-count sensitivity models, expanded RQ1 partner-knowledge robustness models, BH-corrected subscale/component families, and a compact Key_Results sheet, plus standardized equivalence-sensitivity sheets for H2 couplings and the two central RQ1 null-signal pathways.

2. MOVICI_Article3_Check_Results.xlsx
   Contains all Core sheets plus the prespecified debate-cluster bootstrap
   checks for the direct factual variance-ratio contrast and the specificity
   of factual dispersion change relative to subjective knowledge and attitudes at both T1->T2 and T1->T3.

3. sessionInfo_CHECK.txt or sessionInfo_FINAL.txt
   Records the R/package environment used for the run.

Distributed default: RUN_MODE = CHECK (500 cluster-bootstrap resamples).
Article/OSF mode: RUN_MODE = FINAL (20,000 cluster-bootstrap resamples).

The script stops before inference if its structural, linkage or scoring checks fail.

Equivalence-sensitivity interpretation
- Standardized CR2/Satterthwaite TOST analyses use symmetric bounds of +/-0.10, +/-0.20 and +/-0.30 SD.
- +/-0.20 is displayed in Key_Results as the focal small-effect benchmark.
- Because these equivalence analyses were added after the initial Article 3 screening, they are sensitivity analyses, not preregistered confirmatory equivalence tests.
- Equivalence is concluded at a given bound only when both one-sided p values are < .05 (equivalently, the CR2/Satterthwaite 90% CI lies within the bounds).
