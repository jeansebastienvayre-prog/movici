# ==============================================================================
# MOVICI — ARTICLE 3
# Comparative within-participant analysis of information search and debate
# ==============================================================================
# Public data sources:
#   data/MOVICI_Article3_Participant_Data.csv
#   data/MOVICI_Article3_Dyad_Data.csv
# Participant sample: N = 96, 34 debate clusters
# Dyadic sample: 212 ordered evaluator-to-evaluatee relations, 91 evaluators,
#                29 debate clusters
# Inference: OLS + CR2 cluster-robust SEs, Satterthwaite df
# Multiplicity: Benjamini-Hochberg correction within prespecified functional families
# Bootstrap: debate-cluster bootstrap for direct variance-ratio contrasts and
#            selected correlation/convergence robustness analyses.
#
# ARTICLE 3 SCOPE
# H1  Factual trajectory across T1->T2, common-baseline T1->T3, and incremental T2->T3 change
# H2  Full T1->T2, T1->T3, and T2->T3 trajectories for subjective knowledge and attitudes, plus cross-outcome dissociation
# H3  Interactional reconfiguration of epistemic credit and self-calibration
# C1  Complementary CAVL test: prior expertise moderates the association between Web-source credit and T2 knowledge
# RQ1 Human epistemic bottleneck: available partner knowledge -> recognition -> learning
#
# Deliberately excluded from Article 3:
# SDO, homophily, dispositional profiles, and debate-behavior indicators.
# ==============================================================================

rm(list = ls())
options(stringsAsFactors = FALSE, scipen = 999)
set.seed(20260916)
SCRIPT_VERSION <- "OSF_ARTICLE3_2026-09-17_v5"

# Run mode ---------------------------------------------------------------------
# CHECK: 500 debate-cluster bootstrap resamples for installation/code verification.
# FINAL: 20,000 debate-cluster bootstrap resamples for article/OSF numbers.
RUN_MODE <- "CHECK"   # allowed: "CHECK", "FINAL"
if (!RUN_MODE %in% c("CHECK", "FINAL")) stop("RUN_MODE must be CHECK or FINAL.")
BOOT_REPS <- if (RUN_MODE == "FINAL") 20000L else 500L
BOOT_SEED <- 20260916L

# Equivalence-sensitivity settings ------------------------------------------------
# Article 3 was not preregistered and these equivalence analyses were added after
# the initial null-significance screening. We therefore do NOT treat one SESOI as
# confirmatory. Instead, standardized CR2/Satterthwaite TOST results are reported
# across three symmetric sensitivity bounds: +/-0.10, +/-0.20, and +/-0.30 SD of
# the outcome per 1 SD of the predictor. The +/-0.20 bound is a focal small-effect
# benchmark for interpretation, not a preregistered threshold.
EQUIV_BOUNDS_SD <- c(0.10, 0.20, 0.30)
EQUIV_ALPHA <- 0.05

# Canonical stored attitude-score ranges ----------------------------------------
# The administered attitude response format has nine positions. The canonical
# shared dataset retains direction-specific signed subscale scores. Under this
# stored scoring, the theoretical subscale ranges are:
#   SSA  -18 to -2
#   VAHC  +2 to +18
#   VASA -18 to -2
#   EP    -8 to +8
# Hence the theoretical overall signed attitude-score range is -42 to +22.
# These constants are used only for floor/ceiling diagnostics and QC; they do
# not affect any mean-change, CR2, Pitman-Morgan, bootstrap, or regression test.
ATTITUDE_TOTAL_MIN <- -42
ATTITUDE_TOTAL_MAX <- 22

# 1. Dependencies and paths ----------------------------------------------------
required_packages <- c("clubSandwich", "openxlsx")
options(repos = c(CRAN = "https://cloud.r-project.org"))
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]
if (length(missing_packages) > 0L) install.packages(missing_packages)
invisible(lapply(required_packages, library, character.only = TRUE))

PROJECT_ROOT <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
PARTICIPANT_FILE <- file.path(PROJECT_ROOT, "data", "MOVICI_Article3_Participant_Data.csv")
DYAD_FILE <- file.path(PROJECT_ROOT, "data", "MOVICI_Article3_Dyad_Data.csv")
OUT_DIR <- file.path(PROJECT_ROOT, "results")
dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)
CORE_FILE <- file.path(OUT_DIR, "MOVICI_Article3_Core_Results.xlsx")
CHECK_FILE <- file.path(OUT_DIR, "MOVICI_Article3_Check_Results.xlsx")
SESSION_FILE <- file.path(OUT_DIR, paste0("sessionInfo_", RUN_MODE, ".txt"))

if (!file.exists(PARTICIPANT_FILE)) stop("Participant data not found: ", PARTICIPANT_FILE)
if (!file.exists(DYAD_FILE)) stop("Dyad data not found: ", DYAD_FILE)

cat("\nMOVICI Article 3 — comparative reproducible analysis\n")
cat("Script version:", SCRIPT_VERSION, "\n")
cat("Run mode:", RUN_MODE, "\n")
cat("Bootstrap resamples:", BOOT_REPS, "\n\n")

# 2. Helper functions ----------------------------------------------------------
num <- function(x) suppressWarnings(as.numeric(x))

z <- function(x) {
  x <- as.numeric(x)
  m <- mean(x, na.rm = TRUE)
  s <- sd(x, na.rm = TRUE)
  if (!is.finite(s) || s == 0) return(rep(NA_real_, length(x)))
  (x - m) / s
}

z_with <- function(x, center, scale) {
  x <- as.numeric(x)
  if (!is.finite(scale) || scale == 0) return(rep(NA_real_, length(x)))
  (x - center) / scale
}

safe_mean <- function(x) {
  x <- as.numeric(x)
  if (!any(is.finite(x))) return(NA_real_)
  mean(x, na.rm = TRUE)
}

assert_qc <- function(condition, message) {
  if (!isTRUE(condition)) stop("QC failure: ", message, call. = FALSE)
}

bind_fill <- function(...) {
  dfs <- list(...)
  dfs <- dfs[vapply(dfs, function(x) !is.null(x) && nrow(as.data.frame(x)) > 0L, logical(1))]
  if (!length(dfs)) return(data.frame())
  dfs <- lapply(dfs, function(x) as.data.frame(x, check.names = FALSE, stringsAsFactors = FALSE))
  all_names <- unique(unlist(lapply(dfs, names), use.names = FALSE))
  dfs <- lapply(dfs, function(d) {
    miss <- setdiff(all_names, names(d))
    for (m in miss) d[[m]] <- NA
    d[, all_names, drop = FALSE]
  })
  ans <- do.call(rbind, dfs)
  rownames(ans) <- NULL
  ans
}

add_terms <- function(x, model) {
  x <- as.data.frame(x, check.names = FALSE)
  if ("Coef." %in% names(x)) names(x)[names(x) == "Coef."] <- "term"
  if ("Coef" %in% names(x)) names(x)[names(x) == "Coef"] <- "term"
  if (!"term" %in% names(x)) {
    x <- data.frame(term = names(coef(model)), x, check.names = FALSE, row.names = NULL)
  }
  x
}

cr2_analysis <- function(model, data, cluster_col = "debate_id", label = "") {
  cl <- data[[cluster_col]]
  if (any(is.na(cl))) stop("Missing cluster IDs in analysis: ", label)
  V <- clubSandwich::vcovCR(model, cluster = cl, type = "CR2")
  tests <- add_terms(clubSandwich::coef_test(model, vcov = V, test = "Satterthwaite"), model)
  if (all(c("beta", "SE", "df_Satt") %in% names(tests))) {
    crit <- qt(0.975, df = tests$df_Satt)
    tests$CI_low <- tests$beta - crit * tests$SE
    tests$CI_high <- tests$beta + crit * tests$SE
  } else {
    tests$CI_low <- NA_real_
    tests$CI_high <- NA_real_
  }
  tests$model <- label
  tests$N <- nobs(model)
  tests$clusters <- length(unique(cl))
  list(V = V, tests = tests, model = model)
}

extract_term <- function(obj, term) {
  obj$tests[obj$tests$term == term, , drop = FALSE]
}

cr2_tost_sensitivity <- function(model, data, cluster_col, term,
                                 bounds = EQUIV_BOUNDS_SD, alpha = EQUIV_ALPHA,
                                 label = "") {
  obj <- cr2_analysis(model, data, cluster_col, label)
  x <- extract_term(obj, term)
  if (nrow(x) != 1L) stop("TOST term not found uniquely: ", term, " in ", label)
  needed <- c("beta", "SE", "df_Satt")
  if (!all(needed %in% names(x))) stop("CR2 TOST requires beta, SE and df_Satt columns.")
  b <- as.numeric(x$beta[1]); se <- as.numeric(x$SE[1]); df <- as.numeric(x$df_Satt[1])
  if (!all(is.finite(c(b, se, df))) || se <= 0) stop("Invalid coefficient/SE/df for TOST: ", label)
  rows <- lapply(bounds, function(delta) {
    # H01: beta <= -delta versus beta > -delta
    t_lower <- (b + delta) / se
    p_lower <- 1 - pt(t_lower, df = df)
    # H02: beta >= +delta versus beta < +delta
    t_upper <- (b - delta) / se
    p_upper <- pt(t_upper, df = df)
    crit90 <- qt(1 - alpha, df = df)
    ci90_low <- b - crit90 * se
    ci90_high <- b + crit90 * se
    data.frame(
      analysis = label, term = term, estimate_std = b, SE_CR2 = se, df_Satt = df,
      SESOI_low = -delta, SESOI_high = delta,
      CI90_low = ci90_low, CI90_high = ci90_high,
      p_lower = p_lower, p_upper = p_upper, p_equivalence = max(p_lower, p_upper),
      equivalent_alpha_05 = (p_lower < alpha && p_upper < alpha),
      focal_bound_0_20 = isTRUE(all.equal(delta, 0.20)),
      N = nobs(model), clusters = length(unique(data[[cluster_col]])),
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

cr2_mean <- function(x, cluster, label) {
  d <- data.frame(y = as.numeric(x), debate_id = cluster)
  d <- d[complete.cases(d), , drop = FALSE]
  m <- lm(y ~ 1, data = d)
  out <- cr2_analysis(m, d, "debate_id", label)
  extract_term(out, "(Intercept)")
}

cr2_group_change <- function(change, condition, cluster, label) {
  d <- data.frame(change = as.numeric(change), condition = condition, debate_id = cluster)
  d <- d[complete.cases(d), , drop = FALSE]
  d$condition <- factor(d$condition, levels = c("Competition", "Cooperation"))
  m <- lm(change ~ condition, data = d)
  cr2_analysis(m, d, "debate_id", label)$tests
}

describe <- function(x, label, group = "All") {
  x <- as.numeric(x)
  ok <- is.finite(x)
  data.frame(
    variable = label,
    group = group,
    N = sum(ok),
    mean = if (any(ok)) mean(x[ok]) else NA_real_,
    SD = if (sum(ok) > 1L) sd(x[ok]) else NA_real_,
    median = if (any(ok)) median(x[ok]) else NA_real_,
    min = if (any(ok)) min(x[ok]) else NA_real_,
    max = if (any(ok)) max(x[ok]) else NA_real_,
    stringsAsFactors = FALSE
  )
}

score_distribution_diagnostics <- function(x, label, scale_min = 0, scale_max = 20) {
  x <- as.numeric(x)
  x <- x[is.finite(x)]
  if (!length(x)) return(data.frame())
  near_floor_cut <- scale_min + 0.10 * (scale_max - scale_min)
  near_ceiling_cut <- scale_max - 0.10 * (scale_max - scale_min)
  qs <- quantile(x, probs = c(.25, .50, .75), names = FALSE, na.rm = TRUE)
  data.frame(
    variable = label, N = length(x), mean = mean(x), SD = sd(x), variance = var(x),
    min = min(x), Q1 = qs[1], median = qs[2], Q3 = qs[3], max = max(x),
    n_at_floor = sum(x == scale_min), prop_at_floor = mean(x == scale_min),
    n_at_ceiling = sum(x == scale_max), prop_at_ceiling = mean(x == scale_max),
    near_floor_cut = near_floor_cut, n_near_floor = sum(x <= near_floor_cut), prop_near_floor = mean(x <= near_floor_cut),
    near_ceiling_cut = near_ceiling_cut, n_near_ceiling = sum(x >= near_ceiling_cut), prop_near_ceiling = mean(x >= near_ceiling_cut),
    stringsAsFactors = FALSE
  )
}

safe_max <- function(x) {
  x <- as.numeric(x)
  if (!any(is.finite(x))) return(NA_real_)
  max(x, na.rm = TRUE)
}

pitman_morgan <- function(pre, post, label) {
  d <- data.frame(pre = as.numeric(pre), post = as.numeric(post))
  d <- d[complete.cases(d), , drop = FALSE]
  s <- d$post + d$pre
  delta <- d$post - d$pre
  r <- cor(s, delta)
  n <- nrow(d)
  tval <- r * sqrt((n - 2) / pmax(1e-15, 1 - r^2))
  pval <- 2 * pt(-abs(tval), df = n - 2)
  vr <- var(d$post) / var(d$pre)
  data.frame(
    analysis = label, N = n,
    pre_variance = var(d$pre), post_variance = var(d$post),
    variance_ratio_post_over_pre = vr,
    percent_variance_change = 100 * (vr - 1),
    pitman_morgan_r = r, t = tval, df = n - 2, p = pval,
    stringsAsFactors = FALSE
  )
}

pearson_row <- function(x, y, label) {
  d <- data.frame(x = as.numeric(x), y = as.numeric(y))
  d <- d[complete.cases(d), , drop = FALSE]
  ct <- cor.test(d$x, d$y, method = "pearson")
  data.frame(
    analysis = label, N = nrow(d), r = unname(ct$estimate),
    CI95_low = ct$conf.int[1], CI95_high = ct$conf.int[2], p = ct$p.value,
    stringsAsFactors = FALSE
  )
}

cr2_coupling <- function(x, y, cluster, label) {
  d <- data.frame(x = as.numeric(x), y = as.numeric(y), debate_id = cluster)
  d <- d[complete.cases(d), , drop = FALSE]
  d$x_z <- z(d$x); d$y_z <- z(d$y)
  m <- lm(y_z ~ x_z, data = d)
  out <- cr2_analysis(m, d, "debate_id", label)
  extract_term(out, "x_z")
}

aggregate_evaluator <- function(d) {
  ids <- unique(d$evaluator_id)
  rows <- lapply(ids, function(id) {
    x <- d[d$evaluator_id == id, , drop = FALSE]
    own_k2 <- as.numeric(x$evaluator_knowledge_t2[1])
    partner_k2 <- as.numeric(x$evaluatee_knowledge_t2)
    max_partner_k2 <- safe_max(partner_k2)
    valid_partner_k2 <- partner_k2[is.finite(partner_k2)]
    n_more <- if (length(valid_partner_k2) && is.finite(own_k2)) sum(valid_partner_k2 > own_k2) else NA_real_
    prop_more <- if (length(valid_partner_k2) && is.finite(own_k2)) mean(valid_partner_k2 > own_k2) else NA_real_
    data.frame(
      participant_id = id,
      debate_id = x$debate_id[1],
      condition = x$condition[1],
      group_size = x$group_size[1],
      n_partners_rated = nrow(x),
      mean_human_expertise = safe_mean(x$perceived_expertise),
      mean_human_benevolence = safe_mean(x$perceived_benevolence),
      mean_partner_knowledge_t2 = safe_mean(partner_k2),
      max_partner_knowledge_t2 = max_partner_k2,
      max_partner_advantage_t2 = if (is.finite(max_partner_k2) && is.finite(own_k2)) max_partner_k2 - own_k2 else NA_real_,
      n_partners_more_knowledgeable = n_more,
      prop_partners_more_knowledgeable = prop_more,
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

cluster_boot_variance_contrast <- function(data, pre1, post1, pre2, post2,
                                           cluster_col = "debate_id", reps = 500L,
                                           seed = 1L, label = "") {
  vars <- c(cluster_col, pre1, post1, pre2, post2)
  d <- data[complete.cases(data[, vars]), vars, drop = FALSE]
  clusters <- unique(d[[cluster_col]])
  split_rows <- split(seq_len(nrow(d)), d[[cluster_col]])
  calc <- function(dd) {
    lr1 <- log(var(dd[[post1]]) / var(dd[[pre1]]))
    lr2 <- log(var(dd[[post2]]) / var(dd[[pre2]]))
    c(logVR_phase1 = lr1, logVR_phase2 = lr2, contrast_phase2_minus_phase1 = lr2 - lr1)
  }
  original <- calc(d)
  set.seed(seed)
  boot <- matrix(NA_real_, nrow = reps, ncol = 3)
  colnames(boot) <- names(original)
  for (b in seq_len(reps)) {
    sampled <- sample(names(split_rows), length(split_rows), replace = TRUE)
    idx <- unlist(split_rows[sampled], use.names = FALSE)
    bd <- d[idx, , drop = FALSE]
    boot[b, ] <- tryCatch(calc(bd), error = function(e) rep(NA_real_, 3))
  }
  valid <- apply(boot, 1, function(x) all(is.finite(x)))
  boot <- boot[valid, , drop = FALSE]
  ci <- apply(boot, 2, quantile, probs = c(.025, .975), na.rm = TRUE)
  data.frame(
    analysis = label,
    N = nrow(d), clusters = length(clusters),
    logVR_phase1 = original[1], logVR_phase2 = original[2],
    contrast_phase2_minus_phase1 = original[3],
    contrast_CI95_low = ci[1, 3], contrast_CI95_high = ci[2, 3],
    boot_reps_requested = reps, boot_reps_valid = nrow(boot),
    interpretation = "Positive contrast means phase 2 has a larger variance ratio (less convergence / more divergence) than phase 1.",
    stringsAsFactors = FALSE
  )
}

cluster_boot_specificity <- function(data, pre_k, post_k, pre_other, post_other,
                                     cluster_col = "debate_id", reps = 500L,
                                     seed = 1L, label = "") {
  vars <- c(cluster_col, pre_k, post_k, pre_other, post_other)
  d <- data[complete.cases(data[, vars]), vars, drop = FALSE]
  split_rows <- split(seq_len(nrow(d)), d[[cluster_col]])
  calc <- function(dd) {
    lk <- log(var(dd[[post_k]]) / var(dd[[pre_k]]))
    lo <- log(var(dd[[post_other]]) / var(dd[[pre_other]]))
    c(logVR_knowledge = lk, logVR_other = lo, knowledge_minus_other = lk - lo)
  }
  original <- calc(d)
  set.seed(seed)
  boot <- matrix(NA_real_, nrow = reps, ncol = 3)
  colnames(boot) <- names(original)
  for (b in seq_len(reps)) {
    sampled <- sample(names(split_rows), length(split_rows), replace = TRUE)
    idx <- unlist(split_rows[sampled], use.names = FALSE)
    boot[b, ] <- tryCatch(calc(d[idx, , drop = FALSE]), error = function(e) rep(NA_real_, 3))
  }
  valid <- apply(boot, 1, function(x) all(is.finite(x)))
  boot <- boot[valid, , drop = FALSE]
  ci <- quantile(boot[, 3], probs = c(.025, .975), na.rm = TRUE)
  data.frame(
    analysis = label, N = nrow(d), clusters = length(unique(d[[cluster_col]])),
    logVR_knowledge = original[1], logVR_other = original[2],
    knowledge_minus_other = original[3],
    CI95_low = ci[1], CI95_high = ci[2],
    boot_reps_requested = reps, boot_reps_valid = nrow(boot),
    interpretation = "Negative difference means knowledge converged more strongly than the comparison outcome.",
    stringsAsFactors = FALSE
  )
}

write_workbook <- function(path, sheets) {
  wb <- openxlsx::createWorkbook()
  header <- openxlsx::createStyle(
    fontColour = "#FFFFFF", fgFill = "#1F4E78", textDecoration = "bold",
    halign = "center", valign = "center", wrapText = TRUE
  )
  wrap <- openxlsx::createStyle(wrapText = TRUE, valign = "top")
  num_style <- openxlsx::createStyle(numFmt = "0.000")
  p_style <- openxlsx::createStyle(numFmt = "0.0000")
  for (nm in names(sheets)) {
    df <- as.data.frame(sheets[[nm]], check.names = FALSE, stringsAsFactors = FALSE)
    sh <- substr(nm, 1, 31)
    openxlsx::addWorksheet(wb, sh, gridLines = FALSE)
    if (ncol(df) == 0L) {
      openxlsx::writeData(wb, sh, "No output")
      next
    }
    if (nrow(df) == 0L) {
      openxlsx::writeData(wb, sh, as.list(names(df)), colNames = FALSE)
    } else {
      openxlsx::writeDataTable(wb, sh, df, tableStyle = "TableStyleMedium2", withFilter = TRUE)
    }
    openxlsx::addStyle(wb, sh, header, rows = 1, cols = seq_len(ncol(df)), gridExpand = TRUE)
    if (nrow(df) > 0L) {
      openxlsx::addStyle(wb, sh, wrap, rows = 2:(nrow(df) + 1L), cols = seq_len(ncol(df)), gridExpand = TRUE, stack = TRUE)
      numeric_cols <- which(vapply(df, is.numeric, logical(1)))
      p_cols <- grep("(^p$|^q$|p_|p\\.|p_Satt|q_BH|CI95)", names(df), ignore.case = TRUE)
      if (length(numeric_cols)) openxlsx::addStyle(wb, sh, num_style, rows = 2:(nrow(df)+1L), cols = numeric_cols, gridExpand = TRUE, stack = TRUE)
      if (length(p_cols)) openxlsx::addStyle(wb, sh, p_style, rows = 2:(nrow(df)+1L), cols = p_cols, gridExpand = TRUE, stack = TRUE)
    }
    openxlsx::freezePane(wb, sh, firstActiveRow = 2)
    widths <- vapply(seq_len(ncol(df)), function(j) {
      vals <- c(names(df)[j], as.character(df[[j]])); vals <- vals[!is.na(vals)]
      mx <- if (length(vals)) max(nchar(vals)) else 10
      max(10, min(42, mx + 2))
    }, numeric(1))
    openxlsx::setColWidths(wb, sh, seq_len(ncol(df)), widths)
  }
  openxlsx::saveWorkbook(wb, path, overwrite = TRUE)
}

# 3. Import and structural QC --------------------------------------------------
p <- read.csv(PARTICIPANT_FILE, check.names = FALSE, na.strings = c("", "NA"), fileEncoding = "UTF-8")
d <- read.csv(DYAD_FILE, check.names = FALSE, na.strings = c("", "NA"), fileEncoding = "UTF-8")

participant_required <- c(
  "participant_id", "debate_id", "condition", "group_size", "family_ses",
  "knowledge_t1", "knowledge_t2", "knowledge_t3",
  "subjective_knowledge_t1", "subjective_knowledge_t2", "subjective_knowledge_t3",
  "attitude_total_t1", "attitude_total_t2", "attitude_total_t3",
  "attitude_ssa_t1", "attitude_ssa_t2", "attitude_ssa_t3",
  "attitude_vahc_t1", "attitude_vahc_t2", "attitude_vahc_t3",
  "attitude_vasa_t1", "attitude_vasa_t2", "attitude_vasa_t3",
  "attitude_ep_t1", "attitude_ep_t2", "attitude_ep_t3",
  "sources_recalled", "web_source_expertise", "web_source_benevolence"
)
dyad_required <- c(
  "evaluator_id", "evaluatee_id", "debate_id", "condition", "group_size", "familiarity",
  "evaluator_knowledge_t2", "evaluatee_knowledge_t2", "perceived_expertise", "perceived_benevolence"
)
assert_qc(all(participant_required %in% names(p)), "participant file missing required columns")
assert_qc(all(dyad_required %in% names(d)), "dyad file missing required columns")
assert_qc(nrow(p) == 96L, "participant table must have 96 rows")
assert_qc(length(unique(p$participant_id)) == 96L, "participant IDs must be unique")
assert_qc(length(unique(p$debate_id)) == 34L, "participant table must contain 34 debate clusters")
assert_qc(sum(p$condition == "Competition") == 47L, "expected 47 Competition participants")
assert_qc(sum(p$condition == "Cooperation") == 49L, "expected 49 Cooperation participants")
assert_qc(nrow(d) == 212L, "dyad table must contain 212 ordered dyads")
assert_qc(length(unique(d$evaluator_id)) == 91L, "expected 91 dyadic evaluators")
assert_qc(length(unique(d$debate_id)) == 29L, "expected 29 dyadic debate clusters")
assert_qc(!any(d$evaluator_id == d$evaluatee_id), "self-evaluation dyads are not allowed")
assert_qc(all(d$evaluator_id %in% p$participant_id), "all evaluators must link to participant table")
assert_qc(all(d$evaluatee_id %in% p$participant_id), "all evaluatees must link to participant table")
assert_qc(all(p$condition %in% c("Competition", "Cooperation")), "unexpected participant condition")
assert_qc(all(d$condition %in% c("Competition", "Cooperation")), "unexpected dyad condition")

for (v in c("knowledge_t1", "knowledge_t2", "knowledge_t3")) {
  assert_qc(all(p[[v]] >= 0 & p[[v]] <= 20, na.rm = TRUE), paste(v, "outside 0-20"))
}
for (v in c("subjective_knowledge_t1", "subjective_knowledge_t2", "subjective_knowledge_t3")) {
  assert_qc(all(p[[v]] >= 1 & p[[v]] <= 4, na.rm = TRUE), paste(v, "outside 1-4"))
}
# Canonical attitude totals equal the sum of the four canonical subscales at each time.
for (tt in c("t1", "t2", "t3")) {
  total <- p[[paste0("attitude_total_", tt)]]
  parts <- p[[paste0("attitude_ssa_", tt)]] + p[[paste0("attitude_vahc_", tt)]] +
           p[[paste0("attitude_vasa_", tt)]] + p[[paste0("attitude_ep_", tt)]]
  assert_qc(all(abs(total - parts) < 1e-8, na.rm = TRUE), paste("attitude subscales do not sum to total at", tt))
}

# Canonical signed attitude totals must remain within the theoretical stored
# range implied by the four signed subscales. This guard prevents future
# floor/ceiling diagnostics from silently using an incompatible scale.
for (tt in c("t1", "t2", "t3")) {
  total <- p[[paste0("attitude_total_", tt)]]
  assert_qc(
    all(total >= ATTITUDE_TOTAL_MIN & total <= ATTITUDE_TOTAL_MAX, na.rm = TRUE),
    paste("attitude total outside theoretical canonical range at", tt)
  )
}

p$condition <- factor(p$condition, levels = c("Competition", "Cooperation"))
d$condition <- factor(d$condition, levels = c("Competition", "Cooperation"))

# Linkage checks against participant table.
lookup_k2 <- setNames(p$knowledge_t2, p$participant_id)
assert_qc(all(abs(d$evaluator_knowledge_t2 - lookup_k2[d$evaluator_id]) < 1e-8), "dyad evaluator T2 mismatch")
assert_qc(all(abs(d$evaluatee_knowledge_t2 - lookup_k2[d$evaluatee_id]) < 1e-8), "dyad evaluatee T2 mismatch")
lookup_cond <- setNames(as.character(p$condition), p$participant_id)
assert_qc(all(as.character(d$condition) == lookup_cond[d$evaluator_id]), "dyad/participant condition mismatch")

QC <- data.frame(
  check = c(
    "Participant rows", "Participant debate clusters", "Competition participants", "Cooperation participants",
    "Missing family SES", "Missing Web expertise", "Missing Web benevolence",
    "Dyad rows", "Dyad evaluators", "Dyad debate clusters", "Missing dyad perceived expertise",
    "Missing dyad perceived benevolence", "Self dyads", "Attitude total/subscale identity"
  ),
  value = c(
    nrow(p), length(unique(p$debate_id)), sum(p$condition == "Competition"), sum(p$condition == "Cooperation"),
    sum(is.na(p$family_ses)), sum(is.na(p$web_source_expertise)), sum(is.na(p$web_source_benevolence)),
    nrow(d), length(unique(d$evaluator_id)), length(unique(d$debate_id)), sum(is.na(d$perceived_expertise)),
    sum(is.na(d$perceived_benevolence)), sum(d$evaluator_id == d$evaluatee_id), 1
  ),
  expected = c("96", "34", "47", "49", "1", "4", "4", "212", "91", "29", "16", "0", "0", "verified at T1/T2/T3"),
  stringsAsFactors = FALSE
)

# Condition assignment was operational (by participant enrollment/entry order), not
# simple randomization. Debate-group composition additionally used T1 attitude
# positions to favor within-group heterogeneity where feasible. The following
# baseline checks are descriptive diagnostics; they do not establish exchangeability.
Design_Notes <- data.frame(
  topic = c("Condition assignment", "Debate-group composition", "Interpretation"),
  note = c(
    "Cooperation/Competition assignment was implemented operationally according to participant enrollment/entry order; it was not a simple randomized allocation.",
    "Within practical constraints, T1 attitude positions were used when composing debate groups to favor heterogeneous initial positions and make substantive disagreement possible.",
    "Baseline balance checks are descriptive diagnostics only and do not convert the design into a randomized experiment. Because environment type and sequence position are perfectly confounded, no statistical adjustment identifies an order-independent document-versus-interaction effect."
  ), stringsAsFactors = FALSE
)

balance_vars <- c(
  knowledge_t1 = "Factual knowledge T1",
  subjective_knowledge_t1 = "Subjective knowledge T1",
  attitude_total_t1 = "Attitude total T1",
  attitude_ssa_t1 = "Attitude SSA T1",
  attitude_vahc_t1 = "Attitude VAHC T1",
  attitude_vasa_t1 = "Attitude VASA T1",
  attitude_ep_t1 = "Attitude EP T1",
  family_ses = "Family SES"
)
Baseline_Balance_Descriptives <- do.call(rbind, lapply(names(balance_vars), function(v) {
  bind_fill(
    describe(p[[v]][p$condition == "Competition"], balance_vars[[v]], "Competition"),
    describe(p[[v]][p$condition == "Cooperation"], balance_vars[[v]], "Cooperation")
  )
}))
Baseline_Balance_CR2 <- do.call(bind_fill, lapply(names(balance_vars), function(v) {
  dd <- p[complete.cases(p[, c(v, "condition", "debate_id")]), c(v, "condition", "debate_id"), drop = FALSE]
  names(dd)[1] <- "y"
  dd$y_z <- z(dd$y)
  mm <- lm(y_z ~ condition, data = dd)
  oo <- cr2_analysis(mm, dd, "debate_id", paste0("Baseline balance: ", balance_vars[[v]]))
  rr <- extract_term(oo, "conditionCooperation")
  rr$variable <- balance_vars[[v]]
  rr$interpretation <- "Standardized Cooperation-minus-Competition difference; diagnostic only, not a randomization test."
  rr
}))

# 4. Derived variables ---------------------------------------------------------
p$delta_k_ri <- p$knowledge_t2 - p$knowledge_t1
p$delta_k_global <- p$knowledge_t3 - p$knowledge_t1
p$delta_k_debate <- p$knowledge_t3 - p$knowledge_t2
p$delta_k_phase_contrast <- p$delta_k_debate - p$delta_k_ri
p$abs_delta_k_ri <- abs(p$delta_k_ri)
p$abs_delta_k_debate <- abs(p$delta_k_debate)

p$delta_s_ri <- p$subjective_knowledge_t2 - p$subjective_knowledge_t1
p$delta_s_global <- p$subjective_knowledge_t3 - p$subjective_knowledge_t1
p$delta_s_debate <- p$subjective_knowledge_t3 - p$subjective_knowledge_t2
p$delta_s_phase_contrast <- p$delta_s_debate - p$delta_s_ri
p$abs_delta_s_ri <- abs(p$delta_s_ri)
p$abs_delta_s_global <- abs(p$delta_s_global)
p$abs_delta_s_debate <- abs(p$delta_s_debate)

p$delta_a_ri <- p$attitude_total_t2 - p$attitude_total_t1
p$delta_a_global <- p$attitude_total_t3 - p$attitude_total_t1
p$delta_a_debate <- p$attitude_total_t3 - p$attitude_total_t2
p$delta_a_phase_contrast <- p$delta_a_debate - p$delta_a_ri
p$abs_delta_a_ri <- abs(p$delta_a_ri)
p$abs_delta_a_global <- abs(p$delta_a_global)
p$abs_delta_a_debate <- abs(p$delta_a_debate)

for (ss in c("ssa", "vahc", "vasa", "ep")) {
  p[[paste0("delta_", ss, "_ri")]] <- p[[paste0("attitude_", ss, "_t2")]] - p[[paste0("attitude_", ss, "_t1")]]
  p[[paste0("delta_", ss, "_global")]] <- p[[paste0("attitude_", ss, "_t3")]] - p[[paste0("attitude_", ss, "_t1")]]
  p[[paste0("delta_", ss, "_debate")]] <- p[[paste0("attitude_", ss, "_t3")]] - p[[paste0("attitude_", ss, "_t2")]]
  p[[paste0("delta_", ss, "_contrast")]] <- p[[paste0("delta_", ss, "_debate")]] - p[[paste0("delta_", ss, "_ri")]]
}

# Web epistemic-credit composite.
web_ok <- complete.cases(p[, c("web_source_expertise", "web_source_benevolence")])
p$web_expertise_z <- NA_real_; p$web_benevolence_z <- NA_real_; p$web_credit <- NA_real_
p$web_expertise_z[web_ok] <- z(p$web_source_expertise[web_ok])
p$web_benevolence_z[web_ok] <- z(p$web_source_benevolence[web_ok])
p$web_credit[web_ok] <- rowMeans(cbind(p$web_expertise_z[web_ok], p$web_benevolence_z[web_ok]))
p$web_credit_z <- z(p$web_credit)

# Human evaluator aggregates and credit composite.
eval_agg <- aggregate_evaluator(d)
eval_ok <- complete.cases(eval_agg[, c("mean_human_expertise", "mean_human_benevolence")])
eval_agg$human_expertise_z <- NA_real_; eval_agg$human_benevolence_z <- NA_real_; eval_agg$human_credit <- NA_real_
eval_agg$human_expertise_z[eval_ok] <- z(eval_agg$mean_human_expertise[eval_ok])
eval_agg$human_benevolence_z[eval_ok] <- z(eval_agg$mean_human_benevolence[eval_ok])
eval_agg$human_credit[eval_ok] <- rowMeans(cbind(eval_agg$human_expertise_z[eval_ok], eval_agg$human_benevolence_z[eval_ok]))
eval_agg$human_credit_z <- z(eval_agg$human_credit)

p <- merge(p, eval_agg[, c("participant_id", "n_partners_rated", "mean_human_expertise", "mean_human_benevolence",
                            "human_expertise_z", "human_benevolence_z", "human_credit", "human_credit_z",
                            "mean_partner_knowledge_t2", "max_partner_knowledge_t2", "max_partner_advantage_t2",
                            "n_partners_more_knowledgeable", "prop_partners_more_knowledgeable")],
           by = "participant_id", all.x = TRUE, sort = FALSE)
# Restore stable public-ID order.
p <- p[order(p$participant_id), , drop = FALSE]

# Calibration variables: standardize objective and subjective knowledge separately at each occasion.
for (tt in c("t1", "t2", "t3")) {
  kd <- z(p[[paste0("knowledge_", tt)]])
  ks <- z(p[[paste0("subjective_knowledge_", tt)]])
  p[[paste0("z_k_", tt)]] <- kd
  p[[paste0("z_s_", tt)]] <- ks
  p[[paste0("calibration_error_", tt)]] <- abs(ks - kd)
  p[[paste0("calibration_bias_", tt)]] <- ks - kd
}
p$calibration_error_change_debate <- p$calibration_error_t3 - p$calibration_error_t2

# 5. H1 — Factual trajectory ---------------------------------------------------
# The common-baseline T1->T3 analysis is added to show whether the factual gain
# and score homogenization observed by T2 remain visible at the end of the full
# protocol. T2->T3 remains the incremental second-period change.
H1_Descriptives <- bind_fill(
  describe(p$knowledge_t1, "Knowledge T1"),
  describe(p$knowledge_t2, "Knowledge T2"),
  describe(p$knowledge_t3, "Knowledge T3"),
  describe(p$delta_k_ri, "Knowledge change T1->T2"),
  describe(p$delta_k_global, "Knowledge change T1->T3"),
  describe(p$delta_k_debate, "Incremental knowledge change T2->T3"),
  describe(p$delta_k_phase_contrast, "T2->T3 change minus T1->T2 change")
)
H1_RI_Change <- cr2_mean(p$delta_k_ri, p$debate_id, "H1a factual change T1->T2")
H1_Global_Change <- cr2_mean(p$delta_k_global, p$debate_id, "H1a2 common-baseline factual change T1->T3")
H1_Debate_Change <- cr2_mean(p$delta_k_debate, p$debate_id, "H1b incremental factual change T2->T3")
H1_Phase_Contrast <- cr2_mean(p$delta_k_phase_contrast, p$debate_id, "H1c direct within-participant phase contrast")
H1_Common_Baseline <- bind_fill(H1_RI_Change, H1_Global_Change, H1_Debate_Change)
H1_Dispersion <- rbind(
  pitman_morgan(p$knowledge_t1, p$knowledge_t2, "H1d factual dispersion T1->T2"),
  pitman_morgan(p$knowledge_t1, p$knowledge_t3, "H1d common-baseline factual dispersion T1->T3"),
  pitman_morgan(p$knowledge_t2, p$knowledge_t3, "H1d incremental factual dispersion T2->T3")
)
H1_Distribution_Diagnostics <- bind_fill(
  score_distribution_diagnostics(p$knowledge_t1, "Knowledge T1"),
  score_distribution_diagnostics(p$knowledge_t2, "Knowledge T2"),
  score_distribution_diagnostics(p$knowledge_t3, "Knowledge T3")
)
H1_Reliability_Status <- data.frame(
  measure = "20-item factual-knowledge inventory",
  status = "Internal-consistency reliability cannot be estimated from the minimized Article 3 public participant dataset because it contains total scores only, not item-level responses.",
  interpretation = "Distribution diagnostics are reported at T1/T2/T3. If item-level response data are later added to the analytic environment, reliability can be estimated separately without changing the main score analyses.",
  stringsAsFactors = FALSE
)

# Continuity: standardized pre->post slopes compared directly across phases.
long_k <- rbind(
  data.frame(participant_id = p$participant_id, debate_id = p$debate_id, condition = p$condition,
             phase = "RI", pre = p$knowledge_t1, post = p$knowledge_t2),
  data.frame(participant_id = p$participant_id, debate_id = p$debate_id, condition = p$condition,
             phase = "Debate", pre = p$knowledge_t2, post = p$knowledge_t3)
)
long_k$phase <- factor(long_k$phase, levels = c("RI", "Debate"))
# Standardize within phase to compare pre-post continuity rather than raw scale dispersion.
long_k$pre_z <- ave(long_k$pre, long_k$phase, FUN = z)
long_k$post_z <- ave(long_k$post, long_k$phase, FUN = z)
mk_cont <- lm(post_z ~ pre_z * phase, data = long_k)
H1_Continuity <- cr2_analysis(mk_cont, long_k, "debate_id", "H1 standardized pre-post continuity by phase")$tests

# Bounded positive-gain sensitivity for debate, retained from Article 2 logic.
H1_Debate_Sensitivity <- do.call(rbind, lapply(c(.10, .25, .50, 1.00), function(bound) {
  d0 <- data.frame(change = p$delta_k_debate, debate_id = p$debate_id)
  d0 <- d0[complete.cases(d0), , drop = FALSE]
  m0 <- lm(change ~ 1, data = d0)
  fit <- cr2_analysis(m0, d0, "debate_id", "H1 debate-recall-evaluation positive-gain sensitivity")
  tt <- extract_term(fit, "(Intercept)")
  est <- tt$beta[1]; se <- tt$SE[1]; df <- tt$df_Satt[1]
  t_stat <- (est - bound) / se
  data.frame(candidate_positive_gain = bound, estimate = est, CR2_SE = se, df_Satt = df,
             t_vs_bound = t_stat, p_one_sided = pt(t_stat, df = df),
             stringsAsFactors = FALSE)
}))

# 6. H2 — Full subjective and attitudinal trajectories -------------------------
# H2 now mirrors the H1 temporal logic. For each non-factual outcome we report:
#   (1) T1->T2 first-period change,
#   (2) T1->T3 common-baseline end-of-protocol change, and
#   (3) T2->T3 incremental second-period change.
# The adjacent-period contrast is retained as a direct within-person comparison,
# but because sequence order is fixed it is not an order-independent causal effect.
H2_Change_Descriptives <- bind_fill(
  describe(p$delta_k_ri, "Factual change T1->T2"),
  describe(p$delta_k_global, "Factual change T1->T3"),
  describe(p$delta_k_debate, "Factual change T2->T3"),
  describe(p$delta_s_ri, "Subjective change T1->T2"),
  describe(p$delta_s_global, "Subjective change T1->T3"),
  describe(p$delta_s_debate, "Subjective change T2->T3"),
  describe(p$delta_a_ri, "Attitude change T1->T2"),
  describe(p$delta_a_global, "Attitude change T1->T3"),
  describe(p$delta_a_debate, "Attitude change T2->T3")
)

H2_Mean_Changes <- bind_fill(
  cr2_mean(p$delta_s_ri, p$debate_id, "H2 subjective change T1->T2"),
  cr2_mean(p$delta_s_global, p$debate_id, "H2 subjective change T1->T3"),
  cr2_mean(p$delta_s_debate, p$debate_id, "H2 subjective change T2->T3"),
  cr2_mean(p$delta_s_phase_contrast, p$debate_id, "H2 subjective adjacent-period contrast: T2->T3 minus T1->T2"),
  cr2_mean(p$delta_a_ri, p$debate_id, "H2 attitude change T1->T2"),
  cr2_mean(p$delta_a_global, p$debate_id, "H2 attitude change T1->T3"),
  cr2_mean(p$delta_a_debate, p$debate_id, "H2 attitude change T2->T3"),
  cr2_mean(p$delta_a_phase_contrast, p$debate_id, "H2 attitude adjacent-period contrast: T2->T3 minus T1->T2")
)

# Absolute amplitude of within-person reconfiguration.
H2_Amplitude <- bind_fill(
  cr2_mean(p$abs_delta_k_debate - p$abs_delta_k_ri, p$debate_id, "H2 amplitude contrast factual: debate minus RI"),
  cr2_mean(p$abs_delta_s_debate - p$abs_delta_s_ri, p$debate_id, "H2 amplitude contrast subjective: debate minus RI"),
  cr2_mean(p$abs_delta_a_debate - p$abs_delta_a_ri, p$debate_id, "H2 amplitude contrast attitude: debate minus RI")
)

# Dispersion mirrors H1: T1->T2, common-baseline T1->T3, and incremental T2->T3.
H2_Dispersion <- rbind(
  pitman_morgan(p$subjective_knowledge_t1, p$subjective_knowledge_t2, "Subjective dispersion T1->T2"),
  pitman_morgan(p$subjective_knowledge_t1, p$subjective_knowledge_t3, "Subjective dispersion T1->T3"),
  pitman_morgan(p$subjective_knowledge_t2, p$subjective_knowledge_t3, "Subjective dispersion T2->T3"),
  pitman_morgan(p$attitude_total_t1, p$attitude_total_t2, "Attitude dispersion T1->T2"),
  pitman_morgan(p$attitude_total_t1, p$attitude_total_t3, "Attitude dispersion T1->T3"),
  pitman_morgan(p$attitude_total_t2, p$attitude_total_t3, "Attitude dispersion T2->T3")
)

# Distribution diagnostics are shown at all three occasions, using the known
# theoretical ranges of the stored scores. For the canonical signed attitude
# total, the correct stored-score range is -42 to +22 (not -32 to +32).
H2_Distribution_Diagnostics <- bind_fill(
  score_distribution_diagnostics(p$subjective_knowledge_t1, "Subjective knowledge T1", 1, 4),
  score_distribution_diagnostics(p$subjective_knowledge_t2, "Subjective knowledge T2", 1, 4),
  score_distribution_diagnostics(p$subjective_knowledge_t3, "Subjective knowledge T3", 1, 4),
  score_distribution_diagnostics(p$attitude_total_t1, "Attitude total T1", ATTITUDE_TOTAL_MIN, ATTITUDE_TOTAL_MAX),
  score_distribution_diagnostics(p$attitude_total_t2, "Attitude total T2", ATTITUDE_TOTAL_MIN, ATTITUDE_TOTAL_MAX),
  score_distribution_diagnostics(p$attitude_total_t3, "Attitude total T3", ATTITUDE_TOTAL_MIN, ATTITUDE_TOTAL_MAX)
)

# Attitude subscales: T1->T2, T1->T3, T2->T3, plus adjacent-period contrast.
# BH correction is performed separately within each family of four subscales.
subscales <- c("ssa", "vahc", "vasa", "ep")
H2_Attitude_Subscales <- do.call(rbind, lapply(subscales, function(ss) {
  t12 <- cr2_mean(p[[paste0("delta_", ss, "_ri")]], p$debate_id, paste0("Attitude ", toupper(ss), " T1->T2"))
  t13 <- cr2_mean(p[[paste0("delta_", ss, "_global")]], p$debate_id, paste0("Attitude ", toupper(ss), " T1->T3"))
  t23 <- cr2_mean(p[[paste0("delta_", ss, "_debate")]], p$debate_id, paste0("Attitude ", toupper(ss), " T2->T3"))
  co <- cr2_mean(p[[paste0("delta_", ss, "_contrast")]], p$debate_id, paste0("Attitude ", toupper(ss), " adjacent-period contrast"))
  t12$subscale <- ss; t12$test_family <- "T1->T2 change"
  t13$subscale <- ss; t13$test_family <- "T1->T3 change"
  t23$subscale <- ss; t23$test_family <- "T2->T3 change"
  co$subscale <- ss; co$test_family <- "Adjacent-period contrast"
  bind_fill(t12, t13, t23, co)
}))
pcol <- if ("p_Satt" %in% names(H2_Attitude_Subscales)) "p_Satt" else if ("p_val" %in% names(H2_Attitude_Subscales)) "p_val" else "p"
H2_Attitude_Subscales$q_BH <- ave(H2_Attitude_Subscales[[pcol]], H2_Attitude_Subscales$test_family,
                                  FUN = function(x) p.adjust(x, method = "BH"))

# Coupling among changes: descriptive Pearson r + cluster-robust standardized slopes.
H2_Coupling_Descriptive <- bind_fill(
  pearson_row(p$delta_k_ri, p$delta_s_ri, "T1->T2: factual vs subjective change"),
  pearson_row(p$delta_k_ri, p$delta_a_ri, "T1->T2: factual vs attitude change"),
  pearson_row(p$delta_s_ri, p$delta_a_ri, "T1->T2: subjective vs attitude change"),
  pearson_row(p$delta_k_global, p$delta_s_global, "T1->T3: factual vs subjective change"),
  pearson_row(p$delta_k_global, p$delta_a_global, "T1->T3: factual vs attitude change"),
  pearson_row(p$delta_s_global, p$delta_a_global, "T1->T3: subjective vs attitude change"),
  pearson_row(p$delta_k_debate, p$delta_s_debate, "T2->T3: factual vs subjective change"),
  pearson_row(p$delta_k_debate, p$delta_a_debate, "T2->T3: factual vs attitude change"),
  pearson_row(p$delta_s_debate, p$delta_a_debate, "T2->T3: subjective vs attitude change")
)
H2_Coupling_CR2 <- bind_fill(
  cr2_coupling(p$delta_k_ri, p$delta_s_ri, p$debate_id, "T1->T2 factual -> subjective change"),
  cr2_coupling(p$delta_k_ri, p$delta_a_ri, p$debate_id, "T1->T2 factual -> attitude change"),
  cr2_coupling(p$delta_s_ri, p$delta_a_ri, p$debate_id, "T1->T2 subjective -> attitude change"),
  cr2_coupling(p$delta_k_global, p$delta_s_global, p$debate_id, "T1->T3 factual -> subjective change"),
  cr2_coupling(p$delta_k_global, p$delta_a_global, p$debate_id, "T1->T3 factual -> attitude change"),
  cr2_coupling(p$delta_s_global, p$delta_a_global, p$debate_id, "T1->T3 subjective -> attitude change"),
  cr2_coupling(p$delta_k_debate, p$delta_s_debate, p$debate_id, "T2->T3 factual -> subjective change"),
  cr2_coupling(p$delta_k_debate, p$delta_a_debate, p$debate_id, "T2->T3 factual -> attitude change"),
  cr2_coupling(p$delta_s_debate, p$delta_a_debate, p$debate_id, "T2->T3 subjective -> attitude change")
)

# Secondary equivalence sensitivity for the nine standardized change couplings.
# These are not confirmatory equivalence tests; they indicate which effect-size
# bounds are compatible with practical-negligibility claims.
cr2_coupling_tost <- function(x, y, cluster, label) {
  dd <- data.frame(x = as.numeric(x), y = as.numeric(y), debate_id = cluster)
  dd <- dd[complete.cases(dd), , drop = FALSE]
  dd$x_z <- z(dd$x); dd$y_z <- z(dd$y)
  mm <- lm(y_z ~ x_z, data = dd)
  cr2_tost_sensitivity(mm, dd, "debate_id", "x_z", label = label)
}
H2_Coupling_Equivalence <- bind_fill(
  cr2_coupling_tost(p$delta_k_ri, p$delta_s_ri, p$debate_id, "T1->T2 factual -> subjective change"),
  cr2_coupling_tost(p$delta_k_ri, p$delta_a_ri, p$debate_id, "T1->T2 factual -> attitude change"),
  cr2_coupling_tost(p$delta_s_ri, p$delta_a_ri, p$debate_id, "T1->T2 subjective -> attitude change"),
  cr2_coupling_tost(p$delta_k_global, p$delta_s_global, p$debate_id, "T1->T3 factual -> subjective change"),
  cr2_coupling_tost(p$delta_k_global, p$delta_a_global, p$debate_id, "T1->T3 factual -> attitude change"),
  cr2_coupling_tost(p$delta_s_global, p$delta_a_global, p$debate_id, "T1->T3 subjective -> attitude change"),
  cr2_coupling_tost(p$delta_k_debate, p$delta_s_debate, p$debate_id, "T2->T3 factual -> subjective change"),
  cr2_coupling_tost(p$delta_k_debate, p$delta_a_debate, p$debate_id, "T2->T3 factual -> attitude change"),
  cr2_coupling_tost(p$delta_s_debate, p$delta_a_debate, p$debate_id, "T2->T3 subjective -> attitude change")
)

# 7. H3 — Documentary vs human credit and self-calibration -------------------
# Long source table: two rows per eligible participant, Web and Human.
source_long <- rbind(
  data.frame(participant_id = p$participant_id, debate_id = p$debate_id, condition = p$condition,
             source_type = "Web", expertise_z = p$web_expertise_z,
             benevolence_z = p$web_benevolence_z, credit_z = p$web_credit_z,
             sources_recalled_z = z(p$sources_recalled)),
  data.frame(participant_id = p$participant_id, debate_id = p$debate_id, condition = p$condition,
             source_type = "Human", expertise_z = p$human_expertise_z,
             benevolence_z = p$human_benevolence_z, credit_z = p$human_credit_z,
             sources_recalled_z = z(p$sources_recalled))
)
source_long$source_type <- factor(source_long$source_type, levels = c("Web", "Human"))
source_long$condition <- factor(source_long$condition, levels = c("Competition", "Cooperation"))

H3_Source_Descriptives <- bind_fill(
  describe(source_long$credit_z[source_long$source_type == "Web"], "Credit", "Web"),
  describe(source_long$credit_z[source_long$source_type == "Human"], "Credit", "Human"),
  describe(source_long$expertise_z[source_long$source_type == "Web"], "Expertise", "Web"),
  describe(source_long$expertise_z[source_long$source_type == "Human"], "Expertise", "Human"),
  describe(source_long$benevolence_z[source_long$source_type == "Web"], "Benevolence", "Web"),
  describe(source_long$benevolence_z[source_long$source_type == "Human"], "Benevolence", "Human")
)

fit_source_interaction <- function(outcome, label) {
  dd <- source_long[complete.cases(source_long[, c(outcome, "source_type", "condition", "debate_id")]), , drop = FALSE]
  m <- lm(as.formula(paste0(outcome, " ~ source_type * condition")), data = dd)
  cr2_analysis(m, dd, "debate_id", label)$tests
}
H3_Source_Credit <- fit_source_interaction("credit_z", "H3 Source type x condition: composite credit")
H3_Source_Expertise <- fit_source_interaction("expertise_z", "H3 Source type x condition: expertise")
H3_Source_Benevolence <- fit_source_interaction("benevolence_z", "H3 Source type x condition: benevolence")

# H3 robustness: account for how many Web sources each participant recalled.
# This does not treat source selection as a nuisance to be eliminated; free source
# selection is part of the ecological structure of Web search. The adjustment asks
# only whether the source-type x condition result is robust to individual variation
# in the number of recalled Web sources.
h3sens <- source_long[complete.cases(source_long[, c("credit_z", "source_type", "condition", "sources_recalled_z", "debate_id")]), , drop = FALSE]
h3sens_m1 <- lm(credit_z ~ source_type * condition + sources_recalled_z, data = h3sens)
H3_Source_Credit_Sens_NSources <- cr2_analysis(h3sens_m1, h3sens, "debate_id",
  "H3 sensitivity: source type x condition + number of Web sources recalled")$tests
h3sens_m2 <- lm(credit_z ~ source_type * condition + source_type * sources_recalled_z, data = h3sens)
H3_Source_Credit_Sens_NSources_Interaction <- cr2_analysis(h3sens_m2, h3sens, "debate_id",
  "H3 sensitivity: source type x condition + source type x number of Web sources recalled")$tests

# Explicit within-participant Human - Web change, overall and by condition.
credit_change <- p$human_credit_z - p$web_credit_z
expertise_change <- p$human_expertise_z - p$web_expertise_z
benevolence_change <- p$human_benevolence_z - p$web_benevolence_z
H3_Source_Within <- bind_fill(
  cr2_mean(credit_change, p$debate_id, "Human minus Web composite credit: overall"),
  cr2_group_change(credit_change, p$condition, p$debate_id, "Human minus Web composite credit by condition"),
  cr2_mean(expertise_change, p$debate_id, "Human minus Web expertise: overall"),
  cr2_group_change(expertise_change, p$condition, p$debate_id, "Human minus Web expertise by condition"),
  cr2_mean(benevolence_change, p$debate_id, "Human minus Web benevolence: overall"),
  cr2_group_change(benevolence_change, p$condition, p$debate_id, "Human minus Web benevolence by condition")
)

# Longitudinal self-calibration.
calib_d <- p[complete.cases(p[, c("calibration_error_t2", "calibration_error_t3", "condition", "debate_id")]), , drop = FALSE]
calib_m <- lm(calibration_error_t3 ~ calibration_error_t2 + condition, data = calib_d)
H3_Calibration_Longitudinal <- cr2_analysis(calib_m, calib_d, "debate_id", "H3 calibration T3 controlling T2")$tests
H3_Calibration_Change <- cr2_group_change(p$calibration_error_change_debate, p$condition, p$debate_id,
                                           "H3 raw calibration-error change T2->T3 by condition")
# Objective-subjective diagnosticity at T3.
h3s <- p[complete.cases(p[, c("z_k_t3", "z_s_t3", "condition", "debate_id")]), , drop = FALSE]
h3s_m <- lm(z_s_t3 ~ z_k_t3 * condition, data = h3s)
H3_T3_Diagnosticity <- cr2_analysis(h3s_m, h3s, "debate_id", "H3 T3 objective x condition -> subjective")$tests

# 8. C1 — Complementary CAVL test: expertise-dependent Web-source credit ------
h4 <- p[complete.cases(p[, c("knowledge_t2", "knowledge_t1", "web_credit_z", "family_ses", "condition", "debate_id")]), , drop = FALSE]
h4$t1_z <- z(h4$knowledge_t1)
h4$ses_z <- z(h4$family_ses)
h4_m <- lm(knowledge_t2 ~ t1_z * web_credit_z + ses_z + condition, data = h4)
C1_Web_Credit <- cr2_analysis(h4_m, h4, "debate_id", "C1 T1 expertise x Web credit -> T2")$tests

# Simple slopes of Web credit at T1 = -1, 0, +1 SD by re-centering T1.
C1_Simple_Slopes <- do.call(rbind, lapply(c(-1, 0, 1), function(level) {
  dd <- h4
  dd$t1_center <- dd$t1_z - level
  mm <- lm(knowledge_t2 ~ t1_center * web_credit_z + ses_z + condition, data = dd)
  oo <- cr2_analysis(mm, dd, "debate_id", paste0("C1 Web-credit slope at T1 z=", level))
  rr <- extract_term(oo, "web_credit_z")
  rr$t1_z_level <- level
  rr
}))

# Component decomposition (secondary; BH over two interaction tests).
fit_h4_component <- function(var, label) {
  dd <- p[complete.cases(p[, c("knowledge_t2", "knowledge_t1", var, "family_ses", "condition", "debate_id")]), , drop = FALSE]
  dd$t1_z <- z(dd$knowledge_t1); dd$ses_z <- z(dd$family_ses); dd$source_z <- z(dd[[var]])
  mm <- lm(knowledge_t2 ~ t1_z * source_z + ses_z + condition, data = dd)
  oo <- cr2_analysis(mm, dd, "debate_id", label)
  rr <- extract_term(oo, "t1_z:source_z")
  rr$component <- var
  rr
}
C1_Components <- bind_fill(
  fit_h4_component("web_source_expertise", "C1 component: T1 x Web expertise"),
  fit_h4_component("web_source_benevolence", "C1 component: T1 x Web benevolence")
)
pcol4 <- if ("p_Satt" %in% names(C1_Components)) "p_Satt" else if ("p_val" %in% names(C1_Components)) "p_val" else "p"
C1_Components$q_BH <- p.adjust(C1_Components[[pcol4]], method = "BH")

# Parallel human-credit test: not used to infer a difference unless a direct cross-environment test is specified later.
h4h <- p[complete.cases(p[, c("knowledge_t3", "knowledge_t2", "human_credit_z", "condition", "debate_id")]), , drop = FALSE]
h4h$t2_z <- z(h4h$knowledge_t2)
h4h_m <- lm(knowledge_t3 ~ t2_z * human_credit_z + condition, data = h4h)
C1_Human_Parallel <- cr2_analysis(h4h_m, h4h, "debate_id", "C1 parallel human test: T2 x human credit -> T3")$tests

# 9. RQ1 — Human epistemic bottleneck -----------------------------------------
# RQ1a: Is the partner's actual pre-debate expertise recognized?
k2_center <- mean(p$knowledge_t2, na.rm = TRUE); k2_scale <- sd(p$knowledge_t2, na.rm = TRUE)
d$evaluatee_k2_z <- z_with(d$evaluatee_knowledge_t2, k2_center, k2_scale)
d$evaluator_k2_z <- z_with(d$evaluator_knowledge_t2, k2_center, k2_scale)
rq1a <- d[complete.cases(d[, c("perceived_expertise", "evaluatee_k2_z", "evaluator_k2_z", "condition", "debate_id")]), , drop = FALSE]
rq1a_m <- lm(perceived_expertise ~ evaluatee_k2_z + evaluator_k2_z + condition, data = rq1a)
RQ1_Recognition <- cr2_analysis(rq1a_m, rq1a, "debate_id", "RQ1a partner T2 expertise -> perceived expertise")$tests

# Standardized effect + equivalence sensitivity for recognition.
rq1a$perceived_expertise_z <- z(rq1a$perceived_expertise)
rq1a_std_m <- lm(perceived_expertise_z ~ evaluatee_k2_z + evaluator_k2_z + condition, data = rq1a)
RQ1_Recognition_Standardized <- cr2_analysis(rq1a_std_m, rq1a, "debate_id",
  "RQ1a standardized partner T2 expertise -> perceived expertise")$tests
RQ1_Recognition_Equivalence <- cr2_tost_sensitivity(rq1a_std_m, rq1a, "debate_id",
  "evaluatee_k2_z", label = "RQ1a standardized recognition equivalence sensitivity")

# Does evaluator expertise improve discrimination? Secondary expertise-specific test.
rq1a_int_m <- lm(perceived_expertise ~ evaluatee_k2_z * evaluator_k2_z + condition, data = rq1a)
RQ1_Evaluator_Expertise <- cr2_analysis(rq1a_int_m, rq1a, "debate_id", "RQ1a secondary: partner x evaluator expertise")$tests

# RQ1b: Does factual knowledge available in partners predict post-debate factual knowledge beyond own T2?
rq1b <- p[complete.cases(p[, c("knowledge_t3", "knowledge_t2", "mean_partner_knowledge_t2",
                                "max_partner_knowledge_t2", "max_partner_advantage_t2",
                                "prop_partners_more_knowledgeable", "condition", "debate_id")]), , drop = FALSE]
rq1b$own_k2_z <- z(rq1b$knowledge_t2)
rq1b$partner_k2_z <- z(rq1b$mean_partner_knowledge_t2)
rq1b$mean_partner_advantage_t2 <- rq1b$mean_partner_knowledge_t2 - rq1b$knowledge_t2
rq1b$mean_partner_advantage_z <- z(rq1b$mean_partner_advantage_t2)
rq1b$max_partner_k2_z <- z(rq1b$max_partner_knowledge_t2)
rq1b$max_partner_advantage_z <- z(rq1b$max_partner_advantage_t2)
rq1b$delta_k_debate <- rq1b$knowledge_t3 - rq1b$knowledge_t2

# Primary mean-partner analysis.
rq1b_m <- lm(knowledge_t3 ~ own_k2_z + partner_k2_z + condition, data = rq1b)
RQ1_Partner_Knowledge <- cr2_analysis(rq1b_m, rq1b, "debate_id", "RQ1b mean partner T2 factual knowledge -> T3")$tests

# Standardized effect + equivalence sensitivity for mean available partner knowledge.
rq1b$knowledge_t3_z <- z(rq1b$knowledge_t3)
rq1b_std_m <- lm(knowledge_t3_z ~ own_k2_z + partner_k2_z + condition, data = rq1b)
RQ1_Partner_Knowledge_Standardized <- cr2_analysis(rq1b_std_m, rq1b, "debate_id",
  "RQ1b standardized mean partner T2 factual knowledge -> T3")$tests
RQ1_Partner_Knowledge_Equivalence <- cr2_tost_sensitivity(rq1b_std_m, rq1b, "debate_id",
  "partner_k2_z", label = "RQ1b standardized mean partner-knowledge equivalence sensitivity")

# Robustness 1: highest-scoring partner rather than the partner mean.
rq1b_max_m <- lm(knowledge_t3 ~ own_k2_z + max_partner_k2_z + condition, data = rq1b)
RQ1_Max_Partner_Knowledge <- cr2_analysis(rq1b_max_m, rq1b, "debate_id",
  "RQ1b robustness: highest-scoring partner T2 factual knowledge -> T3")$tests

# Robustness 2: how much additional factual knowledge is potentially available
# in the highest-scoring partner relative to the evaluator's own T2 score.
rq1b_maxadv_m <- lm(knowledge_t3 ~ own_k2_z + max_partner_advantage_z + condition, data = rq1b)
RQ1_Max_Partner_Advantage <- cr2_analysis(rq1b_maxadv_m, rq1b, "debate_id",
  "RQ1b robustness: highest-scoring partner factual-knowledge advantage -> T3")$tests
rq1b_maxadv_delta_m <- lm(delta_k_debate ~ own_k2_z + max_partner_advantage_z + condition, data = rq1b)
RQ1_Max_Partner_Advantage_Change <- cr2_analysis(rq1b_maxadv_delta_m, rq1b, "debate_id",
  "RQ1b robustness: highest-scoring partner factual-knowledge advantage -> T2-to-T3 change")$tests

# Secondary diagnostic retained for continuity with v2: mean partner advantage.
rq1b_meanadv_m <- lm(knowledge_t3 ~ own_k2_z + mean_partner_advantage_z + condition, data = rq1b)
RQ1_Mean_Partner_Advantage <- cr2_analysis(rq1b_meanadv_m, rq1b, "debate_id",
  "RQ1b secondary: mean partner factual-knowledge advantage -> T3")$tests

# Supplementary ecological descriptor: proportion of partners scoring above the evaluator.
rq1b_more_m <- lm(knowledge_t3 ~ own_k2_z + prop_partners_more_knowledgeable + condition, data = rq1b)
RQ1_More_Knowledgeable_Partners <- cr2_analysis(rq1b_more_m, rq1b, "debate_id",
  "RQ1b supplementary: proportion of partners with higher T2 factual score -> T3")$tests

# RQ1c: Does evaluator-level human credit predict T3 beyond own T2?
rq1c <- p[complete.cases(p[, c("knowledge_t3", "knowledge_t2", "human_credit_z", "condition", "debate_id")]), , drop = FALSE]
rq1c$own_k2_z <- z(rq1c$knowledge_t2)
rq1c_m <- lm(knowledge_t3 ~ own_k2_z + human_credit_z + condition, data = rq1c)
RQ1_Human_Credit_to_T3 <- cr2_analysis(rq1c_m, rq1c, "debate_id", "RQ1c human credit -> T3 controlling own T2")$tests

# 10. Key-results table --------------------------------------------------------
term_p <- function(df) {
  if ("p_Satt" %in% names(df)) return(df$p_Satt)
  if ("p_val" %in% names(df)) return(df$p_val)
  if ("p" %in% names(df)) return(df$p)
  rep(NA_real_, nrow(df))
}
keyrow <- function(hypothesis, analysis, df, term, expected, status) {
  x <- df[df$term == term, , drop = FALSE]
  if (!nrow(x)) return(data.frame(hypothesis=hypothesis, analysis=analysis, term=term, estimate=NA, SE=NA, p=NA, expected=expected, status=status))
  data.frame(hypothesis=hypothesis, analysis=analysis, term=term,
             estimate=if ("beta" %in% names(x)) x$beta[1] else NA,
             SE=if ("SE" %in% names(x)) x$SE[1] else NA,
             p=term_p(x)[1], expected=expected, status=status, stringsAsFactors = FALSE)
}
eq_keyrow <- function(hypothesis, analysis, df, bound = 0.20, status = "equivalence sensitivity") {
  x <- df[abs(df$SESOI_high - bound) < 1e-12, , drop = FALSE]
  if (!nrow(x)) return(data.frame(hypothesis=hypothesis, analysis=analysis, term="TOST", estimate=NA, SE=NA, p=NA, expected=paste0("|beta_std| < ", bound), status=status, equivalent=NA))
  data.frame(hypothesis=hypothesis, analysis=analysis, term=x$term[1],
             estimate=x$estimate_std[1], SE=x$SE_CR2[1], p=x$p_equivalence[1],
             expected=paste0("equivalence within +/-", bound, " SD"), status=status,
             equivalent=x$equivalent_alpha_05[1], stringsAsFactors = FALSE)
}
Key_Results <- bind_fill(
  keyrow("H1", "Factual change T1->T2", H1_RI_Change, "(Intercept)", "> 0", "primary"),
  keyrow("H1", "Common-baseline factual change T1->T3", H1_Global_Change, "(Intercept)", "> 0 if initial gain remains visible at protocol end", "primary contextual"),
  keyrow("H1", "Incremental factual change T2->T3", H1_Debate_Change, "(Intercept)", "no substantial positive gain", "primary"),
  keyrow("H1", "Direct phase contrast: debate minus RI", H1_Phase_Contrast, "(Intercept)", "< 0", "primary"),
  keyrow("H2", "Subjective change T1->T2", H2_Mean_Changes[H2_Mean_Changes$model == "H2 subjective change T1->T2",], "(Intercept)", "trajectory-specific", "secondary"),
  keyrow("H2", "Subjective change T1->T3", H2_Mean_Changes[H2_Mean_Changes$model == "H2 subjective change T1->T3",], "(Intercept)", "end-of-protocol change from common baseline", "secondary"),
  keyrow("H2", "Subjective change T2->T3", H2_Mean_Changes[H2_Mean_Changes$model == "H2 subjective change T2->T3",], "(Intercept)", "incremental second-period change", "secondary"),
  keyrow("H2", "Attitude change T1->T2", H2_Mean_Changes[H2_Mean_Changes$model == "H2 attitude change T1->T2",], "(Intercept)", "non-zero", "primary"),
  keyrow("H2", "Attitude change T1->T3", H2_Mean_Changes[H2_Mean_Changes$model == "H2 attitude change T1->T3",], "(Intercept)", "end-of-protocol change from common baseline", "primary"),
  keyrow("H2", "Attitude change T2->T3", H2_Mean_Changes[H2_Mean_Changes$model == "H2 attitude change T2->T3",], "(Intercept)", "incremental second-period change", "primary"),
  keyrow("H3", "Source type x condition composite credit", H3_Source_Credit, "source_typeHuman:conditionCooperation", "positive interaction", "primary"),
  keyrow("H3", "Calibration T3 controlling T2", H3_Calibration_Longitudinal, "conditionCooperation", "negative error coefficient", "primary"),
  keyrow("C1", "T1 x Web credit -> T2", C1_Web_Credit, "t1_z:web_credit_z", "negative interaction", "complementary"),
  keyrow("RQ1", "Partner T2 expertise -> perceived expertise", RQ1_Recognition, "evaluatee_k2_z", "positive if competence is recognized", "research question"),
  keyrow("RQ1", "Mean partner T2 factual knowledge -> T3", RQ1_Partner_Knowledge, "partner_k2_z", "positive if available human knowledge supports learning", "research question"),
  keyrow("RQ1", "Highest-scoring partner T2 factual knowledge -> T3", RQ1_Max_Partner_Knowledge, "max_partner_k2_z", "positive if the best available factual resource supports learning", "robustness"),
  keyrow("RQ1", "Highest-scoring partner factual-knowledge advantage -> T3", RQ1_Max_Partner_Advantage, "max_partner_advantage_z", "positive if additional factual knowledge available in the group supports learning", "robustness"),
  keyrow("RQ1", "Human credit -> T3", RQ1_Human_Credit_to_T3, "human_credit_z", "positive if credit supports uptake", "research question"),
  eq_keyrow("RQ1", "Recognition equivalence at focal +/-0.20 SD bound", RQ1_Recognition_Equivalence),
  eq_keyrow("RQ1", "Partner-knowledge -> T3 equivalence at focal +/-0.20 SD bound", RQ1_Partner_Knowledge_Equivalence)
)

Equivalence_Config <- data.frame(
  parameter = c("analysis_status", "standardized_bounds_SD", "focal_bound_SD", "alpha", "decision_rule"),
  value = c(
    "post hoc sensitivity; not preregistered confirmatory equivalence testing",
    paste(EQUIV_BOUNDS_SD, collapse = ", "),
    "0.20",
    as.character(EQUIV_ALPHA),
    "equivalent at a bound only if both one-sided CR2/Satterthwaite p values < alpha; equivalent to 90% CI inside symmetric bounds"
  ),
  stringsAsFactors = FALSE
)

# 11. Core workbook ------------------------------------------------------------
core_sheets <- list(
  QC = QC,
  Design_Notes = Design_Notes,
  Baseline_Balance_Desc = Baseline_Balance_Descriptives,
  Baseline_Balance_CR2 = Baseline_Balance_CR2,
  Equivalence_Config = Equivalence_Config,
  H1_Descriptives = H1_Descriptives,
  H1_Common_Baseline = H1_Common_Baseline,
  H1_RI_Change = H1_RI_Change,
  H1_Global_Change = H1_Global_Change,
  H1_Debate_Change = H1_Debate_Change,
  H1_Phase_Contrast = H1_Phase_Contrast,
  H1_Dispersion = H1_Dispersion,
  H1_Distribution_Diag = H1_Distribution_Diagnostics,
  H1_Reliability_Status = H1_Reliability_Status,
  H1_Continuity = H1_Continuity,
  H1_Debate_Sensitivity = H1_Debate_Sensitivity,
  H2_Change_Desc = H2_Change_Descriptives,
  H2_Mean_Changes = H2_Mean_Changes,
  H2_Amplitude = H2_Amplitude,
  H2_Dispersion = H2_Dispersion,
  H2_Distribution_Diag = H2_Distribution_Diagnostics,
  H2_Attitude_Subscales = H2_Attitude_Subscales,
  H2_Coupling_Descriptive = H2_Coupling_Descriptive,
  H2_Coupling_CR2 = H2_Coupling_CR2,
  H2_Coupling_Equiv = H2_Coupling_Equivalence,
  H3_Source_Desc = H3_Source_Descriptives,
  H3_Source_Credit = H3_Source_Credit,
  H3_Source_Expertise = H3_Source_Expertise,
  H3_Source_Benevolence = H3_Source_Benevolence,
  H3_Credit_Sens_NSources = H3_Source_Credit_Sens_NSources,
  H3_Credit_Sens_NSrc_Int = H3_Source_Credit_Sens_NSources_Interaction,
  H3_Source_Within = H3_Source_Within,
  H3_Calib_Longitudinal = H3_Calibration_Longitudinal,
  H3_Calib_Change = H3_Calibration_Change,
  H3_T3_Diagnosticity = H3_T3_Diagnosticity,
  C1_Web_Credit = C1_Web_Credit,
  C1_Simple_Slopes = C1_Simple_Slopes,
  C1_Components = C1_Components,
  C1_Human_Parallel = C1_Human_Parallel,
  RQ1_Recognition = RQ1_Recognition,
  RQ1_Recognition_Std = RQ1_Recognition_Standardized,
  RQ1_Recognition_Equiv = RQ1_Recognition_Equivalence,
  RQ1_Evaluator_Expertise = RQ1_Evaluator_Expertise,
  RQ1_Partner_Knowledge = RQ1_Partner_Knowledge,
  RQ1_Partner_K_Std = RQ1_Partner_Knowledge_Standardized,
  RQ1_Partner_K_Equiv = RQ1_Partner_Knowledge_Equivalence,
  RQ1_Max_Partner_K = RQ1_Max_Partner_Knowledge,
  RQ1_Max_Partner_Adv = RQ1_Max_Partner_Advantage,
  RQ1_Max_Adv_Change = RQ1_Max_Partner_Advantage_Change,
  RQ1_Mean_Partner_Adv = RQ1_Mean_Partner_Advantage,
  RQ1_More_Knowledgeable = RQ1_More_Knowledgeable_Partners,
  RQ1_Human_Credit_to_T3 = RQ1_Human_Credit_to_T3,
  Key_Results = Key_Results
)
write_workbook(CORE_FILE, core_sheets)
cat("Core workbook written:", CORE_FILE, "\n")

# 12. Bootstrap checks ---------------------------------------------------------
cat("Running debate-cluster bootstrap checks...\n")
H1_Variance_Contrast_Boot <- cluster_boot_variance_contrast(
  p, "knowledge_t1", "knowledge_t2", "knowledge_t2", "knowledge_t3",
  "debate_id", BOOT_REPS, BOOT_SEED,
  "H1 direct contrast of factual variance change: debate minus RI"
)
H2_Convergence_vs_Subjective <- cluster_boot_specificity(
  p, "knowledge_t1", "knowledge_t2", "subjective_knowledge_t1", "subjective_knowledge_t2",
  "debate_id", BOOT_REPS, BOOT_SEED + 1L,
  "H2 T1->T2 factual homogenization vs subjective-knowledge dispersion"
)
H2_Convergence_vs_Attitude <- cluster_boot_specificity(
  p, "knowledge_t1", "knowledge_t2", "attitude_total_t1", "attitude_total_t2",
  "debate_id", BOOT_REPS, BOOT_SEED + 2L,
  "H2 T1->T2 factual homogenization vs attitude dispersion"
)
H2_Global_Convergence_vs_Subjective <- cluster_boot_specificity(
  p, "knowledge_t1", "knowledge_t3", "subjective_knowledge_t1", "subjective_knowledge_t3",
  "debate_id", BOOT_REPS, BOOT_SEED + 3L,
  "H2 T1->T3 factual homogenization vs subjective-knowledge dispersion"
)
H2_Global_Convergence_vs_Attitude <- cluster_boot_specificity(
  p, "knowledge_t1", "knowledge_t3", "attitude_total_t1", "attitude_total_t3",
  "debate_id", BOOT_REPS, BOOT_SEED + 4L,
  "H2 T1->T3 factual homogenization vs attitude dispersion"
)

check_sheets <- c(core_sheets, list(
  H1_Variance_Boot = H1_Variance_Contrast_Boot,
  H2_Conv_vs_Subj_Boot = H2_Convergence_vs_Subjective,
  H2_Conv_vs_Att_Boot = H2_Convergence_vs_Attitude,
  H2_T13_Conv_vs_Subj = H2_Global_Convergence_vs_Subjective,
  H2_T13_Conv_vs_Att = H2_Global_Convergence_vs_Attitude
))
write_workbook(CHECK_FILE, check_sheets)
cat("Complete workbook written:", CHECK_FILE, "\n")

# 13. Session information ------------------------------------------------------
sink(SESSION_FILE)
cat("MOVICI Article 3\n")
cat("Script version:", SCRIPT_VERSION, "\n")
cat("Run mode:", RUN_MODE, "\n")
cat("Bootstrap resamples:", BOOT_REPS, "\n")
cat("Equivalence sensitivity bounds (standardized):", paste(EQUIV_BOUNDS_SD, collapse = ", "), "\n")
cat("Equivalence alpha:", EQUIV_ALPHA, "\n\n")
print(sessionInfo())
sink()
cat("Session information written:", SESSION_FILE, "\n")
cat("\nAnalysis complete.\n")
