# Reproducibility notes — V3.4

V3.4 is the JASSS-audit revision of V3.3. Core empirical coefficient values are unchanged. The main substantive implementation correction is the longitudinal RI exposure engine: step 1 remains a full-pool empirical anchor, while steps 2–50 use the same limited-exposure engine in FIXED and RENEWED.

## Recommended workflow

1. Open `MOVICI_Article4_OSF.Rproj`.
2. Run `source("RUN_FAST.R")`.
3. Confirm every row in `validation/REGRESSION_CHECKS.csv` is `PASS`.
4. Inspect FAST outputs only for technical plausibility; do not use them as article estimates.
5. Run `source("RUN_STANDARD.R")` once the source package is frozen.
6. Confirm the regression checks still pass.
7. Review the publication tables listed in the root README.
8. Record `results/publication/SESSION_INFO.txt`.
9. Regenerate the SHA-256 manifest after adding the final generated outputs to the archived release.

## Dependencies

The simulation pipeline uses base R. Optional `clubSandwich` reproduces the manuscript CR2/Satterthwaite inference for the empirical `ExpertiseAllocationGain` analysis; if absent, OLS and cluster-HC1 are still exported.

## Computational strategy

The main publication estimands retain 30 Monte-Carlo runs. Controlled same-agent COOP/COMP results also retain 30 runs. Sensitivity, ablation, and design-robustness variants use 5 runs by default in V3.4 to avoid making the reproducibility package unnecessarily expensive. If a complementary variant appears unstable or changes a qualitative conclusion, increase that variant selectively in `config/simulation_config.csv` and document the change.

Monte-Carlo worlds quantify simulation variability. They are not additional human observations, and the 2.5%/97.5% Monte-Carlo quantiles are not human-population confidence intervals.

## Critical V3.4 invariants

- Step 1 RI uses the full original 20-item pool in both FIXED and RENEWED.
- From step 2, both FIXED and RENEWED RI use the configured exposure budget and reliability model.
- RENEWED alone introduces new information atoms.
- `EpistemicCreditMisallocationIndex` is directional and equals the mean of its available corrective-underuse components.
- `NO_DIFFERENTIAL_CREDIT_ALLOCATION` preserves each evaluator's mean pre-ablation partner weight within the current episode.
- Human COOP/COMP differences are observational constraints; same-agent regime switching and ablations are causal interventions inside the model only.

## Release discipline

After a successful FAST validation, freeze the source and configuration before the final STANDARD run. Do not modify the model engine after generating the final publication results unless a genuine bug is found. If code changes, rerun the affected results and regenerate the manifest.
