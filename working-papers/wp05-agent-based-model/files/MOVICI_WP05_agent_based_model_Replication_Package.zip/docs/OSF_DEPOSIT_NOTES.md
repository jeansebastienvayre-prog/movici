# OSF deposit notes — MOVICI–CAVL SMA V3.4

## Suggested repository title
MOVICI–CAVL SMA: Empirically Grounded Agent-Based Model of Information Search, Debate, and Epistemic Credit Misallocation

## Suggested short description
Reproducible RStudio package for the MOVICI–CAVL agent-based model accompanying a JASSS manuscript. The model is empirically grounded in the MOVICI experiment and studies repeated information search, debate, metacognitive self-models, epistemic credit allocation, social receptivity, cumulative learning, and SES-related knowledge differences in fixed and expanding information environments.

## What to archive
This final package already includes the V3.4 STANDARD outputs used in the manuscript. If the code is rerun or modified, regenerate outputs, session information, and checksums before replacing the archived release.

Keep the V3.3 package separately if historical traceability is desired; do not mix V3.3 generated outputs into the V3.4 release.

## License
The package includes separate licenses: CC BY 4.0 for data/documentation and MIT for code. Select corresponding OSF license metadata where appropriate and retain the included license files.

## Citation metadata
Add the final article author list and OSF DOI once fixed. Do not reuse provisional manuscript author placeholders.

## Integrity
`SHA256SUMS.txt` inventories the source-release files and their SHA-256 hashes. Regenerate it after adding final STANDARD outputs. The manifest intentionally does not hash itself.

## Interpretation note
The package separates observational human-condition constraints from causal interventions performed inside the simulation. The directional `EpistemicCreditMisallocationIndex` measures under-use of corrective expertise; it is not a direct operational measure of identity-based epistemic injustice.
