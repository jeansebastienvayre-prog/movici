# JASSS / OSF release checklist — V3.4

> Finalization note (2026-09-28): the deposited Article 4 package includes the V3.4 STANDARD `results/` directory and session information. The checklist below is retained as reproducibility provenance for reruns or future replacements of the archived release.

## Before the final STANDARD run
- [ ] Open `MOVICI_Article4_OSF.Rproj`.
- [ ] Optional for exact empirical CR2 inference: install `clubSandwich`.
- [ ] Run `source("RUN_FAST.R")`.
- [ ] Confirm every row in `validation/REGRESSION_CHECKS.csv` is `PASS`.
- [ ] Confirm the RI step-1 full-pool anchor and the step-2+ exposure-budget checks pass.
- [ ] Confirm no unexpected `NA`, `NaN`, or infinite values appear in key FAST outputs.
- [ ] Freeze the V3.4 source/configuration before launching STANDARD.

## Final article run
- [ ] Run `source("RUN_STANDARD.R")` to completion.
- [ ] Confirm `validation/REGRESSION_CHECKS.csv` still contains only `PASS`.
- [ ] Inspect `results/publication/Table_CALIBRATION_VALIDATION_STEP1.csv`.
- [ ] Confirm the empirical RI gain remains `1.395833...` and the step-1 simulation remains in the intended empirical range.
- [ ] Inspect `results/publication/Table_EMPIRICAL_EXPERTISE_ALLOCATION_CHECK.csv`.
- [ ] If `clubSandwich` is installed, archive `EMPIRICAL_EXPERTISE_ALLOCATION_CR2.csv`.
- [ ] Inspect `results/publication/MC_CONVERGENCE.csv`; evaluate stability at 10 / 20 / 30 main runs.
- [ ] Inspect `results/statistics/Table_MAIN_SES_stock_density_RENEWED.csv`.
- [ ] Inspect `results/statistics/Table_MAIN_social_receptivity_diagnostics.csv`.
- [ ] Inspect `Table_SENSITIVITY.csv`, `Table_ABLATIONS.csv`, and `Table_ROBUSTNESS_PARTNERS_GROUPSIZE.csv`.
- [ ] If any 5-run complementary analysis is qualitatively unstable, selectively rerun that variant with more repetitions before manuscript finalization.

## Interpretation checks
- [ ] Report `KnowledgeStock` and `KnowledgeDensity` together in RENEWED.
- [ ] Interpret a widening absolute stock difference separately from a proportional density difference.
- [ ] For standalone RENEWED Debate, use `CumulativeLearningBalance` for endogenous learning.
- [ ] Report acquisitions and losses separately when interpreting increased social receptivity.
- [ ] Treat `EpistemicCreditMisallocationIndex` as intentionally directional.
- [ ] Treat over-credit/less-expert weighting as separate calibration/receptivity diagnostics, not as components of the directional index.
- [ ] Use **epistemic credit misallocation** for the operational index; do not call it a direct measure of epistemic injustice.
- [ ] Describe human COOP/COMP differences as observational, because allocation was not strictly randomized.
- [ ] Reserve causal language for modeled interventions (same-agent counterfactuals and ablations), explicitly qualified as model-internal.
- [ ] Do not treat Monte-Carlo worlds as human observations or MC quantiles as human-population confidence intervals.

## OSF archive
- [ ] Confirm article-minimal files contain only pseudonymous identifiers.
- [ ] Keep `SESSION_INFO.txt` from the final STANDARD run.
- [ ] Regenerate `SHA256SUMS.txt` after adding final generated results.
- [ ] Add the OSF DOI / archived release identifier to the manuscript.
- [ ] Select the intended OSF license(s) before making the project public.
- [ ] Archive the exact manuscript/preprint version associated with the release, if desired.
