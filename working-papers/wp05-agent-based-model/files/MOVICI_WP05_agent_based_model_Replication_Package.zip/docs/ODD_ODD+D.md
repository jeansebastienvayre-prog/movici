# ODD / ODD+D description — MOVICI–CAVL SMA JASSS / OSF V3.4

## 1. Purpose and patterns

### Purpose
The model asks how repeated information search and repeated human debate can generate temporal patterns of factual learning, metacognitive calibration, epistemic-credit allocation, and cumulative knowledge differences. It is empirically grounded in MOVICI. The first episode is anchored to observed short-run signatures; episodes 2–50 are generative experiments, not chronological forecasts.

### Primary empirical patterns targeted or checked at step 1
1. Strong factual gain after RI (T1→T2).
2. Positive SES gradient in post-RI factual knowledge, conditional on baseline knowledge.
3. No robust direct COOP/COMP effect on RI factual knowledge.
4. Near-zero mean factual gain after one debate (T2→T3).
5. COOP/COMP differences in social source evaluation used to parameterize debate credit signals.
6. Better human allocation of perceived competence toward objectively more knowledgeable partners is associated with greater final factual knowledge, conditional on prior knowledge.

Calibration targets and structural checks are labeled separately; fitted quantities are not presented as independent external validations.

### Emergent patterns studied beyond step 1
- Saturation versus continued accumulation of factual knowledge.
- Absolute knowledge-stock differences versus knowledge-density differences in expanding worlds.
- Cumulative SES gradients under repeated RI.
- Directional epistemic-credit misallocation under repeated debate.
- General social receptivity versus differential weighting of sources.
- Missed corrective opportunities and expert-use efficiency.
- Long-run COOP/COMP differences that arise indirectly through social evaluation, credit, self-model updating, and uptake.
- Whether RI→Debate changes final knowledge, the learning path, and social-credit dynamics relative to RI alone and Debate alone.

## 2. Entities, state variables, and scales

### Agents
The model contains 96 pseudonymous agents initialized from the 96 MOVICI participants. Fixed empirical inputs include factual-item states, the SES composite, subjective knowledge, visibility, relational style, debate-group-size information, and empirical condition.

Dynamic states include factual knowledge, self-credit/metacognitive state, exposure history, and evaluator→source relational memory.

### Information atoms
The initial environment contains 20 factual atoms corresponding to the MOVICI factual items. In RENEWED scenarios, 3 new atoms are introduced per cycle from step 2 by default. New-atom difficulty is sampled with replacement from the empirical item-ease distribution.

### Time
One model step is one RI episode, one Debate episode, or one coupled RI→Debate cycle. Reported horizons are 1, 5, 10, 15, 20, 25, and 50. A step is an abstract occurrence of the modeled process; it is not a day, week, or year.

### Social groups
Primary Debate/Coupled simulations rotate partners within modeled condition at each step. Group sizes reproduce the empirical participant-level size distribution separately within COOP and COMP as closely as integer partitioning permits. Fixed-partner and all-size-4 designs are robustness checks.

## 3. Process overview and scheduling

### RI step 1: empirical anchoring
1. Use the original 20-item information pool.
2. Apply the calibrated factual transition kernel to the full pool.
3. Update factual state.
4. Update the metacognitive self-model using empirical navigation information where available.

This full-pool first episode is retained to preserve direct comparability with the observed MOVICI T1→T2 transition.

### RI steps 2–50: longitudinal limited exposure
1. If RENEWED, expand the information world with the configured number of new atoms.
2. Give each agent the same configured exposure budget in FIXED and RENEWED (10 encounters by default).
3. In RENEWED, reserve up to the configured number of encounters for atoms introduced in the current cycle (2 by default); FIXED has no current-cycle new atoms.
4. Draw encounter reliability (`p = 0.80` by default; scenario assumption, not an empirical estimate of Web reliability).
5. Apply calibrated learning transitions after reliable encounters and calibrated loss transitions after misleading encounters.
6. Update factual state.
7. Update the metacognitive self-model.

Thus, after the empirical anchoring episode, FIXED and RENEWED use the same attention/exposure engine. Their structural difference is whether the information world expands.

### Debate step
1. In standalone RENEWED Debate, expand the world and distribute a small amount of new state information across agents so that genuinely new social knowledge can exist; these exogenous additions are tracked separately from learning.
2. Form debate groups within condition under the configured group-size and partner regime.
3. Generate source-recognition and benevolence signals.
4. Update evaluator→source relational memory unless ablated.
5. Compute `OtherCredit`.
6. Transform credit relative to `SelfCredit` into `PartnerWeight`, unless ablated.
7. Calculate source-recognition, calibration, general-receptivity, corrective-opportunity, rank-reversal, and directional credit-misallocation diagnostics.
8. Update `SelfCredit`.
9. Attempt social factual transfer. Partner-weighted transfer can produce either a 0→1 acquisition when a partner has a fact the evaluator lacks or a 1→0 loss when a highly weighted partner lacks a fact the evaluator currently has.

### Coupled step
RI is executed first; Debate is then executed on the RI-updated state without adding a second information-world increment. RI-specific and Debate-specific acquisitions, losses, exposures, and stock deltas are retained separately.

## 4. Design concepts

### Theoretical architecture
CAVL treats learning as bounded, recursively updated, and socially embedded. The implementation distinguishes information acquired through document/search exposure from information acquired through interpersonal source evaluation; factual knowledge from subjective/self-credit; source recognition from actual credit allocation; and credit allocation from factual uptake.

### Epistemic credit misallocation: intentionally directional
The primary synthetic index is the mean of the available components:
1. missed corrective opportunity rate;
2. credit-rank reversal rate when the partner is objectively more knowledgeable than the evaluator;
3. underweighting rate for objectively more knowledgeable partners.

The index is intentionally directional: it measures **under-use of available corrective expertise**, not every possible symmetric credit-calibration error. Over-credit of a less-expert partner is treated as a separate calibration/receptivity phenomenon and is reported through `MeanOverCreditMagnitude`, `WeightLessExpert`, and `OverweightLessExpertRate`.

This distinction allows the model to separate two questions: whether a regime improves source-specific discrimination, and whether it increases general receptivity to other people. A regime can be imperfectly calibrated yet still reduce the probability of missing corrective expertise.

The index is competence-relative. It is not, by itself, a direct measure of identity-prejudicial testimonial injustice. Testing epistemic injustice in the stronger sense would require an explicit status/prejudice mechanism at equal objective competence.

### Controlled same-agent counterfactual
MOVICI did not strictly randomize the human COOP/COMP condition. Human condition differences are therefore treated as observational constraints. The controlled counterfactual instead clones the same initial simulated agent state under COOP and COMP, with common-random-number pairing as far as the implementation permits. It estimates the effect of switching the **modeled social regime**, holding the initial agent state fixed.

A behavior-mediated total-effect proxy is not included in the minimal publication run because the experiment does not identify every behavioral mediation path.

## 5. Initialization

RI and Coupled start from T1 item states and pre-search subjective knowledge. Debate starts from T2 item states and post-RI subjective knowledge. Missing source-profile values are imputed by joint donor sampling from observed profiles. Fixed standardization references are empirical and are never recomputed by scenario or step.

## 6. Input data

The public article package uses only variables required by model initialization, parameterization, and empirical checks. The full canonical MOVICI dataset is not required to reproduce this SMA article.

## 7. Submodels

### Factual transition kernel
Learning and loss probabilities are logistic functions of current expertise, SES, item ease, and the calibrated information-weight state. In Debate, `PartnerWeight` gates the probability of social uptake/revision.

### RI metacognition
Subjective knowledge is updated from prior subjective knowledge, current factual knowledge, and a SERP/navigation cue plus residual noise.

### Source recognition and OtherCredit
Recognized expertise combines visibility, modeled condition, their interaction, and noise. Benevolence combines relational style, modeled condition, and noise. Before relational-memory averaging:

`OtherCredit = RecognizedExpertise + alpha_B × Benevolence`.

### Relational memory
Evaluator→source recognition and credit signals are running means over prior encounters. `NO_RELATIONAL_MEMORY` removes this persistence.

### SelfCredit
The V1.3 persistent self-model retains prior `SelfCredit` and adds a COOP-specific knowledge-updating term plus noise. This is an empirically anchored model component; the minimal V3.4 extension suite does not add a separate self-persistence sensitivity.

## 8. Observation and analysis

### Main designs
- `INTER`: empirical-population composition and between-participant modeled effects.
- `INTRA-LONG`: trajectories of the same simulated agents over time.
- `INTRA_COUNTERFACTUAL`: same initial simulated agent under COOP and COMP.
- Matched cross-process RI vs Debate vs Coupled comparisons.

### Stock and density in expanding worlds
`KnowledgeStock` is the absolute number of currently known atoms. `KnowledgeDensity` is the share of the active information world currently mastered. Both are reported in RENEWED scenarios. A widening absolute stock difference in an expanding information world does not automatically imply an indefinitely widening proportional density difference.

### Learning acquisitions and losses
`CumulativeLearningAcquisitions` and `CumulativeLearningLosses` are reported separately. `CumulativeLearningBalance = acquisitions - losses`. In standalone RENEWED Debate, this balance is the preferred endogenous learning measure because exogenous distributed seed states are tracked outside the learning counters.

### Monte Carlo
The V3.4 publication run uses 30 main Monte-Carlo worlds and 30 controlled counterfactual worlds in RENEWED. Convergence is reported at 10/20/30 main worlds using Monte-Carlo SD, Monte-Carlo SE, and deviation from the 30-run estimate. Monte-Carlo quantiles describe variability across simulated worlds; they are not confidence intervals for a human population.

Publication extensions use 5 runs per variant by default. If an extension changes qualitative interpretation or is visibly unstable, that specific variant should be extended selectively.

## 9. Sensitivity analysis

The minimal publication suite uses three targeted one-at-a-time sensitivities:
- `new_items_per_cycle`: information-world growth;
- `partner_weight_scale`: the credit-to-uptake logistic scale;
- `alpha_B`: benevolence contribution to epistemic credit (`0`, `0.169`, `0.338`).

The central configuration is supplied by the main model and is not redundantly rerun inside the sensitivity suite. These tests examine model/scenario assumptions; they do not constitute complete propagation of sampling uncertainty from all empirical coefficients.

## 10. Mechanistic ablations

- `NO_SES_RI`: remove SES from RI transitions.
- `NO_RELATIONAL_MEMORY`: remove evaluator→source relational-memory averaging.
- `NO_CREDIT_GATING`: set every `PartnerWeight` to 0.5 so credit cannot modulate social uptake.
- `NO_DIFFERENTIAL_CREDIT_ALLOCATION`: first compute the unablated weights, preserve each evaluator's mean weight in the current episode, then assign that mean to all of the evaluator's current partners. This removes source-specific allocation while preserving general receptivity.

The latter two ablations answer different questions: whether credit must affect uptake at all, and whether differential allocation across sources adds explanatory value beyond general social receptivity.

## 11. Robustness

Primary design: rotating partners + empirical group-size distribution. Robustness compares:
- fixed partners + empirical group-size distribution;
- rotating partners + all groups of four.

## 12. Verification and validation

Automated checks verify bounds, cumulative counters, pool growth, panel uniqueness, counterfactual balance, learning identities, the directional-index component identity, and the longitudinal RI exposure budget. The code also enforces mean-receptivity preservation whenever `NO_DIFFERENTIAL_CREDIT_ALLOCATION` is active.

A publication table compares empirical step-1 targets with simulation estimates and labels each quantity as calibration or structural check rather than claiming independent external validation where parameters were fitted on MOVICI.

## 13. V3.4 audit revisions

Relative to V3.3, V3.4:

1. keeps the step-1 full-pool RI empirical anchor but uses the same limited-exposure engine for FIXED and RENEWED from step 2 onward;
2. retains `EpistemicCreditMisallocationIndex` as a directional corrective-expertise-underuse measure and adds less-expert weighting diagnostics instead of symmetrizing the index;
3. adds a mean-receptivity-preserving ablation to distinguish general social openness from differential source allocation;
4. exports dedicated stock-versus-density SES diagnostics and controlled social-receptivity diagnostics;
5. adds a targeted `alpha_B` sensitivity while reducing default extension repetitions to keep the publication package computationally tractable;
6. explicitly separates observational human condition differences from causal interventions inside the simulation;
7. documents social 0→1 acquisitions and 1→0 losses symmetrically and aligns code, ODD, dictionaries, and release notes.
