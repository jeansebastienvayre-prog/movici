# Final V3.4 STANDARD results

This directory contains the final V3.4 STANDARD outputs used to revise the Article 4 manuscript.

- Main scenarios and same-agent counterfactuals use 30 Monte Carlo replications.
- Targeted sensitivity, ablation, and robustness variants use five replications per variant.
- `publication/SESSION_INFO.txt` records the R session from the final STANDARD run.
- Monte Carlo quantiles describe stochastic variability across simulated worlds and are not confidence intervals for a human population.

To reproduce these outputs from source, open `MOVICI_Article4_OSF.Rproj` and run `source("RUN_STANDARD.R")`. `RUN_FAST.R` is for technical verification only and its estimates must not be substituted for the archived publication results.

The pipeline also generates validation checks and diagnostic figures when rerun. Those generated verification artifacts are not required to interpret the archived manuscript-facing result tables.
