MOVICI-CAVL SMA V3.4 — INFERENCE LAYERS
1) Learning is split into KnowledgeStock (absolute known atoms) and KnowledgeDensity (share of active information world mastered).
2) CumulativeLearningAcquisitions/Losses exclude exogenous distributed seed knowledge in standalone renewed Debate.
3) Intra-subject horizon tests follow the same agent from its process-specific empirical baseline.
4) Cumulative step1->horizon tables distinguish a one-episode effect from an effect that grows with repetition.
5) Inter-subject COOP/COMP and SES effects use participant-level models; Debate/Coupled horizon SEs are cluster-robust by current group when possible.
6) Counterfactual intra-condition tests clone the same agents under COOP and COMP with common random-number seeds; these are separate from the empirical between-subject design.
7) Monte Carlo worlds quantify simulation uncertainty and are NEVER treated as additional human participants.
8) Cross-process learning comparisons are matched by ID and favor change/stock-gain metrics over raw T1-vs-T2 levels.
9) EpistemicCreditMisallocationIndex is intentionally directional: it captures under-use of available corrective expertise, not every symmetric calibration error. Over-credit is reported separately. Broader epistemic injustice remains a theoretical interpretation, not the direct name of the index.
10) Coupling non-additivity is descriptive, not a causal interaction estimand, because the coupled trajectory is recursive.
