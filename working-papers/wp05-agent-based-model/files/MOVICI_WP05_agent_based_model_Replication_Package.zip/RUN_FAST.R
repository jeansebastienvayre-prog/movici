# MOVICI-CAVL SMA — JASSS / OSF V3.4 — FAST TECHNICAL CHECK
# -----------------------------------------------------------------------------
# Technical validation only. Do not use FAST outputs as publication estimates.
# Main SMA: 2 runs. Controlled RENEWED counterfactual: 1 run.
# Sensitivity / ablation / robustness suites: OFF.
# -----------------------------------------------------------------------------

N_RUNS_OVERRIDE <- 2L
N_CF_RUNS_OVERRIDE <- 1L
CF_INFO_REGIMES_OVERRIDE <- "RENEWED"
N_TOTAL_CF_RUNS_OVERRIDE <- 0L
RUN_COUNTERFACTUAL_OVERRIDE <- TRUE
RUN_TOTAL_CF_OVERRIDE <- FALSE
RUN_PUBLICATION_EXTENSIONS_OVERRIDE <- FALSE
INCLUDE_FROZEN_OVERRIDE <- FALSE
AGENT_EXPORT_RUNS_OVERRIDE <- 1L
DYAD_EXPORT_RUNS_OVERRIDE <- 0L

source(file.path("R", "SMA_JASSS_PIPELINE.R"))
