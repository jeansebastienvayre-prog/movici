# ============================================================================
# MOVICI-CAVL SMA — JASSS / OSF RELEASE V3.4
# Consolidated pipeline. Do not source this file directly: use RUN_FAST.R or RUN_STANDARD.R.
# Horizons: 1, 5, 10, 15, 20, 25, 50.
# Processes: RI, DEBATE, COUPLED; FIXED and RENEWED environments.
# Includes paired COOP/COMP counterfactual design when enabled by a release launcher.
# ============================================================================


# ============================================================================
# 00_setup.R
# ============================================================================
options(stringsAsFactors = FALSE, scipen = 999)

ROOT <- normalizePath('.', winslash='/', mustWork=TRUE)
DIRS <- c('data/derived','results/panel','results/population','results/statistics',
          'results/comparisons','results/controls','figures','validation')
for (d in DIRS) if (!dir.exists(d)) dir.create(d, recursive=TRUE)

read_config <- function(path) read.csv(path, check.names=FALSE, stringsAsFactors=FALSE)
SIMCFG <- read_config(file.path('config','simulation_config.csv'))
RI_PARAMS <- read_config(file.path('config','ri_model_parameters.csv'))
DEB_PARAMS <- read_config(file.path('config','debate_model_parameters.csv'))
RI_ENV <- read_config(file.path('config','ri_environment_config.csv'))

RUNTIME_CFG_OVERRIDE <- list()
RUNTIME_RI_OVERRIDE <- list()
RUNTIME_DEB_OVERRIDE <- list()
RUNTIME_ABLATION <- 'FULL'

cfg <- function(name) {
  if(!is.null(RUNTIME_CFG_OVERRIDE[[name]])) return(as.character(RUNTIME_CFG_OVERRIDE[[name]]))
  v <- SIMCFG$value[SIMCFG$key==name]
  if(length(v)!=1) stop('Config not uniquely found: ',name)
  v
}
cfg_int <- function(name) as.integer(cfg(name))
cfg_num <- function(name) as.numeric(cfg(name))
cfg_bool <- function(name) toupper(cfg(name)) %in% c('TRUE','T','1','YES','Y')
REPORT_STEPS <- as.integer(strsplit(cfg('report_steps'),';',fixed=TRUE)[[1]])
MASTER_SEED <- cfg_int('seed')

ri_param <- function(name, model=cfg('ri_model')) {
  if(!is.null(RUNTIME_RI_OVERRIDE[[name]])) return(as.numeric(RUNTIME_RI_OVERRIDE[[name]]))
  x <- RI_PARAMS[RI_PARAMS$parameter==name & RI_PARAMS$model %in% c(model,'BOTH'),,drop=FALSE]
  if(nrow(x)!=1) stop('RI parameter not uniquely found: ',name,' model=',model)
  as.numeric(x$central_value[1])
}
deb_param <- function(name) {
  if(!is.null(RUNTIME_DEB_OVERRIDE[[name]])) return(as.numeric(RUNTIME_DEB_OVERRIDE[[name]]))
  x <- DEB_PARAMS[DEB_PARAMS$parameter==name,,drop=FALSE]
  if(nrow(x)!=1) stop('Debate parameter not uniquely found: ',name)
  as.numeric(x$central_value[1])
}
ri_env <- function(name) {
  x <- RI_ENV$value[RI_ENV$key==name]
  if(length(x)!=1) stop('RI environment parameter not uniquely found: ',name)
  x
}

logistic <- function(x) 1/(1+exp(-x))
clamp <- function(x,lo,hi) pmin(hi,pmax(lo,x))
safe_mean <- function(x) if(sum(is.finite(x))>0) mean(x,na.rm=TRUE) else NA_real_
safe_sd <- function(x) if(sum(is.finite(x))>1) sd(x,na.rm=TRUE) else NA_real_
safe_median <- function(x) if(sum(is.finite(x))>0) median(x,na.rm=TRUE) else NA_real_
safe_cor <- function(x,y) {
  ok <- is.finite(x)&is.finite(y)
  if(sum(ok)<3 || safe_sd(x[ok])==0 || safe_sd(y[ok])==0) return(NA_real_)
  cor(x[ok],y[ok])
}
q025 <- function(x) if(sum(is.finite(x))>0) as.numeric(quantile(x,.025,na.rm=TRUE,names=FALSE)) else NA_real_
q975 <- function(x) if(sum(is.finite(x))>0) as.numeric(quantile(x,.975,na.rm=TRUE,names=FALSE)) else NA_real_
z_fixed <- function(x,m,s) ifelse(is.finite(x),(x-m)/s,NA_real_)
zscore <- function(x) {
  s<-sd(x,na.rm=TRUE); m<-mean(x,na.rm=TRUE)
  if(!is.finite(s)||s==0) return(rep(0,length(x)))
  (x-m)/s
}
pad_state <- function(m,n_new,fill=0) {
  if(n_new<=0) return(m)
  cbind(m,matrix(fill,nrow=nrow(m),ncol=n_new))
}
row_sum_na <- function(m) rowSums(m,na.rm=TRUE)
p_adjust_bh <- function(p) {
  out <- rep(NA_real_,length(p)); ok<-is.finite(p)
  if(any(ok)) out[ok] <- p.adjust(p[ok],method='BH')
  out
}
cohen_dz <- function(d) {
  d<-d[is.finite(d)]
  if(length(d)<2) return(NA_real_)
  s<-sd(d)
  if(!is.finite(s)||s==0) return(NA_real_)
  mean(d)/s
}
paired_stats <- function(x,y) {
  ok<-is.finite(x)&is.finite(y); d<-x[ok]-y[ok]
  n<-length(d)
  if(n<3) return(data.frame(N=n,estimate=NA,SE=NA,CI_low=NA,CI_high=NA,t=NA,df=NA,p=NA,dz=NA))
  md<-mean(d); sdv<-sd(d); df<-n-1
  if(!is.finite(sdv) || sdv < sqrt(.Machine$double.eps)) {
    return(data.frame(N=n,estimate=md,SE=0,CI_low=md,CI_high=md,
                      t=if(abs(md)<sqrt(.Machine$double.eps))0 else sign(md)*Inf,
                      df=df,p=if(abs(md)<sqrt(.Machine$double.eps))1 else 0,
                      dz=if(abs(md)<sqrt(.Machine$double.eps))0 else NA_real_))
  }
  se<-sdv/sqrt(n); tv<-md/se; crit<-qt(.975,df=df)
  data.frame(N=n,estimate=md,SE=se,CI_low=md-crit*se,CI_high=md+crit*se,
             t=tv,df=df,p=2*pt(abs(tv),df=df,lower.tail=FALSE),dz=md/sdv)
}
independent_stats <- function(x,g) {
  ok<-is.finite(x)&!is.na(g); x<-x[ok]; g<-as.character(g[ok])
  lev<-sort(unique(g)); if(length(lev)!=2) return(data.frame())
  a<-x[g==lev[1]]; b<-x[g==lev[2]]
  if(length(a)<3||length(b)<3) return(data.frame())
  tt<-t.test(a,b)
  sp<-sqrt(((length(a)-1)*var(a)+(length(b)-1)*var(b))/(length(a)+length(b)-2))
  d<-(mean(a)-mean(b))/sp
  J<-1-3/(4*(length(a)+length(b))-9)
  data.frame(group1=lev[1],group2=lev[2],N1=length(a),N2=length(b),
             estimate=mean(a)-mean(b),CI_low=tt$conf.int[1],CI_high=tt$conf.int[2],
             t=unname(tt$statistic),df=unname(tt$parameter),p=tt$p.value,
             hedges_g=J*d)
}

cluster_coef_table <- function(fit, cluster) {
  # Base-R CR0/HC1-style clustered covariance with small-sample scaling.
  X<-model.matrix(fit); e<-residuals(fit); n<-nrow(X); p<-ncol(X)
  cluster<-as.character(cluster)
  if(length(cluster)!=n) stop('cluster length must match model rows')
  ok<-!is.na(cluster)
  X<-X[ok,,drop=FALSE]; e<-e[ok]; cluster<-cluster[ok]
  G<-length(unique(cluster))
  if(G<4 || nrow(X)<=p) return(NULL)
  bread<-tryCatch(solve(crossprod(X)),error=function(e)NULL)
  if(is.null(bread)) return(NULL)
  meat<-matrix(0,p,p)
  for(g in unique(cluster)) {
    ix<-cluster==g
    s<-crossprod(X[ix,,drop=FALSE],e[ix])
    meat<-meat+s%*%t(s)
  }
  scale<-(G/(G-1))*((nrow(X)-1)/(nrow(X)-p))
  V<-scale*bread%*%meat%*%bread
  se<-sqrt(pmax(diag(V),0))
  b<-coef(fit)
  tval<-b/se
  df<-G-1
  pval<-2*pt(abs(tval),df=df,lower.tail=FALSE)
  data.frame(term=names(b),estimate=as.numeric(b),SE=se,t=tval,df=df,p=pval,
             clusters=G,SE_type='cluster_HC1',stringsAsFactors=FALSE)
}

mc_summary <- function(d, keys, estimate_col='estimate') {
  if(!nrow(d)) return(data.frame())
  grp <- do.call(interaction,c(unname(d[,keys,drop=FALSE]),list(drop=TRUE,lex.order=TRUE)))
  spl <- split(seq_len(nrow(d)),grp)
  out <- lapply(spl,function(ix){
    q<-d[ix,,drop=FALSE]; x<-q[[estimate_col]]
    z<-q[1,keys,drop=FALSE]
    cbind(z,data.frame(N_runs=sum(is.finite(x)),estimate_mean=safe_mean(x),MC_SD=safe_sd(x),
                       MC_median=safe_median(x),MC_q025=q025(x),MC_q975=q975(x),
                       Pr_positive=if(sum(is.finite(x)))mean(x[is.finite(x)]>0) else NA_real_,
                       stringsAsFactors=FALSE))
  })
  do.call(rbind,out)
}

# V2 utilities
null_coalesce <- function(x,y) if(is.null(x)) y else x

# Robust union-of-columns row bind. Base rbind() fails when scenario-specific
# outputs (e.g. COUPLED phase-decomposition metrics) add columns that RI/DEBATE
# do not have. Missing columns are filled with NA before binding.
rbind_fill <- function(xs) {
  if(is.null(xs)) return(data.frame())
  if(!is.list(xs) || is.data.frame(xs)) xs <- list(xs)
  xs <- xs[!vapply(xs, function(x) is.null(x) || (is.data.frame(x) && nrow(x)==0L), logical(1))]
  if(!length(xs)) return(data.frame())
  xs <- lapply(xs, function(x) as.data.frame(x, stringsAsFactors=FALSE))
  all_names <- unique(unlist(lapply(xs, names), use.names=FALSE))
  xs <- lapply(xs, function(x) {
    miss <- setdiff(all_names, names(x))
    if(length(miss)) for(nm in miss) x[[nm]] <- NA
    x[, all_names, drop=FALSE]
  })
  out <- do.call(rbind, xs)
  rownames(out) <- NULL
  out
}
safe_sum <- function(x) if(sum(is.finite(x))>0) sum(x,na.rm=TRUE) else NA_real_
safe_prop <- function(num,den) ifelse(is.finite(den)&den>0,num/den,NA_real_)


# ============================================================================
# 01_data_ingest.R
# ============================================================================
P <- read.csv(file.path('data','article','MOVICI_SMA_ARTICLE_DATA.csv'),
              check.names=FALSE,stringsAsFactors=FALSE,fileEncoding='UTF-8-BOM')
DYADS_EMP <- read.csv(file.path('data','article','MOVICI_SMA_DYADS.csv'),
                      check.names=FALSE,stringsAsFactors=FALSE,fileEncoding='UTF-8-BOM')

stopifnot(nrow(P)==96)
T1_COLS <- sprintf('K_QCM%02d_T1',1:20)
T2_COLS <- sprintf('K_QCM%02d_T2',1:20)
T3_COLS <- sprintf('K_QCM%02d_T3',1:20)
stopifnot(all(T1_COLS %in% names(P)),all(T2_COLS %in% names(P)),all(T3_COLS %in% names(P)))
ITEMS_T1 <- as.matrix(P[,T1_COLS]); storage.mode(ITEMS_T1)<-'numeric'
ITEMS_T2 <- as.matrix(P[,T2_COLS]); storage.mode(ITEMS_T2)<-'numeric'
ITEMS_T3 <- as.matrix(P[,T3_COLS]); storage.mode(ITEMS_T3)<-'numeric'

parent_mean <- function(a,b) {
  x<-cbind(as.numeric(a),as.numeric(b)); out<-rowMeans(x,na.rm=TRUE)
  out[rowSums(is.finite(x))==0]<-NA_real_; out
}
edu<-parent_mean(P$QP_NivETU_Parent1,P$QP_NivETU_Parent2)
pos<-parent_mean(P$QP_PosSocP1,P$QP_PosSocP2)
eco<-parent_mean(P$QP_RMM_Parent1,P$QP_RMM_Parent2)
components<-cbind(zscore(edu),zscore(pos),zscore(eco))
SES_RAW<-rowMeans(components,na.rm=TRUE); SES_RAW[rowSums(is.finite(components))<2]<-NA_real_

W_RAW<-rowMeans(cbind(zscore(P$VE_TotVexRap),zscore(P$VE_TotVbienRap)),na.rm=TRUE)
W_RAW[rowSums(is.finite(cbind(P$VE_TotVexRap,P$VE_TotVbienRap)))<2]<-NA_real_
W_PROXY<-zscore(W_RAW)
wdf<-data.frame(w=W_PROXY,t1=row_sum_na(ITEMS_T1),ses=SES_RAW,condition=P$RI_Condition)
wcc<-complete.cases(wdf)
ww<-wdf[wcc,,drop=FALSE]; ww$zT1<-zscore(ww$t1); ww$zSES<-zscore(ww$ses); ww$COOP<-as.numeric(ww$condition=='COOP')
wf<-lm(w~zT1+zSES+COOP,data=ww)
W_STATE<-rep(0,nrow(P)); W_STATE[wcc]<-zscore(residuals(wf))

ITEM_EASE_RAW<-colMeans(ITEMS_T1,na.rm=TRUE)
ITEM_EASE_Z<-zscore(ITEM_EASE_RAW)

# Fixed common evaluation references. These are never recomputed by scenario or step.
K_REF_PROP_MEAN <- mean(P$K_GLOBAL_T2,na.rm=TRUE)
K_REF_PROP_SD <- sd(P$K_GLOBAL_T2,na.rm=TRUE)
SELF_REF_MEAN <- mean(P$QM_AutoEval_2_PostRI,na.rm=TRUE)
SELF_REF_SD <- sd(P$QM_AutoEval_2_PostRI,na.rm=TRUE)

AGENTS <- data.frame(
  ID_MOVICI=P$ID_MOVICI,
  condition=P$QP_GrCondition,
  SES_raw=SES_RAW,
  W_proxy=W_PROXY,
  W_state=W_STATE,
  M_T1=as.numeric(P$QP_AutoEvalConTopic_T1_PreQ),
  M_T2=as.numeric(P$QM_AutoEval_2_PostRI),
  M_T3=as.numeric(P$QM_AutoEval_2_PostD),
  Visibility=as.numeric(P$DEB_share_group_words),
  RelationalStyle=as.numeric(P$DEB_rel_SA_balance),
  EmpiricalDebateSize=as.numeric(P$DEB_roster_size),
  stringsAsFactors=FALSE
)

EMP_GROUP_SIZE_COUNTS <- table(factor(AGENTS$EmpiricalDebateSize,levels=c(2,3,4)))
EMP_GROUP_SIZE_SHARE <- as.numeric(EMP_GROUP_SIZE_COUNTS)/sum(EMP_GROUP_SIZE_COUNTS)
names(EMP_GROUP_SIZE_SHARE) <- c('2','3','4')
EMP_GROUP_SIZE_COUNTS_BY_CONDITION <- table(AGENTS$condition,factor(AGENTS$EmpiricalDebateSize,levels=c(2,3,4)))
EMP_GROUP_SIZE_SHARE_BY_CONDITION <- prop.table(EMP_GROUP_SIZE_COUNTS_BY_CONDITION,1)

SERP_SHARE_EMP <- as.numeric(P$RatioTpsExplorationNav)
Z_SERP_SHARE_EMP <- (SERP_SHARE_EMP-ri_param('SERPshare_ref_mean',cfg('ri_model')))/ri_param('SERPshare_ref_sd',cfg('ri_model'))

# Fixed empirical scaling of debate source cues, matching the audited Debate package.
ev <- data.frame(evaluator_ID=DYADS_EMP$evaluator_ID,
                 evaluatee_ID=DYADS_EMP$evaluatee_ID,
                 stringsAsFactors=FALSE)
target_vis <- AGENTS$Visibility[match(ev$evaluatee_ID,AGENTS$ID_MOVICI)]
target_rel <- AGENTS$RelationalStyle[match(ev$evaluatee_ID,AGENTS$ID_MOVICI)]
vis_wc <- ave(target_vis,ev$evaluator_ID,FUN=function(v)v-mean(v,na.rm=TRUE))
rel_wc <- ave(target_rel,ev$evaluator_ID,FUN=function(v)v-mean(v,na.rm=TRUE))
VIS_SD_EMP <- sd(vis_wc,na.rm=TRUE)
REL_SD_EMP <- sd(rel_wc,na.rm=TRUE)

write.csv(AGENTS,file.path('data','derived','agents_common.csv'),row.names=FALSE,na='')
write.csv(data.frame(reference=c('K_REF_PROP_MEAN','K_REF_PROP_SD','SELF_REF_MEAN','SELF_REF_SD'),
                     value=c(K_REF_PROP_MEAN,K_REF_PROP_SD,SELF_REF_MEAN,SELF_REF_SD)),
          file.path('data','derived','common_fixed_references.csv'),row.names=FALSE)


# ============================================================================
# 02_common_state.R
# ============================================================================
CORE_N_ITEMS <- ncol(ITEMS_T1)

make_base_state <- function(process) {
  process<-toupper(process)
  if(process %in% c('RI','COUPLED')) {
    items<-ITEMS_T1
    items[!is.finite(items)]<-0
    self_raw<-AGENTS$M_T1
    baseline_phase<-'T1'
  } else {
    items<-ITEMS_T2
    self_raw<-AGENTS$M_T2
    baseline_phase<-'T2'
  }
  kprop<-rowMeans(items,na.rm=TRUE)
  data.frame(
    ID_MOVICI=AGENTS$ID_MOVICI,
    condition=AGENTS$condition,
    empirical_condition=AGENTS$condition,
    SES_raw=AGENTS$SES_raw,
    W_proxy=AGENTS$W_proxy,
    W_state=AGENTS$W_state,
    SelfRaw=self_raw,
    SelfCredit_z=z_fixed(self_raw,SELF_REF_MEAN,SELF_REF_SD),
    K_prop=kprop,
    K_z_common=z_fixed(kprop,K_REF_PROP_MEAN,K_REF_PROP_SD),
    baseline_phase=baseline_phase,
    stringsAsFactors=FALSE
  )
}

make_world <- function(process,info_regime,run=1L,condition_override=NULL,profile_mode='OBSERVED') {
  state<-make_base_state(process)
  if(!is.null(condition_override)) state$condition[]<-toupper(condition_override)
  items<-if(toupper(process) %in% c('RI','COUPLED')) ITEMS_T1 else ITEMS_T2
  if(toupper(process) %in% c('RI','COUPLED')) items[!is.finite(items)]<-0
  intro_step<-rep(0L,ncol(items))
  ever_exposed<-matrix(FALSE,nrow=nrow(items),ncol=ncol(items))
  list(
    process=toupper(process),info_regime=toupper(info_regime),
    state=state,items=items,item_ease_raw=ITEM_EASE_RAW,item_ease_z=ITEM_EASE_Z,
    intro_step=intro_step,ever_exposed=ever_exposed,
    baseline_items=items,baseline_K=state$K_prop,
    baseline_stock=rowSums(items,na.rm=TRUE),
    baseline_self=state$SelfCredit_z,
    previous_items=items,previous_K=state$K_prop,
    core_n_items=ncol(items),
    relational_memory=new.env(hash=TRUE,parent=emptyenv()),
    fixed_groups=NULL,
    profiles=prepare_source_profiles(AGENTS$ID_MOVICI,run=run,profile_mode=profile_mode,target_condition=condition_override)
  )
}

refresh_state_from_items <- function(world) {
  world$state$K_prop<-rowMeans(world$items,na.rm=TRUE)
  world$state$K_z_common<-z_fixed(world$state$K_prop,K_REF_PROP_MEAN,K_REF_PROP_SD)
  world
}

add_new_items <- function(world, step, mode=c('unknown','distributed'), run=1L) {
  mode<-match.arg(mode)
  nnew<-cfg_int('new_items_per_cycle')
  if(nnew<=0) return(world)
  set.seed(MASTER_SEED + 5100000L + as.integer(run)*10000L + step*100L + ncol(world$items)*31L)
  ease_idx<-sample(seq_along(ITEM_EASE_RAW),nnew,replace=TRUE)
  new_raw<-ITEM_EASE_RAW[ease_idx]; new_z<-ITEM_EASE_Z[ease_idx]
  n<-nrow(world$items)
  if(mode=='unknown') new_states<-matrix(0,nrow=n,ncol=nnew)
  else {
    new_states<-sapply(new_raw,function(p)rbinom(n,1,p))
    if(nnew==1) new_states<-matrix(new_states,ncol=1)
  }
  world$items<-cbind(world$items,new_states)
  world$previous_items<-pad_state(world$previous_items,nnew,fill=0)
  world$baseline_items<-pad_state(world$baseline_items,nnew,fill=0)
  old_pool<-ncol(world$ever_exposed)
  world$ever_exposed<-pad_state(world$ever_exposed,nnew,fill=FALSE)
  if(mode=='distributed') world$ever_exposed[,(old_pool+1):(old_pool+nnew)]<-new_states==1
  world$item_ease_raw<-c(world$item_ease_raw,new_raw)
  world$item_ease_z<-c(world$item_ease_z,new_z)
  world$intro_step<-c(world$intro_step,rep(step,nnew))
  refresh_state_from_items(world)
}

common_metrics <- function(world, prev_items, state_gains, state_losses, step,
                           learning_acq=NULL,learning_loss=NULL,exposures=NULL,state_additions=NULL,
                           accum=NULL,extra=list()) {
  items<-world$items; n<-nrow(items); pool<-ncol(items)
  if(ncol(prev_items)<pool) prev_items<-pad_state(prev_items,pool-ncol(prev_items),fill=0)
  learning_acq<-null_coalesce(learning_acq,state_gains)
  learning_loss<-null_coalesce(learning_loss,state_losses)
  exposures<-null_coalesce(exposures,rep(NA_real_,n))
  state_additions<-null_coalesce(state_additions,rep(0,n))
  if(is.null(accum)) accum<-list()

  prior_correct<-rowSums(prev_items==1,na.rm=TRUE)
  prior_incorrect<-rowSums(prev_items==0,na.rm=TRUE)
  retained<-rowSums(prev_items==1 & items==1,na.rm=TRUE)
  Kprop<-rowMeans(items,na.rm=TRUE)
  Kz<-z_fixed(Kprop,K_REF_PROP_MEAN,K_REF_PROP_SD)
  selfz<-world$state$SelfCredit_z
  bias<-selfz-Kz
  base_bias<-world$baseline_self-z_fixed(world$baseline_K,K_REF_PROP_MEAN,K_REF_PROP_SD)

  stock<-rowSums(items,na.rm=TRUE)
  baseline_stock<-world$baseline_stock
  core_idx<-seq_len(min(world$core_n_items,pool))
  core_stock<-rowSums(items[,core_idx,drop=FALSE],na.rm=TRUE)
  core_density<-core_stock/length(core_idx)
  new_idx<-which(world$intro_step>=2)
  new_stock<-if(length(new_idx))rowSums(items[,new_idx,drop=FALSE],na.rm=TRUE) else rep(0,n)
  new_density<-if(length(new_idx))rowMeans(items[,new_idx,drop=FALSE],na.rm=TRUE) else rep(NA_real_,n)

  exposed_n<-rowSums(world$ever_exposed)
  correct_exposed<-rowSums(items*world$ever_exposed,na.rm=TRUE)
  encountered_accuracy<-ifelse(exposed_n>0,correct_exposed/exposed_n,NA_real_)

  cum_acq<-null_coalesce(accum$cum_learning_acq,rep(NA_real_,n))
  cum_loss<-null_coalesce(accum$cum_learning_loss,rep(NA_real_,n))
  cum_exp<-null_coalesce(accum$cum_exposures,rep(NA_real_,n))
  cum_seed<-null_coalesce(accum$cum_state_additions,rep(NA_real_,n))

  out<-data.frame(
    ID_MOVICI=world$state$ID_MOVICI,
    condition=world$state$condition,
    empirical_condition=world$state$empirical_condition,
    SES_raw=world$state$SES_raw,
    W_proxy=world$state$W_proxy,

    KnowledgeStock=stock,
    BaselineKnowledgeStock=baseline_stock,
    NetKnowledgeStockGain=stock-baseline_stock,
    KnowledgeDensity=Kprop,
    K_prop=Kprop,
    K_eq20=20*Kprop,
    K_z_common=Kz,
    K_baseline_prop=world$baseline_K,
    DeltaKnowledgeDensityBaseline=Kprop-world$baseline_K,
    DeltaK_baseline=Kprop-world$baseline_K,
    DeltaK_step=Kprop-rowMeans(prev_items,na.rm=TRUE),
    CoreKnowledgeStock=core_stock,
    CoreKnowledgeStockGain=core_stock-rowSums(world$baseline_items[,core_idx,drop=FALSE],na.rm=TRUE),
    CoreKnowledgeDensity=core_density,
    NewKnowledgeStock=new_stock,
    NewKnowledgeDensity=new_density,

    SelfRaw=world$state$SelfRaw,
    SelfCredit_z=selfz,
    SelfBias_z=bias,
    SelfOverCredit_z=pmax(bias,0),
    SelfUnderCredit_z=pmax(-bias,0),
    AbsCalibrationError=abs(bias),
    CalibrationImprovement=abs(base_bias)-abs(bias),

    StateGainCount=state_gains,
    StateLossCount=state_losses,
    StateAdditionCount=state_additions,
    LearningAcquisitionCount=learning_acq,
    LearningLossCount=learning_loss,
    ExposureCount=exposures,
    AcquisitionCount=state_gains,
    LossCount=state_losses,
    AcquisitionRate=ifelse(prior_incorrect>0,state_gains/prior_incorrect,NA_real_),
    LossRate=ifelse(prior_correct>0,state_losses/prior_correct,NA_real_),
    GrossLearningAcquisitionPerExposure=ifelse(is.finite(exposures)&exposures>0,learning_acq/exposures,NA_real_),
    GrossLearningLossPerExposure=ifelse(is.finite(exposures)&exposures>0,learning_loss/exposures,NA_real_),
    RetentionRate=ifelse(prior_correct>0,retained/prior_correct,NA_real_),
    TurnoverRate=(state_gains+state_losses)/pool,
    StateTurnoverRate=(state_gains+state_losses)/pool,
    GrossLearningEventRate=(learning_acq+learning_loss)/pool,

    CumulativeLearningAcquisitions=cum_acq,
    CumulativeLearningLosses=cum_loss,
    CumulativeLearningBalance=cum_acq-cum_loss,
    CumulativeExposureCount=cum_exp,
    CumulativeStateAdditions=cum_seed,
    LearningEfficiencyPerExposure=ifelse(is.finite(cum_exp)&cum_exp>0,cum_acq/cum_exp,NA_real_),
    NetLearningPerExposure=ifelse(is.finite(cum_exp)&cum_exp>0,(cum_acq-cum_loss)/cum_exp,NA_real_),

    PoolSize=pool,
    EncounteredDistinctCount=exposed_n,
    Coverage=ifelse(pool>0,exposed_n/pool,NA_real_),
    EncounteredAccuracy=encountered_accuracy,
    NewKnowledgeShare=ifelse(stock>0,new_stock/stock,0),
    stringsAsFactors=FALSE
  )
  for(nm in names(extra)) out[[nm]]<-extra[[nm]]
  out
}

population_metrics <- function(panel_step, baseline_variance) {
  data.frame(
    N_agents=nrow(panel_step),
    KnowledgeStock_mean=safe_mean(panel_step$KnowledgeStock),
    KnowledgeStock_SD=safe_sd(panel_step$KnowledgeStock),
    NetKnowledgeStockGain_mean=safe_mean(panel_step$NetKnowledgeStockGain),
    KnowledgeDensity_mean=safe_mean(panel_step$KnowledgeDensity),
    K_mean=safe_mean(panel_step$KnowledgeDensity),
    K_SD=safe_sd(panel_step$KnowledgeDensity),
    KnowledgeVariance=var(panel_step$KnowledgeDensity,na.rm=TRUE),
    VarianceReduction=if(is.finite(baseline_variance)&&baseline_variance>0) 1-var(panel_step$KnowledgeDensity,na.rm=TRUE)/baseline_variance else NA_real_,
    MeanDeltaK=safe_mean(panel_step$DeltaKnowledgeDensityBaseline),
    CoreKnowledgeStock_mean=safe_mean(panel_step$CoreKnowledgeStock),
    NewKnowledgeStock_mean=safe_mean(panel_step$NewKnowledgeStock),
    MeanSelfCredit=safe_mean(panel_step$SelfCredit_z),
    MeanSelfBias=safe_mean(panel_step$SelfBias_z),
    MeanSelfOverCredit=safe_mean(panel_step$SelfOverCredit_z),
    MeanSelfUnderCredit=safe_mean(panel_step$SelfUnderCredit_z),
    MeanAbsCalibrationError=safe_mean(panel_step$AbsCalibrationError),
    MeanCalibrationImprovement=safe_mean(panel_step$CalibrationImprovement),
    SelfKnowledgeCorrelation=safe_cor(panel_step$SelfCredit_z,panel_step$K_z_common),
    MeanAcquisitionRate=safe_mean(panel_step$AcquisitionRate),
    MeanLossRate=safe_mean(panel_step$LossRate),
    MeanRetentionRate=safe_mean(panel_step$RetentionRate),
    MeanTurnoverRate=safe_mean(panel_step$TurnoverRate),
    MeanCumulativeLearningAcquisitions=safe_mean(panel_step$CumulativeLearningAcquisitions),
    MeanCumulativeLearningLosses=safe_mean(panel_step$CumulativeLearningLosses),
    MeanCumulativeLearningBalance=safe_mean(panel_step$CumulativeLearningBalance),
    MeanCumulativeExposureCount=safe_mean(panel_step$CumulativeExposureCount),
    MeanLearningEfficiencyPerExposure=safe_mean(panel_step$LearningEfficiencyPerExposure),
    MeanNetLearningPerExposure=safe_mean(panel_step$NetLearningPerExposure),
    stringsAsFactors=FALSE
  )
}


# ============================================================================
# 03_ri_engine.R
# ============================================================================
ri_probabilities <- function(world, model=cfg('ri_model')) {
  states<-world$items
  k20<-20*rowMeans(states,na.rm=TRUE)
  zK<-(k20-ri_param('K_ref_mean',model))/ri_param('K_ref_sd',model)
  zSES<-(world$state$SES_raw-ri_param('SES_ref_mean',model))/ri_param('SES_ref_sd',model)
  zSES[!is.finite(zSES)]<-0
  zW<-(world$state$W_state-ri_param('W_ref_mean',model))/ri_param('W_ref_sd',model)
  zW[!is.finite(zW)]<-0
  bW<-if(model %in% c('V1.3','V1.4'))ri_param('bW',model) else 0
  pL<-matrix(NA_real_,nrow(states),ncol(states)); pF<-pL
  for(j in seq_len(ncol(states))) {
    pL[,j]<-logistic(ri_param('a_plus',model)+ri_param('bK_plus',model)*zK+
                       (if(RUNTIME_ABLATION=='NO_SES_RI')0 else ri_param('bSES',model))*zSES+ri_param('gamma_item',model)*world$item_ease_z[j]+bW*zW)
    pF[,j]<-logistic(ri_param('a_minus',model)+ri_param('bK_minus',model)*zK-
                       (if(RUNTIME_ABLATION=='NO_SES_RI')0 else ri_param('bSES',model))*zSES-ri_param('gamma_item',model)*world$item_ease_z[j]-bW*zW)
  }
  list(learn=pL,loss=pF)
}

ri_meta_update <- function(M_prev,K_eq20,serp_cue_z,eps=NULL) {
  model<-cfg('ri_model')
  zM<-(M_prev-ri_param('M_ref_mean',model))/ri_param('M_ref_sd',model)
  zK<-(K_eq20-ri_param('M_K_ref_mean',model))/ri_param('M_K_ref_sd',model)
  mu<-ri_param('m_intercept',model)+ri_param('bM_persistence',model)*zM+
      ri_param('bK_monitoring',model)*zK+ri_param('bSERPshare_monitoring',model)*serp_cue_z
  if(is.null(eps)) eps<-rnorm(length(mu),0,ri_param('sigma_M',model))
  clamp(mu+eps,1,4)
}

ri_full_pool_update <- function(world) {
  p<-ri_probabilities(world)
  before<-world$items
  u<-matrix(runif(length(before)),nrow=nrow(before),ncol=ncol(before))
  out<-before
  learn<-before==0 & is.finite(before)
  lose<-before==1 & is.finite(before)
  out[learn]<-as.numeric(u[learn]<p$learn[learn])
  out[lose]<-as.numeric(u[lose]>=p$loss[lose])
  acquisitions<-rowSums(before==0 & out==1,na.rm=TRUE)
  losses<-rowSums(before==1 & out==0,na.rm=TRUE)
  exposures<-rowSums(is.finite(before))
  world$items<-out
  world$ever_exposed[,seq_len(ncol(out))]<-TRUE
  list(world=world,acquisitions=acquisitions,losses=losses,exposures=exposures)
}

ri_limited_exposure_update <- function(world, step) {
  p<-ri_probabilities(world); before<-world$items; out<-before
  n<-nrow(before); pool<-ncol(before)
  budget<-cfg_int('ri_exposure_budget')
  newslots<-cfg_int('ri_new_exposure_slots')
  p_rel<-cfg_num('ri_reliability')
  cur_new<-which(world$intro_step==step)
  old_idx<-setdiff(seq_len(pool),cur_new)
  acquisitions<-losses<-exposures<-numeric(n)
  for(i in seq_len(n)) {
    a<-if(length(cur_new))sample(cur_new,min(newslots,length(cur_new)),replace=FALSE) else integer(0)
    rem<-max(0,budget-length(a))
    b<-if(length(old_idx))sample(old_idx,min(rem,length(old_idx)),replace=FALSE) else integer(0)
    idx<-c(a,b)
    exposures[i]<-length(idx)
    if(!length(idx)) next
    rel<-runif(length(idx))<p_rel
    uu<-runif(length(idx))
    world$ever_exposed[i,idx]<-TRUE
    for(s in seq_along(idx)) {
      j<-idx[s]; prior<-before[i,j]
      if(rel[s] && prior==0 && uu[s]<p$learn[i,j]) {
        out[i,j]<-1; acquisitions[i]<-acquisitions[i]+1
      } else if(!rel[s] && prior==1 && uu[s]<p$loss[i,j]) {
        out[i,j]<-0; losses[i]<-losses[i]+1
      }
    }
  }
  world$items<-out
  list(world=world,acquisitions=acquisitions,losses=losses,exposures=exposures)
}

ri_episode <- function(world,run,step,allow_add=TRUE) {
  prev<-world$items
  if(world$info_regime=='RENEWED' && step>=2 && allow_add) {
    world<-add_new_items(world,step,mode='unknown',run=run)
    prev<-pad_state(prev,ncol(world$items)-ncol(prev),fill=0)
  }
  set.seed(MASTER_SEED + run*100000L + step*100L + 11L)
  # Step 1 is the empirical anchoring episode on the original 20-item pool.
  # From step 2 onward, FIXED and RENEWED use the same limited-exposure engine;
  # the regimes differ only in whether new information atoms enter the world.
  if(step==1) z<-ri_full_pool_update(world)
  else z<-ri_limited_exposure_update(world,step)
  world<-refresh_state_from_items(z$world)

  set.seed(MASTER_SEED + run*100000L + step*100L + 12L)
  cue<-if(step==1 && exists('Z_SERP_SHARE_EMP')) Z_SERP_SHARE_EMP else rnorm(nrow(world$items))
  Mprev<-clamp(world$state$SelfRaw,1,4)
  Mnew<-ri_meta_update(Mprev,20*world$state$K_prop,cue)
  world$state$SelfRaw<-Mnew
  world$state$SelfCredit_z<-z_fixed(Mnew,SELF_REF_MEAN,SELF_REF_SD)

  list(world=world,prev_items=prev,
       acquisitions=z$acquisitions,losses=z$losses,
       learning_acquisitions=z$acquisitions,learning_losses=z$losses,
       exposures=z$exposures,state_additions=rep(0,nrow(world$items)))
}


# ============================================================================
# 04_debate_engine.R
# ============================================================================
prepare_source_profiles <- function(ids,run=1L,profile_mode='OBSERVED',target_condition=NULL) {
  profile_mode<-toupper(profile_mode)
  if(profile_mode=='OBSERVED') {
    x<-AGENTS[match(ids,AGENTS$ID_MOVICI),c('ID_MOVICI','Visibility','RelationalStyle')]
    donor<-AGENTS[complete.cases(AGENTS[,c('Visibility','RelationalStyle')]),c('Visibility','RelationalStyle'),drop=FALSE]
    miss<-which(!is.finite(x$Visibility)|!is.finite(x$RelationalStyle))
    if(length(miss)&&nrow(donor)) {
      set.seed(MASTER_SEED + 40404L + as.integer(run)*1000L)
      take<-sample(seq_len(nrow(donor)),length(miss),replace=TRUE)
      x$Visibility[miss]<-donor$Visibility[take]
      x$RelationalStyle[miss]<-donor$RelationalStyle[take]
    }
    return(x)
  }
  if(profile_mode=='CONDITION_CONSISTENT') {
    cc<-toupper(target_condition)
    donor<-AGENTS[AGENTS$condition==cc & complete.cases(AGENTS[,c('Visibility','RelationalStyle')]),
                  c('Visibility','RelationalStyle'),drop=FALSE]
    if(!nrow(donor)) stop('No condition-consistent profile donors for ',cc)
    # Common latent ranks across COOP/COMP arms; donor pools differ by condition.
    set.seed(MASTER_SEED + 40404L + as.integer(run)*1000L)
    u<-runif(length(ids))
    take<-pmin(nrow(donor),pmax(1L,as.integer(floor(u*nrow(donor)))+1L))
    x<-data.frame(ID_MOVICI=ids,Visibility=donor$Visibility[take],RelationalStyle=donor$RelationalStyle[take],stringsAsFactors=FALSE)
    return(x)
  }
  stop('Unknown profile_mode: ',profile_mode)
}

best_group_size_counts <- function(n,target_share=EMP_GROUP_SIZE_SHARE) {
  best<-NULL; besterr<-Inf
  for(g2 in 0:floor(n/2)) for(g3 in 0:floor(n/3)) {
    rem<-n-2*g2-3*g3
    if(rem<0 || rem%%4!=0) next
    g4<-rem/4
    if(g2+g3+g4==0) next
    sh<-c('2'=2*g2/n,'3'=3*g3/n,'4'=4*g4/n)
    err<-sum((sh-target_share[c('2','3','4')])^2)
    if(err<besterr) { besterr<-err; best<-c('2'=g2,'3'=g3,'4'=g4) }
  }
  if(is.null(best)) stop('Could not partition ',n,' agents into groups 2/3/4')
  as.integer(best)
}

make_groups <- function(ids,group_size_mode=cfg('group_size_mode'),target_share=EMP_GROUP_SIZE_SHARE) {
  ids<-sample(ids,length(ids),replace=FALSE)
  mode<-toupper(group_size_mode)
  if(mode=='ALL4') {
    gs<-cfg_int('group_size_fixed')
    g<-split(ids,ceiling(seq_along(ids)/gs))
    if(length(g)>1 && length(g[[length(g)]])==1 && length(g[[length(g)-1]])>=3) {
      donor<-g[[length(g)-1]]; g[[length(g)]]<-c(tail(donor,1),g[[length(g)]])
      g[[length(g)-1]]<-head(donor,-1)
    }
    return(g)
  }
  if(mode=='EMPIRICAL_DISTRIBUTION') {
    counts<-best_group_size_counts(length(ids),target_share=target_share)
    sizes<-c(rep(2,counts[1]),rep(3,counts[2]),rep(4,counts[3]))
    sizes<-sample(sizes,length(sizes),replace=FALSE)
    g<-list(); pos<-1L
    for(ii in seq_along(sizes)) { g[[ii]]<-ids[pos:(pos+sizes[ii]-1L)]; pos<-pos+sizes[ii] }
    return(g)
  }
  stop('Unknown group_size_mode: ',group_size_mode)
}
recognition_accuracy <- function(k,e) {
  ok<-is.finite(k)&is.finite(e); k<-k[ok]; e<-e[ok]
  if(length(k)<2)return(NA_real_)
  vals<-numeric(0)
  for(a in 1:(length(k)-1)) for(b in (a+1):length(k)) {
    dk<-k[a]-k[b]; de<-e[a]-e[b]
    if(dk==0)next
    vals<-c(vals,as.numeric(sign(dk)==sign(de)))
  }
  if(length(vals))mean(vals) else NA_real_
}

softmax_vec <- function(x) {
  ok<-is.finite(x); out<-rep(NA_real_,length(x))
  if(!any(ok))return(out)
  y<-x[ok]-max(x[ok]); e<-exp(y); out[ok]<-e/sum(e); out
}

build_debate_dyads <- function(world,groups) {
  rows<-list(); k<-0L
  for(g in groups) if(length(g)>=2) for(i in g) for(j in g[g!=i]) {
    k<-k+1L; rows[[k]]<-data.frame(evaluator_ID=i,evaluatee_ID=j,stringsAsFactors=FALSE)
  }
  if(!length(rows))return(data.frame())
  d<-do.call(rbind,rows)
  si<-match(d$evaluator_ID,world$state$ID_MOVICI); sj<-match(d$evaluatee_ID,world$state$ID_MOVICI)
  d$condition<-world$state$condition[si]
  d$Ki<-world$state$K_prop[si]; d$Kj<-world$state$K_prop[sj]
  d$zKi<-world$state$K_z_common[si]; d$zKj<-world$state$K_z_common[sj]
  d$SelfCreditPre<-world$state$SelfCredit_z[si]
  d$Visibility<-world$profiles$Visibility[match(d$evaluatee_ID,world$profiles$ID_MOVICI)]
  d$RelationalStyle<-world$profiles$RelationalStyle[match(d$evaluatee_ID,world$profiles$ID_MOVICI)]
  d$Visibility_wc<-ave(d$Visibility,d$evaluator_ID,FUN=function(v)v-mean(v,na.rm=TRUE))
  d$RelationalStyle_wc<-ave(d$RelationalStyle,d$evaluator_ID,FUN=function(v)v-mean(v,na.rm=TRUE))
  d$zVisibility_wc<-d$Visibility_wc/VIS_SD_EMP
  d$zRelationalStyle_wc<-d$RelationalStyle_wc/REL_SD_EMP
  d$COMP<-as.numeric(d$condition=='COMP')
  d$RecognizedExpertiseSignal<-deb_param('Evis_intercept')+
    deb_param('Evis_beta_visibility')*d$zVisibility_wc+
    deb_param('Evis_beta_COMP')*d$COMP+
    deb_param('Evis_beta_visibility_COMP')*d$zVisibility_wc*d$COMP+
    deb_param('sigma_Evis')*rnorm(nrow(d))
  d$BenevolenceSignal<-deb_param('B_intercept')+
    deb_param('B_beta_relational_style')*d$zRelationalStyle_wc+
    deb_param('B_beta_COMP')*d$COMP+
    deb_param('sigma_B')*rnorm(nrow(d))
  d$OtherCreditSignal<-d$RecognizedExpertiseSignal+deb_param('alpha_B')*d$BenevolenceSignal
  d$key<-paste(d$evaluator_ID,d$evaluatee_ID,sep='|')
  d
}

apply_relational_memory <- function(world,d) {
  if(!nrow(d))return(list(world=world,dyad=d))
  if(RUNTIME_ABLATION=='NO_RELATIONAL_MEMORY') {
    d$RecognizedExpertise<-d$RecognizedExpertiseSignal
    d$OtherCredit<-d$OtherCreditSignal
    return(list(world=world,dyad=d))
  }
  R<-C<-numeric(nrow(d))
  for(i in seq_len(nrow(d))) {
    key<-d$key[i]
    if(exists(key,envir=world$relational_memory,inherits=FALSE)) {
      old<-get(key,envir=world$relational_memory,inherits=FALSE); n0<-old[1]; r0<-old[2]; c0<-old[3]
    } else { n0<-0; r0<-0; c0<-0 }
    n1<-n0+1
    R[i]<-(n0*r0+d$RecognizedExpertiseSignal[i])/n1
    C[i]<-(n0*c0+d$OtherCreditSignal[i])/n1
    assign(key,c(n1,R[i],C[i]),envir=world$relational_memory)
  }
  d$RecognizedExpertise<-R; d$OtherCredit<-C
  list(world=world,dyad=d)
}

finalize_debate_dyads <- function(d) {
  if(!nrow(d))return(d)
  base_weight<-logistic((d$OtherCredit-d$SelfCreditPre)/deb_param('partner_weight_scale'))
  d$PartnerWeightUnablated<-base_weight
  if(RUNTIME_ABLATION=='NO_CREDIT_GATING') {
    d$PartnerWeight<-rep(0.5,nrow(d))
  } else if(RUNTIME_ABLATION=='NO_DIFFERENTIAL_CREDIT_ALLOCATION') {
    # Preserve each evaluator's mean receptivity in the current episode while
    # removing differential weighting across that evaluator's current partners.
    d$PartnerWeight<-ave(base_weight,d$evaluator_ID,FUN=function(x) rep(safe_mean(x),length(x)))
    pre<-tapply(base_weight,d$evaluator_ID,safe_mean)
    post<-tapply(d$PartnerWeight,d$evaluator_ID,safe_mean)
    common<-intersect(names(pre),names(post))
    err<-if(length(common))max(abs(pre[common]-post[common]),na.rm=TRUE) else 0
    if(is.finite(err) && err>1e-12) stop('Mean-receptivity preservation failed: ',err)
  } else {
    d$PartnerWeight<-base_weight
  }
  d$RecognitionBias<-d$RecognizedExpertise-d$zKj
  d$RecognitionError<-abs(d$RecognitionBias)
  d$OtherCreditBias<-d$OtherCredit-d$zKj
  d$OtherCreditCalibrationError<-abs(d$OtherCreditBias)
  d$UnderRecognitionMagnitude<-pmax(-d$RecognitionBias,0)
  d$OverRecognitionMagnitude<-pmax(d$RecognitionBias,0)
  d$UnderCreditMagnitude<-pmax(-d$OtherCreditBias,0)
  d$OverCreditMagnitude<-pmax(d$OtherCreditBias,0)
  d$RelativeCredit<-d$SelfCreditPre-d$OtherCredit
  d$Opportunity<-pmax(d$Kj-d$Ki,0)
  d$AccessibleOpportunity<-d$Opportunity*d$PartnerWeight
  d$MissedOpportunity<-d$Opportunity*(1-d$PartnerWeight)
  d$RecognitionRankReversal<-ifelse(d$Kj>d$Ki,as.numeric(d$RecognizedExpertise<=d$SelfCreditPre),NA_real_)
  d$CreditRankReversal<-ifelse(d$Kj>d$Ki,as.numeric(d$OtherCredit<=d$SelfCreditPre),NA_real_)
  d$UnderweightMoreExpert<-ifelse(d$Kj>d$Ki,as.numeric(d$PartnerWeight<.5),NA_real_)
  d$OverweightLessExpert<-ifelse(d$Kj<d$Ki,as.numeric(d$PartnerWeight>.5),NA_real_)
  d
}

aggregate_debate_metrics <- function(world,d) {
  ids<-world$state$ID_MOVICI
  out<-lapply(ids,function(id){
    g<-d[d$evaluator_ID==id,,drop=FALSE]
    blank<-data.frame(ID_MOVICI=id,
      RecognitionAccuracy=NA_real_,MeanRecognizedExpertise=NA_real_,MeanRecognitionBias=NA_real_,
      MeanRecognitionError=NA_real_,MeanUnderRecognitionMagnitude=NA_real_,MeanOverRecognitionMagnitude=NA_real_,
      MeanBenevolenceSignal=NA_real_,MeanOtherCredit=NA_real_,MeanOtherCreditBias=NA_real_,
      MeanOtherCreditCalibrationError=NA_real_,MeanUnderCreditMagnitude=NA_real_,MeanOverCreditMagnitude=NA_real_,
      MeanUnderRecognitionMoreExpertMagnitude=NA_real_,MeanUnderCreditMoreExpertMagnitude=NA_real_,
      MeanRelativeCreditSelfMinusMoreExpert=NA_real_,RelativeCreditSelfMinusOther=NA_real_,ExpertUseEfficiency=NA_real_,MissedCorrectiveOpportunityRate=NA_real_,
      RecognitionRankReversalRate=NA_real_,CreditRankReversalRate=NA_real_,UnderweightMoreExpertRate=NA_real_,
      OverweightLessExpertRate=NA_real_,WeightMoreExpert=NA_real_,WeightLessExpert=NA_real_,
      MoreExpertEncounterCount=NA_real_,LessExpertEncounterCount=NA_real_,CorrectiveOpportunityTotal=NA_real_,
      AccessibleCorrectiveOpportunityTotal=NA_real_,MissedCorrectiveOpportunityTotal=NA_real_,
      KnowledgeRecognitionCovariance=NA_real_,KnowledgeOtherCreditCovariance=NA_real_,ExpertiseAllocationGain=NA_real_,
      EpistemicCreditMisallocationIndex=NA_real_,EpistemicCreditAllocationIndex=NA_real_)
    if(!nrow(g))return(blank)

    valid<-is.finite(g$Opportunity)&is.finite(g$PartnerWeight)
    den<-sum(g$Opportunity[valid],na.rm=TRUE)
    eue<-if(den>0)sum(g$Opportunity[valid]*g$PartnerWeight[valid],na.rm=TRUE)/den else NA_real_
    mcor<-if(is.finite(eue))1-eue else NA_real_
    more<-is.finite(g$Kj)&is.finite(g$Ki)&g$Kj>g$Ki
    less<-is.finite(g$Kj)&is.finite(g$Ki)&g$Kj<g$Ki
    rec_rr<-more&is.finite(g$RecognitionRankReversal)
    cred_rr<-more&is.finite(g$CreditRankReversal)
    uw<-more&is.finite(g$UnderweightMoreExpert)
    ow<-less&is.finite(g$OverweightLessExpert)
    rk<-is.finite(g$zKj)&is.finite(g$RecognizedExpertise)
    ck<-is.finite(g$zKj)&is.finite(g$OtherCredit)
    covkr<-if(sum(rk)>=2 && length(unique(g$zKj[rk]))>1)cov(g$zKj[rk],g$RecognizedExpertise[rk]) else NA_real_
    covkc<-if(sum(ck)>=2 && length(unique(g$zKj[ck]))>1)cov(g$zKj[ck],g$OtherCredit[ck]) else NA_real_
    ea<-is.finite(g$Kj)&is.finite(g$RecognizedExpertise)
    alloc<-NA_real_
    if(sum(ea)>=2) {
      sw<-softmax_vec(g$RecognizedExpertise[ea]); alloc<-sum(sw*g$Kj[ea])-mean(g$Kj[ea])
    }
    rr_rate<-if(any(rec_rr))mean(g$RecognitionRankReversal[rec_rr],na.rm=TRUE) else NA_real_
    uw_rate<-if(any(uw))mean(g$UnderweightMoreExpert[uw],na.rm=TRUE) else NA_real_
    ow_rate<-if(any(ow))mean(g$OverweightLessExpert[ow],na.rm=TRUE) else NA_real_
    cr_rate<-if(any(cred_rr))mean(g$CreditRankReversal[cred_rr],na.rm=TRUE) else NA_real_
    misallocation_components<-c(mcor,cr_rate,uw_rate)
    misalloc<-if(any(is.finite(misallocation_components)))mean(misallocation_components[is.finite(misallocation_components)]) else NA_real_

    data.frame(ID_MOVICI=id,
      RecognitionAccuracy=recognition_accuracy(g$Kj,g$RecognizedExpertise),
      MeanRecognizedExpertise=safe_mean(g$RecognizedExpertise),
      MeanRecognitionBias=safe_mean(g$RecognitionBias),
      MeanRecognitionError=safe_mean(g$RecognitionError),
      MeanUnderRecognitionMagnitude=safe_mean(g$UnderRecognitionMagnitude),
      MeanOverRecognitionMagnitude=safe_mean(g$OverRecognitionMagnitude),
      MeanBenevolenceSignal=safe_mean(g$BenevolenceSignal),
      MeanOtherCredit=safe_mean(g$OtherCredit),
      MeanOtherCreditBias=safe_mean(g$OtherCreditBias),
      MeanOtherCreditCalibrationError=safe_mean(g$OtherCreditCalibrationError),
      MeanUnderCreditMagnitude=safe_mean(g$UnderCreditMagnitude),
      MeanOverCreditMagnitude=safe_mean(g$OverCreditMagnitude),
      MeanUnderRecognitionMoreExpertMagnitude=if(any(more))safe_mean(g$UnderRecognitionMagnitude[more]) else NA_real_,
      MeanUnderCreditMoreExpertMagnitude=if(any(more))safe_mean(g$UnderCreditMagnitude[more]) else NA_real_,
      MeanRelativeCreditSelfMinusMoreExpert=if(any(more))safe_mean(g$RelativeCredit[more]) else NA_real_,
      RelativeCreditSelfMinusOther=safe_mean(g$RelativeCredit),
      ExpertUseEfficiency=eue,
      MissedCorrectiveOpportunityRate=mcor,
      RecognitionRankReversalRate=rr_rate,
      CreditRankReversalRate=cr_rate,
      UnderweightMoreExpertRate=uw_rate,
      OverweightLessExpertRate=ow_rate,
      WeightMoreExpert=if(any(more&is.finite(g$PartnerWeight)))mean(g$PartnerWeight[more&is.finite(g$PartnerWeight)],na.rm=TRUE) else NA_real_,
      WeightLessExpert=if(any(less&is.finite(g$PartnerWeight)))mean(g$PartnerWeight[less&is.finite(g$PartnerWeight)],na.rm=TRUE) else NA_real_,
      MoreExpertEncounterCount=sum(more,na.rm=TRUE),
      LessExpertEncounterCount=sum(less,na.rm=TRUE),
      CorrectiveOpportunityTotal=safe_sum(g$Opportunity),
      AccessibleCorrectiveOpportunityTotal=safe_sum(g$AccessibleOpportunity),
      MissedCorrectiveOpportunityTotal=safe_sum(g$MissedOpportunity),
      KnowledgeRecognitionCovariance=covkr,
      KnowledgeOtherCreditCovariance=covkc,
      ExpertiseAllocationGain=alloc,
      EpistemicCreditMisallocationIndex=misalloc,
      EpistemicCreditAllocationIndex=if(is.finite(misalloc))1-misalloc else NA_real_)
  })
  do.call(rbind,out)
}

debate_social_transfer <- function(world,d) {
  before<-world$items; out<-before
  p<-ri_probabilities(world,model=cfg('debate_content_kernel_model'))
  ncontent<-cfg_int('debate_content_per_partner')
  success_acq<-matrix(FALSE,nrow=nrow(before),ncol=ncol(before))
  success_loss<-matrix(FALSE,nrow=nrow(before),ncol=ncol(before))
  exposures<-numeric(nrow(before))
  for(r in seq_len(nrow(d))) {
    i<-match(d$evaluator_ID[r],world$state$ID_MOVICI)
    j<-match(d$evaluatee_ID[r],world$state$ID_MOVICI)
    if(!is.finite(i)||!is.finite(j))next
    for(z in seq_len(ncontent)) {
      item<-sample.int(ncol(before),1)
      exposures[i]<-exposures[i]+1
      world$ever_exposed[i,item]<-TRUE
      if(before[i,item]==0 && before[j,item]==1) {
        pr<-p$learn[i,item]*d$PartnerWeight[r]
        if(runif(1)<pr) success_acq[i,item]<-TRUE
      } else if(before[i,item]==1 && before[j,item]==0) {
        pr<-p$loss[i,item]*d$PartnerWeight[r]
        if(runif(1)<pr) success_loss[i,item]<-TRUE
      }
    }
  }
  out[success_acq]<-1; out[success_loss]<-0
  acquisitions<-rowSums(before==0 & out==1,na.rm=TRUE)
  losses<-rowSums(before==1 & out==0,na.rm=TRUE)
  world$items<-out
  list(world=world,acquisitions=acquisitions,losses=losses,exposures=exposures)
}

debate_self_update <- function(world) {
  zK<-world$state$K_z_common
  prev<-world$state$SelfCredit_z
  coop<-as.numeric(world$state$condition=='COOP')
  eps<-rnorm(length(zK))
  if(cfg('debate_model')=='V1.3') {
    znew<-deb_param('rho')*prev+deb_param('beta_COOP')*zK*coop+deb_param('sigma_self_persistent')*eps
  } else {
    lam<-ifelse(coop==1,deb_param('lambda_COOP'),deb_param('lambda_COMP'))
    sig<-ifelse(coop==1,deb_param('sigma_self_COOP'),deb_param('sigma_self_COMP'))
    znew<-lam*zK+sig*eps
  }
  world$state$SelfCredit_z<-znew
  world$state$SelfRaw<-SELF_REF_MEAN+SELF_REF_SD*znew
  world
}

debate_episode <- function(world,run,step,allow_add=TRUE,learning=TRUE) {
  prev<-world$items
  seed_acq<-rep(0,nrow(world$items))
  if(world$info_regime=='RENEWED' && step>=2 && allow_add) {
    old_pool<-ncol(world$items)
    set.seed(MASTER_SEED + run*100000L + step*100L + 21L)
    world<-add_new_items(world,step,mode='distributed',run=run)
    prev<-pad_state(prev,ncol(world$items)-ncol(prev),fill=0)
    if(ncol(world$items)>old_pool) seed_acq<-rowSums(world$items[,(old_pool+1):ncol(world$items),drop=FALSE],na.rm=TRUE)
  }
  partner_mode<-toupper(cfg('debate_partner_mode'))
  if(partner_mode=='FIXED' && !is.null(world$fixed_groups)) {
    bycond<-world$fixed_groups
  } else {
    set.seed(MASTER_SEED + run*100000L + (if(partner_mode=='FIXED') 1L else step)*100L + 22L)
    spl<-split(world$state$ID_MOVICI,world$state$condition)
    bycond<-lapply(names(spl),function(cc) {
      targ<-if(cc %in% rownames(EMP_GROUP_SIZE_SHARE_BY_CONDITION)) as.numeric(EMP_GROUP_SIZE_SHARE_BY_CONDITION[cc,]) else EMP_GROUP_SIZE_SHARE
      names(targ)<-c('2','3','4')
      make_groups(spl[[cc]],group_size_mode=cfg('group_size_mode'),target_share=targ)
    })
    names(bycond)<-names(spl)
    if(partner_mode=='FIXED') world$fixed_groups<-bycond
  }
  groups<-unlist(bycond,recursive=FALSE)
  gm<-list(); gi<-0L
  for(cc in names(bycond)) for(gj in seq_along(bycond[[cc]])) {
    gi<-gi+1L
    gm[[gi]]<-data.frame(ID_MOVICI=bycond[[cc]][[gj]],DebateGroupID=paste0(cc,'_G',gj),stringsAsFactors=FALSE)
  }
  group_map<-do.call(rbind,gm)
  d<-build_debate_dyads(world,groups)
  mm<-apply_relational_memory(world,d); world<-mm$world; d<-finalize_debate_dyads(mm$dyad)
  social_metrics<-aggregate_debate_metrics(world,d)

  set.seed(MASTER_SEED + run*100000L + step*100L + 23L)
  world<-debate_self_update(world)

  if(learning) {
    set.seed(MASTER_SEED + run*100000L + step*100L + 24L)
    tr<-debate_social_transfer(world,d); world<-refresh_state_from_items(tr$world)
    transfer_acq<-tr$acquisitions; transfer_loss<-tr$losses; exposures<-tr$exposures
  } else {
    transfer_acq<-transfer_loss<-exposures<-rep(0,nrow(world$items))
  }
  state_gains<-rowSums(prev==0 & world$items==1,na.rm=TRUE)
  state_losses<-rowSums(prev==1 & world$items==0,na.rm=TRUE)
  list(world=world,prev_items=prev,acquisitions=state_gains,losses=state_losses,
       learning_acquisitions=transfer_acq,learning_losses=transfer_loss,exposures=exposures,
       state_additions=seed_acq,social_metrics=social_metrics,dyads=d,group_map=group_map,
       seed_acquisitions=seed_acq,transfer_acquisitions=transfer_acq,transfer_losses=transfer_loss)
}


# ============================================================================
# 05_coupled_engine.R
# ============================================================================
coupled_episode <- function(world,run,step) {
  # One coupled tick = RI followed by Debate on the RI-updated state.
  # RENEWED atoms are introduced by RI only, so the Debate stage uses the same pool.
  a<-ri_episode(world,run,step,allow_add=TRUE)
  after_ri_items<-a$world$items
  world<-a$world
  b<-debate_episode(world,run,step,allow_add=FALSE,learning=TRUE)

  start<-a$prev_items
  final<-b$world$items
  if(ncol(start)<ncol(final)) start<-pad_state(start,ncol(final)-ncol(start),fill=0)
  if(ncol(after_ri_items)<ncol(final)) after_ri_items<-pad_state(after_ri_items,ncol(final)-ncol(after_ri_items),fill=0)

  net_acq<-rowSums(start==0 & final==1,na.rm=TRUE)
  net_loss<-rowSums(start==1 & final==0,na.rm=TRUE)
  ri_stock_delta<-rowSums(after_ri_items,na.rm=TRUE)-rowSums(start,na.rm=TRUE)
  debate_stock_delta<-rowSums(final,na.rm=TRUE)-rowSums(after_ri_items,na.rm=TRUE)

  list(world=b$world,prev_items=start,acquisitions=net_acq,losses=net_loss,
       learning_acquisitions=a$learning_acquisitions+b$learning_acquisitions,
       learning_losses=a$learning_losses+b$learning_losses,
       exposures=a$exposures+b$exposures,
       state_additions=a$state_additions+b$state_additions,
       social_metrics=b$social_metrics,dyads=b$dyads,group_map=b$group_map,
       RI_acquisitions=a$learning_acquisitions,RI_losses=a$learning_losses,RI_exposures=a$exposures,
       Debate_acquisitions=b$learning_acquisitions,Debate_losses=b$learning_losses,Debate_exposures=b$exposures,
       RI_stock_delta=ri_stock_delta,Debate_stock_delta=debate_stock_delta)
}


# ============================================================================
# 06_scenario_matrix.R
# ============================================================================
SCENARIOS <- read.csv(file.path('config','scenario_registry.csv'),stringsAsFactors=FALSE)
PRIMARY_SCENARIOS <- SCENARIOS[SCENARIOS$primary=='yes',,drop=FALSE]
include_frozen <- if(exists('INCLUDE_FROZEN_OVERRIDE',inherits=TRUE)) isTRUE(INCLUDE_FROZEN_OVERRIDE) else cfg_bool('debate_frozen_control')
if(include_frozen) {
  RUN_SCENARIOS <- rbind(PRIMARY_SCENARIOS,SCENARIOS[SCENARIOS$process=='DEBATE_FROZEN',,drop=FALSE])
} else RUN_SCENARIOS <- PRIMARY_SCENARIOS


# ============================================================================
# 07_harmonized_indicators.R
# ============================================================================
SOCIAL_METRICS <- c(
  'RecognitionAccuracy','MeanRecognizedExpertise','MeanRecognitionBias','MeanRecognitionError',
  'MeanUnderRecognitionMagnitude','MeanOverRecognitionMagnitude','MeanBenevolenceSignal',
  'MeanOtherCredit','MeanOtherCreditBias','MeanOtherCreditCalibrationError',
  'MeanUnderCreditMagnitude','MeanOverCreditMagnitude','MeanUnderRecognitionMoreExpertMagnitude',
  'MeanUnderCreditMoreExpertMagnitude','MeanRelativeCreditSelfMinusMoreExpert','RelativeCreditSelfMinusOther',
  'ExpertUseEfficiency','MissedCorrectiveOpportunityRate','RecognitionRankReversalRate',
  'CreditRankReversalRate','UnderweightMoreExpertRate','OverweightLessExpertRate','WeightMoreExpert','WeightLessExpert','MoreExpertEncounterCount','LessExpertEncounterCount',
  'CorrectiveOpportunityTotal','AccessibleCorrectiveOpportunityTotal','MissedCorrectiveOpportunityTotal',
  'KnowledgeRecognitionCovariance','KnowledgeOtherCreditCovariance','ExpertiseAllocationGain',
  'EpistemicCreditMisallocationIndex','EpistemicCreditAllocationIndex'
)

LEARNING_METRICS <- c(
  'KnowledgeStock','NetKnowledgeStockGain','KnowledgeDensity','DeltaKnowledgeDensityBaseline',
  'CoreKnowledgeStock','CoreKnowledgeStockGain','CoreKnowledgeDensity','NewKnowledgeStock','NewKnowledgeDensity',
  'CumulativeLearningAcquisitions','CumulativeLearningLosses','CumulativeLearningBalance',
  'CumulativeExposureCount','LearningEfficiencyPerExposure','NetLearningPerExposure',
  'AcquisitionRate','LossRate','GrossLearningAcquisitionPerExposure','GrossLearningLossPerExposure','RetentionRate','TurnoverRate','GrossLearningEventRate','Coverage','EncounteredAccuracy'
)

METACOG_METRICS <- c(
  'SelfCredit_z','SelfBias_z','SelfOverCredit_z','SelfUnderCredit_z',
  'AbsCalibrationError','CalibrationImprovement'
)

COMMON_AGENT_METRICS <- unique(c(LEARNING_METRICS,METACOG_METRICS,'K_prop','K_eq20','DeltaK_baseline','DeltaK_step','K_z_common'))

STRICT_CROSS_PROCESS_METRICS <- c(
  'NetKnowledgeStockGain','DeltaKnowledgeDensityBaseline','CoreKnowledgeStockGain',
  'CumulativeLearningAcquisitions','CumulativeLearningLosses','CumulativeLearningBalance',
  'LearningEfficiencyPerExposure','NetLearningPerExposure','CalibrationImprovement','AbsCalibrationError'
)

SOCIAL_CROSS_PROCESS_METRICS <- c(
  'MeanOtherCredit','MeanOtherCreditBias','MeanOtherCreditCalibrationError','MeanUnderRecognitionMoreExpertMagnitude',
  'MeanUnderCreditMoreExpertMagnitude','MeanRelativeCreditSelfMinusMoreExpert','RelativeCreditSelfMinusOther',
  'RecognitionAccuracy','MeanRecognitionError','ExpertUseEfficiency','MissedCorrectiveOpportunityRate',
  'RecognitionRankReversalRate','CreditRankReversalRate','UnderweightMoreExpertRate','OverweightLessExpertRate','WeightMoreExpert','WeightLessExpert',
  'EpistemicCreditMisallocationIndex','EpistemicCreditAllocationIndex'
)

attach_social_metrics <- function(common,social=NULL) {
  for(m in SOCIAL_METRICS) common[[m]]<-NA_real_
  if(is.null(social)||!nrow(social))return(common)
  ii<-match(common$ID_MOVICI,social$ID_MOVICI)
  for(m in SOCIAL_METRICS) if(m %in% names(social)) common[[m]]<-social[[m]][ii]
  common
}

make_empty_accum <- function(n) {
  list(
    cum_learning_acq=rep(0,n),cum_learning_loss=rep(0,n),cum_exposures=rep(0,n),cum_state_additions=rep(0,n),
    cum_RI_acq=rep(0,n),cum_RI_loss=rep(0,n),cum_RI_exposures=rep(0,n),
    cum_Debate_acq=rep(0,n),cum_Debate_loss=rep(0,n),cum_Debate_exposures=rep(0,n),
    cum_RI_stock_delta=rep(0,n),cum_Debate_stock_delta=rep(0,n)
  )
}

make_baseline_panel <- function(world,process,info_regime,run,design='INTER',condition_scenario='EMPIRICAL') {
  n<-nrow(world$items); zero<-rep(0,n); accum<-make_empty_accum(n)
  z<-common_metrics(world,world$items,zero,zero,step=0,
                    learning_acq=zero,learning_loss=zero,exposures=zero,state_additions=zero,accum=accum)
  z<-attach_social_metrics(z,NULL)
  z$process<-process; z$info_regime<-info_regime; z$run<-run; z$step<-0L
  z$design<-design; z$condition_scenario<-condition_scenario
  z$baseline_phase<-world$state$baseline_phase
  z$DebateGroupID<-NA_character_
  z$RI_AcquisitionCount<-z$RI_LossCount<-z$RI_ExposureCount<-NA_real_
  z$Debate_AcquisitionCount<-z$Debate_LossCount<-z$Debate_ExposureCount<-NA_real_
  z$RI_StockDelta<-z$Debate_StockDelta<-NA_real_
  z$CumulativeRI_Acquisitions<-z$CumulativeRI_Losses<-z$CumulativeRI_Exposures<-NA_real_
  z$CumulativeDebate_Acquisitions<-z$CumulativeDebate_Losses<-z$CumulativeDebate_Exposures<-NA_real_
  z$CumulativeRI_StockDelta<-z$CumulativeDebate_StockDelta<-NA_real_
  z
}

make_step_panel <- function(world,ep,process,info_regime,run,step,accum,
                            design='INTER',condition_scenario='EMPIRICAL') {
  z<-common_metrics(world,ep$prev_items,ep$acquisitions,ep$losses,step=step,
                    learning_acq=ep$learning_acquisitions,learning_loss=ep$learning_losses,
                    exposures=ep$exposures,state_additions=ep$state_additions,accum=accum)
  social<-if('social_metrics'%in%names(ep))ep$social_metrics else NULL
  z<-attach_social_metrics(z,social)
  z$process<-process; z$info_regime<-info_regime; z$run<-run; z$step<-step
  z$design<-design; z$condition_scenario<-condition_scenario
  z$baseline_phase<-world$state$baseline_phase
  z$DebateGroupID<-NA_character_
  if('group_map'%in%names(ep) && !is.null(ep$group_map) && nrow(ep$group_map)) {
    ii<-match(z$ID_MOVICI,ep$group_map$ID_MOVICI)
    z$DebateGroupID<-ep$group_map$DebateGroupID[ii]
  }
  if(process=='COUPLED') {
    z$RI_AcquisitionCount<-ep$RI_acquisitions; z$RI_LossCount<-ep$RI_losses; z$RI_ExposureCount<-ep$RI_exposures
    z$Debate_AcquisitionCount<-ep$Debate_acquisitions; z$Debate_LossCount<-ep$Debate_losses; z$Debate_ExposureCount<-ep$Debate_exposures
    z$RI_StockDelta<-ep$RI_stock_delta; z$Debate_StockDelta<-ep$Debate_stock_delta
    z$CumulativeRI_Acquisitions<-accum$cum_RI_acq; z$CumulativeRI_Losses<-accum$cum_RI_loss; z$CumulativeRI_Exposures<-accum$cum_RI_exposures
    z$CumulativeDebate_Acquisitions<-accum$cum_Debate_acq; z$CumulativeDebate_Losses<-accum$cum_Debate_loss; z$CumulativeDebate_Exposures<-accum$cum_Debate_exposures
    z$CumulativeRI_StockDelta<-accum$cum_RI_stock_delta; z$CumulativeDebate_StockDelta<-accum$cum_Debate_stock_delta
  } else {
    z$RI_AcquisitionCount<-z$RI_LossCount<-z$RI_ExposureCount<-NA_real_
    z$Debate_AcquisitionCount<-z$Debate_LossCount<-z$Debate_ExposureCount<-NA_real_
    z$RI_StockDelta<-z$Debate_StockDelta<-NA_real_
    z$CumulativeRI_Acquisitions<-z$CumulativeRI_Losses<-z$CumulativeRI_Exposures<-NA_real_
    z$CumulativeDebate_Acquisitions<-z$CumulativeDebate_Losses<-z$CumulativeDebate_Exposures<-NA_real_
    z$CumulativeRI_StockDelta<-z$CumulativeDebate_StockDelta<-NA_real_
  }
  z
}


# ============================================================================
# 08_run_simulations.R
# ============================================================================
run_one_scenario <- function(process,info_regime,run,condition_override=NULL,eligible_ids=NULL,
                             design='INTER',condition_scenario='EMPIRICAL',collect_dyads=FALSE,profile_mode='OBSERVED') {
  world<-make_world(process,info_regime,run=run,condition_override=condition_override,profile_mode=profile_mode)
  if(!is.null(eligible_ids)) {
    keep<-world$state$ID_MOVICI %in% eligible_ids
    world$state<-world$state[keep,,drop=FALSE]
    world$items<-world$items[keep,,drop=FALSE]
    world$baseline_items<-world$baseline_items[keep,,drop=FALSE]
    world$previous_items<-world$previous_items[keep,,drop=FALSE]
    world$ever_exposed<-world$ever_exposed[keep,,drop=FALSE]
    world$baseline_K<-world$baseline_K[keep]
    world$baseline_stock<-world$baseline_stock[keep]
    world$baseline_self<-world$baseline_self[keep]
    world$profiles<-world$profiles[world$profiles$ID_MOVICI %in% world$state$ID_MOVICI,,drop=FALSE]
  }
  panels<-list(); pops<-list(); dyads_out<-list(); pk<-1L; qk<-0L; dk<-0L
  accum<-make_empty_accum(nrow(world$items))
  panels[[pk]]<-make_baseline_panel(world,process,info_regime,run,design,condition_scenario)
  basevar<-var(world$baseline_K,na.rm=TRUE)

  for(step in seq_len(cfg_int('max_steps'))) {
    if(process=='RI') ep<-ri_episode(world,run,step,allow_add=TRUE)
    else if(process=='DEBATE') ep<-debate_episode(world,run,step,allow_add=TRUE,learning=TRUE)
    else if(process=='DEBATE_FROZEN') ep<-debate_episode(world,run,step,allow_add=FALSE,learning=FALSE)
    else if(process=='COUPLED') ep<-coupled_episode(world,run,step)
    else stop('Unknown process: ',process)
    world<-ep$world

    accum$cum_learning_acq<-accum$cum_learning_acq+ep$learning_acquisitions
    accum$cum_learning_loss<-accum$cum_learning_loss+ep$learning_losses
    accum$cum_exposures<-accum$cum_exposures+ep$exposures
    accum$cum_state_additions<-accum$cum_state_additions+ep$state_additions
    if(process=='COUPLED') {
      accum$cum_RI_acq<-accum$cum_RI_acq+ep$RI_acquisitions
      accum$cum_RI_loss<-accum$cum_RI_loss+ep$RI_losses
      accum$cum_RI_exposures<-accum$cum_RI_exposures+ep$RI_exposures
      accum$cum_Debate_acq<-accum$cum_Debate_acq+ep$Debate_acquisitions
      accum$cum_Debate_loss<-accum$cum_Debate_loss+ep$Debate_losses
      accum$cum_Debate_exposures<-accum$cum_Debate_exposures+ep$Debate_exposures
      accum$cum_RI_stock_delta<-accum$cum_RI_stock_delta+ep$RI_stock_delta
      accum$cum_Debate_stock_delta<-accum$cum_Debate_stock_delta+ep$Debate_stock_delta
    }

    if(step %in% REPORT_STEPS) {
      pk<-pk+1L
      panel<-make_step_panel(world,ep,process,info_regime,run,step,accum,design,condition_scenario)
      panels[[pk]]<-panel
      if(isTRUE(collect_dyads) && 'dyads'%in%names(ep) && !is.null(ep$dyads) && nrow(ep$dyads)) {
        dd<-ep$dyads
        dd$process<-process; dd$info_regime<-info_regime; dd$run<-run; dd$step<-step
        dd$design<-design; dd$condition_scenario<-condition_scenario
        if('group_map'%in%names(ep) && !is.null(ep$group_map) && nrow(ep$group_map)) {
          dd$DebateGroupID<-ep$group_map$DebateGroupID[match(dd$evaluator_ID,ep$group_map$ID_MOVICI)]
        } else dd$DebateGroupID<-NA_character_
        dk<-dk+1L; dyads_out[[dk]]<-dd
      }
      pop<-population_metrics(panel,basevar)
      pop$process<-process; pop$info_regime<-info_regime; pop$run<-run; pop$step<-step
      pop$design<-design; pop$condition_scenario<-condition_scenario
      for(m in SOCIAL_METRICS) if(m %in% names(panel)) pop[[paste0('Social_',m)]]<-safe_mean(panel[[m]])
      if(process=='COUPLED') {
        pop$MeanCumulativeRI_Acquisitions<-safe_mean(panel$CumulativeRI_Acquisitions)
        pop$MeanCumulativeDebate_Acquisitions<-safe_mean(panel$CumulativeDebate_Acquisitions)
        pop$MeanCumulativeRI_StockDelta<-safe_mean(panel$CumulativeRI_StockDelta)
        pop$MeanCumulativeDebate_StockDelta<-safe_mean(panel$CumulativeDebate_StockDelta)
      }
      qk<-qk+1L; pops[[qk]]<-pop
    }
  }
  list(panel=do.call(rbind,panels),population=if(length(pops))do.call(rbind,pops) else data.frame(),
       dyads=if(length(dyads_out))do.call(rbind,dyads_out) else data.frame())
}

N_RUNS <- if(exists('N_RUNS_OVERRIDE',inherits=TRUE)) as.integer(N_RUNS_OVERRIDE) else cfg_int('n_runs')
DYAD_EXPORT_RUNS <- if(exists('DYAD_EXPORT_RUNS_OVERRIDE',inherits=TRUE)) as.integer(DYAD_EXPORT_RUNS_OVERRIDE) else cfg_int('dyad_export_runs')
cat('Running JASSS / OSF V3.4 minimal publication SMA with ',N_RUNS,' Monte Carlo runs...\n',sep='')
ALL_PANEL_LIST<-list(); ALL_POP_LIST<-list(); ALL_DYAD_LIST<-list(); k<-0L; kd<-0L
for(s in seq_len(nrow(RUN_SCENARIOS))) {
  process<-RUN_SCENARIOS$process[s]; info<-RUN_SCENARIOS$info_regime[s]
  cat('  - INTER ',process,' / ',info,'\n',sep='')
  for(run in seq_len(N_RUNS)) {
    if(N_RUNS >= 10L && (run %% 10L == 0L || run == 1L || run == N_RUNS)) cat('      run ',run,'/',N_RUNS,'\n',sep='')
    set.seed(MASTER_SEED + run*1000000L + s*10000L)
    z<-run_one_scenario(process,info,run,design='INTER',condition_scenario='EMPIRICAL',
                        collect_dyads=(run<=DYAD_EXPORT_RUNS))
    k<-k+1L; ALL_PANEL_LIST[[k]]<-z$panel; ALL_POP_LIST[[k]]<-z$population
    if(nrow(z$dyads)) { kd<-kd+1L; ALL_DYAD_LIST[[kd]]<-z$dyads }
  }
}
cat('Binding main scenario outputs with union-of-columns safeguard...\n')
PANEL_ALL<-rbind_fill(ALL_PANEL_LIST)
POP_ALL<-rbind_fill(ALL_POP_LIST)
DYAD_ALL<-rbind_fill(ALL_DYAD_LIST)
write.csv(POP_ALL,file.path('results','population','population_by_run.csv'),row.names=FALSE,na='')


# ============================================================================
# 08b_counterfactual_intra.R
# ============================================================================
# Paired counterfactual condition design: the SAME agents are simulated under all-COOP
# and all-COMP worlds with common random-number seeds. This isolates the simulated
# effect of the interaction regime from empirical between-group composition.
run_cf <- if(exists('RUN_COUNTERFACTUAL_OVERRIDE',inherits=TRUE)) isTRUE(RUN_COUNTERFACTUAL_OVERRIDE) else cfg_bool('run_counterfactual_intra')
CF_PANEL_ALL<-data.frame()
if(run_cf) {
  procs<-strsplit(cfg('counterfactual_processes'),';',fixed=TRUE)[[1]]
  cf_infos<-if(exists('CF_INFO_REGIMES_OVERRIDE',inherits=TRUE)) strsplit(as.character(CF_INFO_REGIMES_OVERRIDE),';',fixed=TRUE)[[1]] else c('FIXED','RENEWED')
  cf_runs<-if(exists('N_CF_RUNS_OVERRIDE',inherits=TRUE)) as.integer(N_CF_RUNS_OVERRIDE) else N_RUNS
  cat('Running paired counterfactual COOP/COMP design with ',cf_runs,' runs; info=',paste(cf_infos,collapse=';'),'...\n',sep='')
  eligible_ids<-AGENTS$ID_MOVICI[AGENTS$condition %in% c('COOP','COMP')]
  CF_KEEP_METRICS<-unique(c('KnowledgeStock','NetKnowledgeStockGain','KnowledgeDensity','CumulativeLearningAcquisitions',
                            'CumulativeLearningLosses','CumulativeLearningBalance',
                            'LearningEfficiencyPerExposure','SelfCredit_z','SelfBias_z','AbsCalibrationError','CalibrationImprovement',
                            SOCIAL_CROSS_PROCESS_METRICS,'MeanUnderCreditMagnitude','MeanOverCreditMagnitude',
                            'MeanUnderRecognitionMoreExpertMagnitude','MeanUnderCreditMoreExpertMagnitude','MeanRelativeCreditSelfMinusMoreExpert'))
  zz<-list(); k<-0L
  for(pr in procs) for(info in cf_infos) for(run in seq_len(cf_runs)) {
    if(cf_runs >= 10L && (run %% 10L == 0L || run == 1L || run == cf_runs)) cat('  - CF ',pr,' / ',info,' : run ',run,'/',cf_runs,'\n',sep='')
    for(cond in c('COOP','COMP')) {
      # Same run/step seeds in both arms = common random numbers where equations permit.
      z<-run_one_scenario(pr,info,run,condition_override=cond,eligible_ids=eligible_ids,design='INTRA_COUNTERFACTUAL',condition_scenario=cond)
      keep<-intersect(c('ID_MOVICI','process','info_regime','run','step','design','condition_scenario',CF_KEEP_METRICS),names(z$panel))
      k<-k+1L; zz[[k]]<-z$panel[,keep,drop=FALSE]
    }
  }
  CF_PANEL_ALL<-rbind_fill(zz)
}

# Publication-only approximate total-effect counterfactual: condition-consistent
# Visibility/RelationalStyle profiles are drawn from each empirical condition while
# preserving common latent ranks across arms. This is a behavior-mediated TOTAL-EFFECT
# PROXY, not a nonparametric causal total effect.
run_total_cf <- exists('RUN_TOTAL_CF_OVERRIDE',inherits=TRUE) && isTRUE(RUN_TOTAL_CF_OVERRIDE)
CF_TOTAL_PANEL_ALL<-data.frame()
if(run_total_cf) {
  procs<-strsplit(cfg('counterfactual_processes'),';',fixed=TRUE)[[1]]
  total_runs<-if(exists('N_TOTAL_CF_RUNS_OVERRIDE',inherits=TRUE)) as.integer(N_TOTAL_CF_RUNS_OVERRIDE) else 0L
  cat('Running condition-consistent-profile total-effect proxy with ',total_runs,' runs...\n',sep='')
  eligible_ids<-AGENTS$ID_MOVICI[AGENTS$condition %in% c('COOP','COMP')]
  zz<-list(); k<-0L
  for(pr in procs) for(info in c('FIXED','RENEWED')) for(run in seq_len(total_runs)) for(cond in c('COOP','COMP')) {
    z<-run_one_scenario(pr,info,run,condition_override=cond,eligible_ids=eligible_ids,
                        design='INTRA_TOTAL_PROXY',condition_scenario=cond,profile_mode='CONDITION_CONSISTENT')
    keep<-intersect(c('ID_MOVICI','process','info_regime','run','step','design','condition_scenario',CF_KEEP_METRICS),names(z$panel))
    k<-k+1L; zz[[k]]<-z$panel[,keep,drop=FALSE]
  }
  CF_TOTAL_PANEL_ALL<-rbind_fill(zz)
}


# ============================================================================
# 09_statistics_intra.R
# ============================================================================
# Horizon-wise within-agent changes from the process-specific empirical baseline.
INTRA_METRICS <- c('KnowledgeStock','KnowledgeDensity','NetKnowledgeStockGain',
                   'CumulativeLearningAcquisitions','CumulativeLearningLosses','CumulativeLearningBalance',
                   'SelfCredit_z','SelfBias_z','AbsCalibrationError','CalibrationImprovement')
rows<-list(); kk<-0L
for(pr in unique(PANEL_ALL$process)) for(info in unique(PANEL_ALL$info_regime[PANEL_ALL$process==pr]))
for(run in unique(PANEL_ALL$run)) {
  bas_all<-PANEL_ALL[PANEL_ALL$process==pr & PANEL_ALL$info_regime==info & PANEL_ALL$run==run & PANEL_ALL$step==0,
                     c('ID_MOVICI',INTRA_METRICS),drop=FALSE]
  if(!nrow(bas_all)) next
  for(st in REPORT_STEPS) {
    cur_all<-PANEL_ALL[PANEL_ALL$process==pr & PANEL_ALL$info_regime==info & PANEL_ALL$run==run & PANEL_ALL$step==st,
                       c('ID_MOVICI',INTRA_METRICS),drop=FALSE]
    if(!nrow(cur_all)) next
    ib<-match(cur_all$ID_MOVICI,bas_all$ID_MOVICI)
    for(m in INTRA_METRICS) {
      # Cumulative metrics are already 0 at baseline; the paired statistic remains valid.
      z<-paired_stats(cur_all[[m]],bas_all[[m]][ib])
      kk<-kk+1L; rows[[kk]]<-cbind(data.frame(process=pr,info_regime=info,run=run,step=st,metric=m),z)
    }
  }
}
INTRA_BY_RUN<-if(length(rows))rbind_fill(rows) else data.frame()
if(nrow(INTRA_BY_RUN)) INTRA_BY_RUN$q_BH<-ave(INTRA_BY_RUN$p,INTRA_BY_RUN$process,INTRA_BY_RUN$info_regime,
                                              INTRA_BY_RUN$run,FUN=p_adjust_bh)
write.csv(INTRA_BY_RUN,file.path('results','statistics','intra_subject_change_by_run.csv'),row.names=FALSE,na='')
INTRA_MC<-mc_summary(INTRA_BY_RUN,c('process','info_regime','step','metric'))
write.csv(INTRA_MC,file.path('results','statistics','intra_subject_change_MC_summary.csv'),row.names=FALSE,na='')

# Agent-level longitudinal slopes (closed-form OLS) followed by slope ~ SES + COOP.
# This is the dedicated cumulative-effect layer for structural and condition gradients.
SLOPE_COMMON <- c('KnowledgeStock','KnowledgeDensity','NetKnowledgeStockGain','CumulativeLearningAcquisitions',
                  'LearningEfficiencyPerExposure','SelfCredit_z','SelfBias_z','AbsCalibrationError')
SLOPE_SOCIAL <- c('MeanOtherCredit','MeanOtherCreditBias','RelativeCreditSelfMinusOther',
                  'ExpertUseEfficiency','MissedCorrectiveOpportunityRate','RecognitionRankReversalRate',
                  'CreditRankReversalRate','UnderweightMoreExpertRate','OverweightLessExpertRate','WeightMoreExpert','WeightLessExpert','EpistemicCreditMisallocationIndex')
srows<-list(); sk<-0L
for(pr in unique(PANEL_ALL$process)) for(info in unique(PANEL_ALL$info_regime[PANEL_ALL$process==pr]))
for(run in unique(PANEL_ALL$run)) {
  metrics<-SLOPE_COMMON
  if(pr %in% c('DEBATE','DEBATE_FROZEN','COUPLED')) metrics<-c(metrics,SLOPE_SOCIAL)
  block<-PANEL_ALL[PANEL_ALL$process==pr & PANEL_ALL$info_regime==info & PANEL_ALL$run==run,
                   c('ID_MOVICI','condition','SES_raw','step',metrics),drop=FALSE]
  if(!nrow(block)) next
  for(id in unique(block$ID_MOVICI)) {
    q<-block[block$ID_MOVICI==id,,drop=FALSE]
    for(m in metrics) {
      # Social metrics begin at step 1; common metrics may include step 0.
      ok<-is.finite(q$step)&is.finite(q[[m]])
      if(sum(ok)<4) next
      x<-log1p(q$step[ok]); y<-q[[m]][ok]
      xc<-x-mean(x); den<-sum(xc^2)
      if(!is.finite(den)||den<=0) next
      sl<-sum(xc*(y-mean(y)))/den
      sk<-sk+1L; srows[[sk]]<-data.frame(process=pr,info_regime=info,run=run,ID_MOVICI=id,
                                          condition=q$condition[1],SES_raw=q$SES_raw[1],metric=m,slope=sl,
                                          stringsAsFactors=FALSE)
    }
  }
}
INTRA_SLOPES<-if(length(srows))rbind_fill(srows) else data.frame()
write.csv(INTRA_SLOPES,file.path('results','statistics','intra_subject_agent_slopes.csv'),row.names=FALSE,na='')

sfx<-list(); sx<-0L
if(nrow(INTRA_SLOPES)) {
  for(pr in unique(INTRA_SLOPES$process)) for(info in unique(INTRA_SLOPES$info_regime[INTRA_SLOPES$process==pr]))
  for(run in unique(INTRA_SLOPES$run)) for(m in unique(INTRA_SLOPES$metric)) {
    q<-INTRA_SLOPES[INTRA_SLOPES$process==pr & INTRA_SLOPES$info_regime==info & INTRA_SLOPES$run==run & INTRA_SLOPES$metric==m,,drop=FALSE]
    q$COOP<-as.numeric(q$condition=='COOP')
    q<-q[complete.cases(q[,c('slope','SES_raw','COOP')]),,drop=FALSE]
    if(nrow(q)<10 || length(unique(q$COOP))<2) next
    fit<-lm(slope~SES_raw+COOP,data=q); sm<-summary(fit)$coefficients
    for(term in intersect(c('SES_raw','COOP'),rownames(sm))) {
      sx<-sx+1L; sfx[[sx]]<-data.frame(process=pr,info_regime=info,run=run,metric=m,term=term,
                                        estimate=sm[term,1],SE=sm[term,2],t=sm[term,3],df=df.residual(fit),p=sm[term,4],N=nrow(q),
                                        stringsAsFactors=FALSE)
    }
  }
}
SLOPE_EFFECTS_BY_RUN<-if(length(sfx))rbind_fill(sfx) else data.frame()
write.csv(SLOPE_EFFECTS_BY_RUN,file.path('results','statistics','cumulative_slope_SES_COOP_effects_by_run.csv'),row.names=FALSE,na='')
SLOPE_EFFECTS_MC<-mc_summary(SLOPE_EFFECTS_BY_RUN,c('process','info_regime','metric','term'))
write.csv(SLOPE_EFFECTS_MC,file.path('results','statistics','cumulative_slope_SES_COOP_effects_MC_summary.csv'),row.names=FALSE,na='')


# ============================================================================
# 09b_cumulative_dynamics.R
# ============================================================================
# Explicit step-1 -> later-horizon cumulative dynamics.
# This distinguishes an effect already present after one episode from an effect that grows with repetition.
CUM_METRICS <- unique(c('KnowledgeStock','KnowledgeDensity','NetKnowledgeStockGain','CumulativeLearningAcquisitions',
                        'LearningEfficiencyPerExposure','SelfCredit_z','SelfBias_z','AbsCalibrationError',SOCIAL_CROSS_PROCESS_METRICS))
within_rows<-list(); adj_rows<-list(); wk<-0L; ak<-0L
for(pr in unique(PANEL_ALL$process)) for(info in unique(PANEL_ALL$info_regime[PANEL_ALL$process==pr]))
for(run in unique(PANEL_ALL$run)) {
  s1<-PANEL_ALL[PANEL_ALL$process==pr & PANEL_ALL$info_regime==info & PANEL_ALL$run==run & PANEL_ALL$step==1,,drop=FALSE]
  if(!nrow(s1)) next
  for(st in REPORT_STEPS[REPORT_STEPS>1]) {
    cur<-PANEL_ALL[PANEL_ALL$process==pr & PANEL_ALL$info_regime==info & PANEL_ALL$run==run & PANEL_ALL$step==st,,drop=FALSE]
    if(!nrow(cur)) next
    for(m in CUM_METRICS) {
      if(!m %in% names(cur)) next
      q<-merge(cur[,c('ID_MOVICI','condition','SES_raw',m),drop=FALSE],
               s1[,c('ID_MOVICI',m),drop=FALSE],by='ID_MOVICI',suffixes=c('_T','_S1'),sort=FALSE)
      names(q)[names(q)==paste0(m,'_T')]<-'current'
      names(q)[names(q)==paste0(m,'_S1')]<-'step1'
      ok<-is.finite(q$current)&is.finite(q$step1)
      q<-q[ok,,drop=FALSE]
      if(nrow(q)<6) next
      for(cc in intersect(c('COOP','COMP'),unique(q$condition))) {
        zq<-q[q$condition==cc,,drop=FALSE]
        if(nrow(zq)<3) next
        z<-paired_stats(zq$current,zq$step1)
        wk<-wk+1L; within_rows[[wk]]<-cbind(data.frame(process=pr,info_regime=info,run=run,step=st,condition=cc,metric=m),z)
      }
      q$change<-q$current-q$step1; q$COOP<-as.numeric(q$condition=='COOP')
      q<-q[complete.cases(q[,c('change','SES_raw','COOP')]),,drop=FALSE]
      if(nrow(q)<10 || length(unique(q$COOP))<2) next
      use_s1<-safe_sd(q$step1)>sqrt(.Machine$double.eps)
      fit<-if(use_s1)lm(change~step1+SES_raw+COOP,data=q) else lm(change~SES_raw+COOP,data=q)
      sm<-summary(fit)$coefficients
      for(term in intersect(c('SES_raw','COOP'),rownames(sm))) {
        ak<-ak+1L; adj_rows[[ak]]<-data.frame(process=pr,info_regime=info,run=run,step=st,metric=m,term=term,
                                              estimate=sm[term,1],SE=sm[term,2],t=sm[term,3],df=df.residual(fit),p=sm[term,4],N=nrow(q),
                                              stringsAsFactors=FALSE)
      }
    }
  }
}
CUM_WITHIN_BY_RUN<-if(length(within_rows))rbind_fill(within_rows) else data.frame()
CUM_ADJ_BY_RUN<-if(length(adj_rows))rbind_fill(adj_rows) else data.frame()
write.csv(CUM_WITHIN_BY_RUN,file.path('results','statistics','cumulative_step1_to_horizon_within_condition_by_run.csv'),row.names=FALSE,na='')
write.csv(CUM_ADJ_BY_RUN,file.path('results','statistics','cumulative_step1_to_horizon_SES_COOP_adjusted_by_run.csv'),row.names=FALSE,na='')
CUM_WITHIN_MC<-mc_summary(CUM_WITHIN_BY_RUN,c('process','info_regime','step','condition','metric'))
CUM_ADJ_MC<-mc_summary(CUM_ADJ_BY_RUN,c('process','info_regime','step','metric','term'))
write.csv(CUM_WITHIN_MC,file.path('results','statistics','cumulative_step1_to_horizon_within_condition_MC_summary.csv'),row.names=FALSE,na='')
write.csv(CUM_ADJ_MC,file.path('results','statistics','cumulative_step1_to_horizon_SES_COOP_adjusted_MC_summary.csv'),row.names=FALSE,na='')


# ============================================================================
# 10_statistics_inter.R
# ============================================================================
# Between-participant adjusted effects at each horizon.
# Debate/Coupled use current-group cluster-robust SEs where enough groups exist.
INTER_METRICS <- unique(c(
  'KnowledgeStock','NetKnowledgeStockGain','KnowledgeDensity','CoreKnowledgeStockGain','NewKnowledgeStock',
  'CumulativeLearningAcquisitions','CumulativeLearningLosses','CumulativeLearningBalance',
  'LearningEfficiencyPerExposure','NetLearningPerExposure','SelfCredit_z','SelfBias_z','SelfOverCredit_z','SelfUnderCredit_z',
  'AbsCalibrationError','CalibrationImprovement',SOCIAL_CROSS_PROCESS_METRICS,
  'MeanRecognizedExpertise','MeanBenevolenceSignal','MeanRecognitionBias','MeanUnderRecognitionMagnitude','MeanOverRecognitionMagnitude',
  'MeanUnderCreditMagnitude','MeanOverCreditMagnitude','MeanUnderRecognitionMoreExpertMagnitude',
  'MeanUnderCreditMoreExpertMagnitude','MeanRelativeCreditSelfMinusMoreExpert','CorrectiveOpportunityTotal','MissedCorrectiveOpportunityTotal'
))
rows<-list(); kk<-0L
for(pr in unique(PANEL_ALL$process)) for(info in unique(PANEL_ALL$info_regime[PANEL_ALL$process==pr]))
for(run in unique(PANEL_ALL$run)) {
  bas<-PANEL_ALL[PANEL_ALL$process==pr & PANEL_ALL$info_regime==info & PANEL_ALL$run==run & PANEL_ALL$step==0,
                 c('ID_MOVICI',INTER_METRICS),drop=FALSE]
  if(!nrow(bas)) next
  names(bas)[-1]<-paste0(names(bas)[-1],'__baseline')
  for(st in REPORT_STEPS) {
    cur<-PANEL_ALL[PANEL_ALL$process==pr & PANEL_ALL$info_regime==info & PANEL_ALL$run==run & PANEL_ALL$step==st,
                   c('ID_MOVICI','condition','SES_raw','DebateGroupID',INTER_METRICS),drop=FALSE]
    if(!nrow(cur)) next
    q<-merge(cur,bas,by='ID_MOVICI',all.x=TRUE,sort=FALSE)
    q$COOP<-as.numeric(q$condition=='COOP')
    for(m in INTER_METRICS) {
      outcome<-q[[m]]
      baseline<-q[[paste0(m,'__baseline')]]
      if(sum(is.finite(outcome))<10) next
      use_baseline<-sum(is.finite(baseline))>=10 && safe_sd(baseline)>sqrt(.Machine$double.eps)
      qfit<-data.frame(outcome=outcome,baseline=baseline,SES_raw=q$SES_raw,COOP=q$COOP,
                       DebateGroupID=q$DebateGroupID,stringsAsFactors=FALSE)
      vars<-if(use_baseline)c('outcome','baseline','SES_raw','COOP') else c('outcome','SES_raw','COOP')
      qfit<-qfit[complete.cases(qfit[,vars,drop=FALSE]),,drop=FALSE]
      if(nrow(qfit)<10 || length(unique(qfit$COOP))<2) next
      fit<-if(use_baseline)lm(outcome~baseline+SES_raw+COOP,data=qfit) else lm(outcome~SES_raw+COOP,data=qfit)

      ctab<-NULL
      if(pr %in% c('DEBATE','DEBATE_FROZEN','COUPLED') && sum(!is.na(qfit$DebateGroupID))==nrow(qfit))
        ctab<-cluster_coef_table(fit,qfit$DebateGroupID)

      if(!is.null(ctab)) {
        for(term in intersect(c('SES_raw','COOP'),ctab$term)) {
          z<-ctab[ctab$term==term,,drop=FALSE]
          kk<-kk+1L
          rows[[kk]]<-data.frame(process=pr,info_regime=info,run=run,step=st,metric=m,term=term,
                                  estimate=z$estimate,SE=z$SE,t=z$t,df=z$df,p=z$p,N=nobs(fit),
                                  clusters=z$clusters,SE_type=z$SE_type,stringsAsFactors=FALSE)
        }
      } else {
        sm<-summary(fit)$coefficients
        for(term in intersect(c('SES_raw','COOP'),rownames(sm))) {
          kk<-kk+1L
          rows[[kk]]<-data.frame(process=pr,info_regime=info,run=run,step=st,metric=m,term=term,
                                  estimate=sm[term,1],SE=sm[term,2],t=sm[term,3],df=df.residual(fit),p=sm[term,4],
                                  N=nobs(fit),clusters=NA_integer_,SE_type='classical_OLS',stringsAsFactors=FALSE)
        }
      }
    }
  }
}
INTER_BY_RUN<-if(length(rows))rbind_fill(rows) else data.frame()
if(nrow(INTER_BY_RUN)) INTER_BY_RUN$q_BH<-ave(INTER_BY_RUN$p,INTER_BY_RUN$process,INTER_BY_RUN$info_regime,
                                              INTER_BY_RUN$run,INTER_BY_RUN$term,FUN=p_adjust_bh)
write.csv(INTER_BY_RUN,file.path('results','statistics','inter_subject_adjusted_effects_by_run.csv'),row.names=FALSE,na='')
INTER_MC<-mc_summary(INTER_BY_RUN,c('process','info_regime','step','metric','term','SE_type'))
write.csv(INTER_MC,file.path('results','statistics','inter_subject_adjusted_effects_MC_summary.csv'),row.names=FALSE,na='')


# ============================================================================
# 10b_counterfactual_condition.R
# ============================================================================
# True paired same-agent COOP vs COMP contrasts from the counterfactual worlds.
CF_CONDITION_BY_RUN<-data.frame(); CF_CUMULATIVE_BY_RUN<-data.frame()
if(exists('CF_PANEL_ALL') && nrow(CF_PANEL_ALL)) {
  CF_METRICS<-unique(c('KnowledgeStock','NetKnowledgeStockGain','KnowledgeDensity','CumulativeLearningAcquisitions','CumulativeLearningLosses','CumulativeLearningBalance',
                       'LearningEfficiencyPerExposure','SelfCredit_z','SelfBias_z','AbsCalibrationError','CalibrationImprovement',
                       SOCIAL_CROSS_PROCESS_METRICS,'MeanUnderCreditMagnitude','MeanOverCreditMagnitude',
                       'MeanUnderRecognitionMoreExpertMagnitude','MeanUnderCreditMoreExpertMagnitude','MeanRelativeCreditSelfMinusMoreExpert'))
  rr<-list(); cr<-list(); rk<-0L; ck<-0L
  for(pr in unique(CF_PANEL_ALL$process)) for(info in unique(CF_PANEL_ALL$info_regime[CF_PANEL_ALL$process==pr]))
  for(run in unique(CF_PANEL_ALL$run)) {
    # step-1 paired difference is the reference for cumulative condition divergence
    s1c<-CF_PANEL_ALL[CF_PANEL_ALL$process==pr & CF_PANEL_ALL$info_regime==info & CF_PANEL_ALL$run==run &
                       CF_PANEL_ALL$step==1 & CF_PANEL_ALL$condition_scenario=='COOP',,drop=FALSE]
    s1m<-CF_PANEL_ALL[CF_PANEL_ALL$process==pr & CF_PANEL_ALL$info_regime==info & CF_PANEL_ALL$run==run &
                       CF_PANEL_ALL$step==1 & CF_PANEL_ALL$condition_scenario=='COMP',,drop=FALSE]
    for(st in REPORT_STEPS) {
      co<-CF_PANEL_ALL[CF_PANEL_ALL$process==pr & CF_PANEL_ALL$info_regime==info & CF_PANEL_ALL$run==run &
                        CF_PANEL_ALL$step==st & CF_PANEL_ALL$condition_scenario=='COOP',,drop=FALSE]
      cp<-CF_PANEL_ALL[CF_PANEL_ALL$process==pr & CF_PANEL_ALL$info_regime==info & CF_PANEL_ALL$run==run &
                        CF_PANEL_ALL$step==st & CF_PANEL_ALL$condition_scenario=='COMP',,drop=FALSE]
      if(!nrow(co)||!nrow(cp))next
      for(m in CF_METRICS) {
        if(!m%in%names(co))next
        q<-merge(co[,c('ID_MOVICI',m),drop=FALSE],cp[,c('ID_MOVICI',m),drop=FALSE],by='ID_MOVICI',suffixes=c('_COOP','_COMP'),sort=FALSE)
        z<-paired_stats(q[[paste0(m,'_COOP')]],q[[paste0(m,'_COMP')]])
        rk<-rk+1L; rr[[rk]]<-cbind(data.frame(process=pr,info_regime=info,run=run,step=st,metric=m,contrast='COOP_MINUS_COMP'),z)

        if(st>1 && nrow(s1c)&&nrow(s1m)) {
          q1<-merge(s1c[,c('ID_MOVICI',m),drop=FALSE],s1m[,c('ID_MOVICI',m),drop=FALSE],by='ID_MOVICI',suffixes=c('_COOP','_COMP'),sort=FALSE)
          names(q1)[2:3]<-c('S1_COOP','S1_COMP')
          names(q)[2:3]<-c('T_COOP','T_COMP')
          qq<-merge(q,q1,by='ID_MOVICI',sort=FALSE)
          diff_growth<-(qq$T_COOP-qq$T_COMP)-(qq$S1_COOP-qq$S1_COMP)
          zz<-paired_stats(diff_growth,rep(0,length(diff_growth)))
          ck<-ck+1L; cr[[ck]]<-cbind(data.frame(process=pr,info_regime=info,run=run,step=st,metric=m,
                                                contrast='CHANGE_IN_COOP_MINUS_COMP_FROM_STEP1'),zz)
        }
      }
    }
  }
  CF_CONDITION_BY_RUN<-if(length(rr))rbind_fill(rr) else data.frame()
  CF_CUMULATIVE_BY_RUN<-if(length(cr))rbind_fill(cr) else data.frame()
}
write.csv(CF_CONDITION_BY_RUN,file.path('results','statistics','counterfactual_same_agent_COOP_vs_COMP_by_run.csv'),row.names=FALSE,na='')
write.csv(CF_CUMULATIVE_BY_RUN,file.path('results','statistics','counterfactual_cumulative_condition_divergence_by_run.csv'),row.names=FALSE,na='')
CF_CONDITION_MC<-mc_summary(CF_CONDITION_BY_RUN,c('process','info_regime','step','metric','contrast'))
CF_CUMULATIVE_MC<-mc_summary(CF_CUMULATIVE_BY_RUN,c('process','info_regime','step','metric','contrast'))
write.csv(CF_CONDITION_MC,file.path('results','statistics','counterfactual_same_agent_COOP_vs_COMP_MC_summary.csv'),row.names=FALSE,na='')
write.csv(CF_CUMULATIVE_MC,file.path('results','statistics','counterfactual_cumulative_condition_divergence_MC_summary.csv'),row.names=FALSE,na='')


# ============================================================================
# 11_pairwise_comparisons.R
# ============================================================================
get_panel <- function(pr,info,run,st) PANEL_ALL[PANEL_ALL$process==pr & PANEL_ALL$info_regime==info &
                                                 PANEL_ALL$run==run & PANEL_ALL$step==st,,drop=FALSE]

matched_metric_contrast <- function(A,B,metrics,id='ID_MOVICI') {
  out<-list(); k<-0L
  keep<-intersect(c(id,metrics),intersect(names(A),names(B)))
  mets<-setdiff(keep,id)
  if(!length(mets))return(data.frame())
  q<-merge(A[,c(id,mets),drop=FALSE],B[,c(id,mets),drop=FALSE],by=id,suffixes=c('_A','_B'),sort=FALSE)
  for(m in mets) {
    z<-paired_stats(q[[paste0(m,'_A')]],q[[paste0(m,'_B')]])
    k<-k+1L; out[[k]]<-cbind(data.frame(metric=m),z)
  }
  if(length(out))rbind_fill(out) else data.frame()
}

# General matched common-process contrasts, orientation A - B.
proc_pairs<-list(c('RI','DEBATE'),c('COUPLED','RI'),c('COUPLED','DEBATE'))
crows<-list(); ck<-0L
for(info in c('FIXED','RENEWED')) for(run in unique(PANEL_ALL$run)) for(st in REPORT_STEPS)
for(pair in proc_pairs) {
  a<-get_panel(pair[1],info,run,st); b<-get_panel(pair[2],info,run,st)
  if(!nrow(a)||!nrow(b))next
  z<-matched_metric_contrast(a,b,STRICT_CROSS_PROCESS_METRICS)
  if(!nrow(z))next
  z$process_A<-pair[1]; z$process_B<-pair[2]; z$info_regime<-info; z$run<-run; z$step<-st
  ck<-ck+1L; crows[[ck]]<-z
}
CROSS_PROCESS_BY_RUN<-if(length(crows))rbind_fill(crows) else data.frame()
if(nrow(CROSS_PROCESS_BY_RUN)) CROSS_PROCESS_BY_RUN$q_BH<-ave(CROSS_PROCESS_BY_RUN$p,CROSS_PROCESS_BY_RUN$run,
                                                              CROSS_PROCESS_BY_RUN$step,FUN=p_adjust_bh)
write.csv(CROSS_PROCESS_BY_RUN,file.path('results','comparisons','cross_process_matched_by_run.csv'),row.names=FALSE,na='')
CROSS_PROCESS_MC<-mc_summary(CROSS_PROCESS_BY_RUN,c('process_A','process_B','info_regime','step','metric'))
write.csv(CROSS_PROCESS_MC,file.path('results','comparisons','cross_process_matched_MC_summary.csv'),row.names=FALSE,na='')

# Coupled vs Debate social/vigilance effects: does direct RI attenuate or amplify social-credit dynamics?
srows<-list(); sk<-0L
for(info in c('FIXED','RENEWED')) for(run in unique(PANEL_ALL$run)) for(st in REPORT_STEPS) {
  a<-get_panel('COUPLED',info,run,st); b<-get_panel('DEBATE',info,run,st)
  if(!nrow(a)||!nrow(b))next
  z<-matched_metric_contrast(a,b,SOCIAL_CROSS_PROCESS_METRICS)
  if(!nrow(z))next
  z$process_A<-'COUPLED'; z$process_B<-'DEBATE'; z$info_regime<-info; z$run<-run; z$step<-st
  sk<-sk+1L; srows[[sk]]<-z
}
COUPLING_SOCIAL_BY_RUN<-if(length(srows))rbind_fill(srows) else data.frame()
write.csv(COUPLING_SOCIAL_BY_RUN,file.path('results','comparisons','coupled_vs_debate_social_credit_by_run.csv'),row.names=FALSE,na='')
COUPLING_SOCIAL_MC<-mc_summary(COUPLING_SOCIAL_BY_RUN,c('process_A','process_B','info_regime','step','metric'))
write.csv(COUPLING_SOCIAL_MC,file.path('results','comparisons','coupled_vs_debate_social_credit_MC_summary.csv'),row.names=FALSE,na='')

# Fixed vs renewed information. Stock and density are both exported so denominator effects remain explicit.
irows<-list(); ik<-0L
INFO_METRICS<-unique(c(STRICT_CROSS_PROCESS_METRICS,'KnowledgeStock','KnowledgeDensity','NewKnowledgeStock','Coverage'))
for(pr in c('RI','DEBATE','COUPLED')) for(run in unique(PANEL_ALL$run)) for(st in REPORT_STEPS) {
  a<-get_panel(pr,'RENEWED',run,st); b<-get_panel(pr,'FIXED',run,st)
  if(!nrow(a)||!nrow(b))next
  z<-matched_metric_contrast(a,b,INFO_METRICS)
  if(!nrow(z))next
  z$process<-pr; z$contrast<-'RENEWED_MINUS_FIXED'; z$run<-run; z$step<-st
  ik<-ik+1L; irows[[ik]]<-z
}
INFO_BY_RUN<-if(length(irows))rbind_fill(irows) else data.frame()
if(nrow(INFO_BY_RUN)) INFO_BY_RUN$q_BH<-ave(INFO_BY_RUN$p,INFO_BY_RUN$run,INFO_BY_RUN$step,FUN=p_adjust_bh)
write.csv(INFO_BY_RUN,file.path('results','comparisons','renewed_vs_fixed_matched_by_run.csv'),row.names=FALSE,na='')
INFO_MC<-mc_summary(INFO_BY_RUN,c('process','contrast','step','metric'))
write.csv(INFO_MC,file.path('results','comparisons','renewed_vs_fixed_matched_MC_summary.csv'),row.names=FALSE,na='')

# Descriptive non-additivity of the coupled trajectory.
# It is NOT labelled as a causal interaction because the coupled process is recursive.
NONADD_METRICS<-c('CumulativeLearningBalance','NetKnowledgeStockGain','DeltaKnowledgeDensityBaseline','CalibrationImprovement')
sy<-list(); syk<-0L
for(info in c('FIXED','RENEWED')) for(run in unique(PANEL_ALL$run)) for(st in REPORT_STEPS) {
  a<-get_panel('COUPLED',info,run,st); b<-get_panel('RI',info,run,st); c<-get_panel('DEBATE',info,run,st)
  if(!nrow(a)||!nrow(b)||!nrow(c))next
  for(m in NONADD_METRICS) {
    qa<-a[,c('ID_MOVICI',m),drop=FALSE]; qb<-b[,c('ID_MOVICI',m),drop=FALSE]; qc<-c[,c('ID_MOVICI',m),drop=FALSE]
    names(qa)[2]<-'C'; names(qb)[2]<-'R'; names(qc)[2]<-'D'
    q<-Reduce(function(x,y)merge(x,y,by='ID_MOVICI',sort=FALSE),list(qa,qb,qc))
    x<-q$C-(q$R+q$D); x<-x[is.finite(x)]
    if(length(x)<3)next
    z<-paired_stats(x,rep(0,length(x)))
    syk<-syk+1L; sy[[syk]]<-cbind(data.frame(info_regime=info,run=run,step=st,metric=m,
                                              contrast='COUPLED_MINUS_RI_PLUS_DEBATE_DESCRIPTIVE'),z)
  }
}
NONADD_BY_RUN<-if(length(sy))rbind_fill(sy) else data.frame()
write.csv(NONADD_BY_RUN,file.path('results','comparisons','coupling_nonadditivity_descriptive_by_run.csv'),row.names=FALSE,na='')
NONADD_MC<-mc_summary(NONADD_BY_RUN,c('info_regime','step','metric','contrast'))
write.csv(NONADD_MC,file.path('results','comparisons','coupling_nonadditivity_descriptive_MC_summary.csv'),row.names=FALSE,na='')

# Coupling moderation of SES and empirical COOP effects: beta_COUPLED - beta_single.
modrows<-list(); mk<-0L
if(exists('INTER_BY_RUN') && nrow(INTER_BY_RUN)) {
  for(term in c('SES_raw','COOP')) for(info in c('FIXED','RENEWED')) for(run in unique(INTER_BY_RUN$run))
  for(st in REPORT_STEPS) for(comp in c('RI','DEBATE')) {
    a<-INTER_BY_RUN[INTER_BY_RUN$process=='COUPLED' & INTER_BY_RUN$info_regime==info & INTER_BY_RUN$run==run &
                     INTER_BY_RUN$step==st & INTER_BY_RUN$term==term,,drop=FALSE]
    b<-INTER_BY_RUN[INTER_BY_RUN$process==comp & INTER_BY_RUN$info_regime==info & INTER_BY_RUN$run==run &
                     INTER_BY_RUN$step==st & INTER_BY_RUN$term==term,,drop=FALSE]
    if(!nrow(a)||!nrow(b))next
    q<-merge(a[,c('metric','estimate')],b[,c('metric','estimate')],by='metric',suffixes=c('_C','_S'))
    if(!nrow(q))next
    for(j in seq_len(nrow(q))) {
      mk<-mk+1L; modrows[[mk]]<-data.frame(term=term,info_regime=info,run=run,step=st,comparator=comp,
                                            metric=q$metric[j],estimate=q$estimate_C[j]-q$estimate_S[j],stringsAsFactors=FALSE)
    }
  }
}
COUPLING_MODERATION_BY_RUN<-if(length(modrows))rbind_fill(modrows) else data.frame()
write.csv(COUPLING_MODERATION_BY_RUN,file.path('results','comparisons','coupling_SES_COOP_moderation_by_run.csv'),row.names=FALSE,na='')
COUPLING_MODERATION_MC<-mc_summary(COUPLING_MODERATION_BY_RUN,c('term','info_regime','step','comparator','metric'))
write.csv(COUPLING_MODERATION_MC,file.path('results','comparisons','coupling_SES_COOP_moderation_MC_summary.csv'),row.names=FALSE,na='')

# Strongest condition-moderation test: paired counterfactual difference-in-differences.
CF_COUPLING_MODERATION_BY_RUN<-data.frame()
if(exists('CF_CONDITION_BY_RUN') && nrow(CF_CONDITION_BY_RUN)) {
  aa<-CF_CONDITION_BY_RUN[CF_CONDITION_BY_RUN$process=='COUPLED',c('info_regime','run','step','metric','estimate')]
  bb<-CF_CONDITION_BY_RUN[CF_CONDITION_BY_RUN$process=='DEBATE',c('info_regime','run','step','metric','estimate')]
  if(nrow(aa)&&nrow(bb)) {
    q<-merge(aa,bb,by=c('info_regime','run','step','metric'),suffixes=c('_COUPLED','_DEBATE'))
    q$estimate<-q$estimate_COUPLED-q$estimate_DEBATE
    q$contrast<-'(COOP-COMP)_COUPLED_MINUS_(COOP-COMP)_DEBATE'
    CF_COUPLING_MODERATION_BY_RUN<-q[,c('info_regime','run','step','metric','contrast','estimate')]
  }
}
write.csv(CF_COUPLING_MODERATION_BY_RUN,file.path('results','comparisons','counterfactual_coupling_condition_moderation_by_run.csv'),row.names=FALSE,na='')
CF_COUPLING_MODERATION_MC<-mc_summary(CF_COUPLING_MODERATION_BY_RUN,c('info_regime','step','metric','contrast'))
write.csv(CF_COUPLING_MODERATION_MC,file.path('results','comparisons','counterfactual_coupling_condition_moderation_MC_summary.csv'),row.names=FALSE,na='')


# ============================================================================
# 12_export.R
# ============================================================================
# Compact participant panel export plus article-facing summaries.
nr<-if(exists('AGENT_EXPORT_RUNS_OVERRIDE',inherits=TRUE)) as.integer(AGENT_EXPORT_RUNS_OVERRIDE) else cfg_int('agent_export_runs')
PANEL_EXPORT<-PANEL_ALL[PANEL_ALL$run<=nr,,drop=FALSE]
write.csv(PANEL_EXPORT,file.path('results','panel','harmonized_agent_panel_first_runs.csv'),row.names=FALSE,na='')
if(exists('DYAD_ALL') && nrow(DYAD_ALL)) write.csv(DYAD_ALL,file.path('results','panel','debate_dyads_first_runs.csv'),row.names=FALSE,na='')
if(exists('CF_PANEL_ALL') && nrow(CF_PANEL_ALL)) {
  CF_EXPORT<-CF_PANEL_ALL[CF_PANEL_ALL$run<=nr,,drop=FALSE]
  write.csv(CF_EXPORT,file.path('results','panel','counterfactual_condition_panel_first_runs.csv'),row.names=FALSE,na='')
}

# Monte Carlo population summary in long format.
metric_cols<-setdiff(names(POP_ALL),c('process','info_regime','run','step','design','condition_scenario'))
pl<-list(); pk<-0L
for(m in metric_cols) {
  x<-POP_ALL[[m]]
  if(!is.numeric(x))next
  pk<-pk+1L
  pl[[pk]]<-data.frame(process=POP_ALL$process,info_regime=POP_ALL$info_regime,
                       run=POP_ALL$run,step=POP_ALL$step,metric=m,estimate=x,stringsAsFactors=FALSE)
}
pop_long<-if(length(pl))rbind_fill(pl) else data.frame()
pop_long<-pop_long[is.finite(pop_long$estimate),,drop=FALSE]
POP_MC<-mc_summary(pop_long,c('process','info_regime','step','metric'))
write.csv(POP_MC,file.path('results','population','population_MC_summary.csv'),row.names=FALSE,na='')

# 1) Main learning table: stock and density are explicitly separated.
learning_metrics<-c('KnowledgeStock_mean','NetKnowledgeStockGain_mean','KnowledgeDensity_mean','CoreKnowledgeStock_mean',
                    'NewKnowledgeStock_mean','MeanCumulativeLearningAcquisitions','MeanCumulativeLearningLosses',
                    'MeanCumulativeLearningBalance','MeanCumulativeExposureCount','MeanLearningEfficiencyPerExposure',
                    'MeanNetLearningPerExposure','MeanCalibrationImprovement','MeanAbsCalibrationError','SelfKnowledgeCorrelation','VarianceReduction')
TABLE_LEARNING<-POP_MC[POP_MC$metric%in%learning_metrics & POP_MC$process%in%c('RI','DEBATE','COUPLED'),,drop=FALSE]
write.csv(TABLE_LEARNING,file.path('results','population','Table_MAIN_learning_dynamics.csv'),row.names=FALSE,na='')


# 1b) Self-directed epistemic vigilance / metacognitive calibration.
self_metrics<-c('MeanSelfCredit','MeanSelfBias','MeanSelfOverCredit','MeanSelfUnderCredit',
                'MeanAbsCalibrationError','MeanCalibrationImprovement','SelfKnowledgeCorrelation')
TABLE_SELF_VIGILANCE<-POP_MC[POP_MC$metric%in%self_metrics & POP_MC$process%in%c('RI','DEBATE','COUPLED'),,drop=FALSE]
write.csv(TABLE_SELF_VIGILANCE,file.path('results','population','Table_MAIN_self_vigilance.csv'),row.names=FALSE,na='')

# 2) Debate/coupling vigilance and epistemic-credit misallocation table.
social_metrics<-paste0('Social_',c('RecognitionAccuracy','MeanRecognizedExpertise','MeanRecognitionBias','MeanRecognitionError',
                    'MeanUnderRecognitionMagnitude','MeanOverRecognitionMagnitude','MeanBenevolenceSignal','MeanOtherCredit','MeanOtherCreditBias',
                    'MeanOtherCreditCalibrationError','MeanUnderCreditMagnitude','MeanOverCreditMagnitude',
                    'MeanUnderRecognitionMoreExpertMagnitude','MeanUnderCreditMoreExpertMagnitude','MeanRelativeCreditSelfMinusMoreExpert',
                    'RelativeCreditSelfMinusOther','ExpertUseEfficiency','MissedCorrectiveOpportunityRate',
                    'RecognitionRankReversalRate','CreditRankReversalRate','UnderweightMoreExpertRate','OverweightLessExpertRate','WeightMoreExpert','WeightLessExpert',
                    'EpistemicCreditMisallocationIndex','EpistemicCreditAllocationIndex'))
TABLE_CREDIT_MISALLOCATION<-POP_MC[POP_MC$metric%in%social_metrics & POP_MC$process%in%c('DEBATE','COUPLED'),,drop=FALSE]
write.csv(TABLE_CREDIT_MISALLOCATION,file.path('results','population','Table_MAIN_epistemic_credit_misallocation.csv'),row.names=FALSE,na='')

# 3) SES effects on learning and their cumulative slopes.
if(exists('INTER_MC')) {
  ses_metrics<-c('KnowledgeStock','NetKnowledgeStockGain','KnowledgeDensity','CumulativeLearningAcquisitions',
                 'CumulativeLearningBalance','LearningEfficiencyPerExposure','CalibrationImprovement','AbsCalibrationError')
  TABLE_SES_HORIZON<-INTER_MC[INTER_MC$term=='SES_raw' & INTER_MC$metric%in%ses_metrics,,drop=FALSE]
  write.csv(TABLE_SES_HORIZON,file.path('results','statistics','Table_MAIN_SES_effects_by_horizon.csv'),row.names=FALSE,na='')
}
if(exists('INTER_MC')) {
  TABLE_SES_STOCK_DENSITY<-INTER_MC[INTER_MC$term=='SES_raw' & INTER_MC$process%in%c('RI','COUPLED') &
                                      INTER_MC$info_regime=='RENEWED' & INTER_MC$metric%in%c('KnowledgeStock','KnowledgeDensity'),,drop=FALSE]
  write.csv(TABLE_SES_STOCK_DENSITY,file.path('results','statistics','Table_MAIN_SES_stock_density_RENEWED.csv'),row.names=FALSE,na='')
}
if(exists('SLOPE_EFFECTS_MC')) {
  TABLE_SES_SLOPE<-SLOPE_EFFECTS_MC[SLOPE_EFFECTS_MC$term=='SES_raw',,drop=FALSE]
  write.csv(TABLE_SES_SLOPE,file.path('results','statistics','Table_MAIN_SES_cumulative_slope_effects.csv'),row.names=FALSE,na='')
  TABLE_COOP_SLOPE<-SLOPE_EFFECTS_MC[SLOPE_EFFECTS_MC$term=='COOP',,drop=FALSE]
  write.csv(TABLE_COOP_SLOPE,file.path('results','statistics','Table_MAIN_COOP_cumulative_slope_effects.csv'),row.names=FALSE,na='')
}

# 4) Cumulative COOP/COMP divergence from step 1.
if(exists('CUM_ADJ_MC')) {
  TABLE_CUM_COND<-CUM_ADJ_MC[CUM_ADJ_MC$term=='COOP',,drop=FALSE]
  write.csv(TABLE_CUM_COND,file.path('results','statistics','Table_MAIN_COOP_COMP_cumulative_divergence.csv'),row.names=FALSE,na='')
}
if(exists('CF_CONDITION_MC')) write.csv(CF_CONDITION_MC,file.path('results','statistics','Table_MAIN_counterfactual_same_agent_COOP_COMP.csv'),row.names=FALSE,na='')
if(exists('CF_CUMULATIVE_MC')) write.csv(CF_CUMULATIVE_MC,file.path('results','statistics','Table_MAIN_counterfactual_cumulative_COOP_COMP.csv'),row.names=FALSE,na='')
if(exists('CF_CONDITION_MC') && nrow(CF_CONDITION_MC)) {
  receptivity_metrics<-c('RecognitionAccuracy','MeanOtherCredit','MeanUnderCreditMagnitude','MeanOverCreditMagnitude',
                         'WeightMoreExpert','WeightLessExpert','UnderweightMoreExpertRate','OverweightLessExpertRate',
                         'ExpertUseEfficiency','MissedCorrectiveOpportunityRate','EpistemicCreditMisallocationIndex',
                         'CumulativeLearningAcquisitions','CumulativeLearningLosses','CumulativeLearningBalance')
  TABLE_SOCIAL_RECEPTIVITY<-CF_CONDITION_MC[CF_CONDITION_MC$metric%in%receptivity_metrics,,drop=FALSE]
  write.csv(TABLE_SOCIAL_RECEPTIVITY,file.path('results','statistics','Table_MAIN_social_receptivity_diagnostics.csv'),row.names=FALSE,na='')
}

# 5) Coupling vs each single process and social moderation.
if(exists('CROSS_PROCESS_MC')) {
  TABLE_COUPLING_COMMON<-CROSS_PROCESS_MC[CROSS_PROCESS_MC$process_A=='COUPLED',,drop=FALSE]
  write.csv(TABLE_COUPLING_COMMON,file.path('results','comparisons','Table_MAIN_coupling_vs_single_learning.csv'),row.names=FALSE,na='')
}
if(exists('COUPLING_SOCIAL_MC')) write.csv(COUPLING_SOCIAL_MC,file.path('results','comparisons','Table_MAIN_coupling_vs_debate_social.csv'),row.names=FALSE,na='')
if(exists('COUPLING_MODERATION_MC')) write.csv(COUPLING_MODERATION_MC,file.path('results','comparisons','Table_MAIN_coupling_SES_COOP_moderation.csv'),row.names=FALSE,na='')
if(exists('CF_COUPLING_MODERATION_MC')) write.csv(CF_COUPLING_MODERATION_MC,file.path('results','comparisons','Table_MAIN_counterfactual_coupling_condition_moderation.csv'),row.names=FALSE,na='')

writeLines(c(
  'MOVICI-CAVL SMA V3.4 — INFERENCE LAYERS',
  '1) Learning is split into KnowledgeStock (absolute known atoms) and KnowledgeDensity (share of active information world mastered).',
  '2) CumulativeLearningAcquisitions/Losses exclude exogenous distributed seed knowledge in standalone renewed Debate.',
  '3) Intra-subject horizon tests follow the same agent from its process-specific empirical baseline.',
  '4) Cumulative step1->horizon tables distinguish a one-episode effect from an effect that grows with repetition.',
  '5) Inter-subject COOP/COMP and SES effects use participant-level models; Debate/Coupled horizon SEs are cluster-robust by current group when possible.',
  '6) Counterfactual intra-condition tests clone the same agents under COOP and COMP with common random-number seeds; these are separate from the empirical between-subject design.',
  '7) Monte Carlo worlds quantify simulation uncertainty and are NEVER treated as additional human participants.',
  '8) Cross-process learning comparisons are matched by ID and favor change/stock-gain metrics over raw T1-vs-T2 levels.',
  '9) EpistemicCreditMisallocationIndex is intentionally directional: it captures under-use of available corrective expertise, not every symmetric calibration error. Over-credit is reported separately. Broader epistemic injustice remains a theoretical interpretation, not the direct name of the index.',
  '10) Coupling non-additivity is descriptive, not a causal interaction estimand, because the coupled trajectory is recursive.'
),file.path('results','statistics','READ_ME_INFERENCE.txt'))


# ============================================================================
# 13_regression_checks.R
# ============================================================================
checks<-list(); k<-0L
add_check<-function(name,pass,detail='') {
  k<<-k+1L; checks[[k]]<<-data.frame(check=name,pass=isTRUE(pass),detail=as.character(detail),stringsAsFactors=FALSE)
}
add_check('report_steps_exact',identical(REPORT_STEPS,c(1L,5L,10L,15L,20L,25L,50L)),paste(REPORT_STEPS,collapse=';'))
add_check('ri_exposure_budget_positive',cfg_int('ri_exposure_budget')>0,cfg('ri_exposure_budget'))
add_check('ri_new_slots_within_budget',cfg_int('ri_new_exposure_slots')>=0 && cfg_int('ri_new_exposure_slots')<=cfg_int('ri_exposure_budget'),
          paste(cfg_int('ri_new_exposure_slots'),'of',cfg_int('ri_exposure_budget')))
add_check('ri_reliability_bounds',cfg_num('ri_reliability')>=0 && cfg_num('ri_reliability')<=1,cfg('ri_reliability'))
key<-paste(PANEL_ALL$process,PANEL_ALL$info_regime,PANEL_ALL$run,PANEL_ALL$step,PANEL_ALL$ID_MOVICI,sep='|')
add_check('unique_panel_keys',!anyDuplicated(key),sum(duplicated(key)))

for(m in c('KnowledgeDensity','K_prop','CoreKnowledgeDensity','AcquisitionRate','LossRate','RetentionRate','TurnoverRate',
           'StateTurnoverRate','Coverage','EncounteredAccuracy','LearningEfficiencyPerExposure')) {
  if(!m%in%names(PANEL_ALL))next
  x<-PANEL_ALL[[m]]; ok<-is.finite(x)
  add_check(paste0(m,'_bounds_0_1'),!any(ok) || all(x[ok]>=-1e-12 & x[ok]<=1+1e-12),
            if(any(ok))paste(range(x[ok]),collapse='..') else 'no finite values')
}
for(m in c('ExpertUseEfficiency','MissedCorrectiveOpportunityRate','RecognitionRankReversalRate','CreditRankReversalRate',
           'UnderweightMoreExpertRate','OverweightLessExpertRate','WeightMoreExpert','WeightLessExpert','EpistemicCreditMisallocationIndex','EpistemicCreditAllocationIndex')) {
  x<-PANEL_ALL[[m]]; ok<-is.finite(x)
  add_check(paste0(m,'_bounds_0_1'),!any(ok) || all(x[ok]>=-1e-12 & x[ok]<=1+1e-12),
            if(any(ok))paste(range(x[ok]),collapse='..') else 'no finite values')
}

add_check('KnowledgeStock_le_PoolSize',all(PANEL_ALL$KnowledgeStock<=PANEL_ALL$PoolSize+1e-12,na.rm=TRUE))
add_check('KnowledgeStock_ge_0',all(PANEL_ALL$KnowledgeStock>=-1e-12,na.rm=TRUE))
add_check('NetStock_identity',max(abs(PANEL_ALL$NetKnowledgeStockGain-(PANEL_ALL$KnowledgeStock-PANEL_ALL$BaselineKnowledgeStock)),na.rm=TRUE)<1e-10)

e<-PANEL_ALL$ExpertUseEfficiency; m<-PANEL_ALL$MissedCorrectiveOpportunityRate
ok<-is.finite(e)&is.finite(m)
add_check('EUE_MCOR_complement',!any(ok) || max(abs(e[ok]+m[ok]-1))<1e-10,if(any(ok))max(abs(e[ok]+m[ok]-1)) else 'no defined EUE')
em<-PANEL_ALL$EpistemicCreditMisallocationIndex; ea<-PANEL_ALL$EpistemicCreditAllocationIndex
ok<-is.finite(em)&is.finite(ea)
add_check('credit_allocation_misallocation_complement',!any(ok) || max(abs(em[ok]+ea[ok]-1))<1e-10,
          if(any(ok))max(abs(em[ok]+ea[ok]-1)) else 'no defined index')

# The directional misallocation index is the mean of the available corrective-underuse components.
comp_mat<-cbind(PANEL_ALL$MissedCorrectiveOpportunityRate,PANEL_ALL$CreditRankReversalRate,PANEL_ALL$UnderweightMoreExpertRate)
calc_mis<-apply(comp_mat,1,function(v) if(any(is.finite(v)))mean(v[is.finite(v)]) else NA_real_)
ok<-is.finite(calc_mis)&is.finite(PANEL_ALL$EpistemicCreditMisallocationIndex)
add_check('directional_misallocation_component_identity',!any(ok) || max(abs(calc_mis[ok]-PANEL_ALL$EpistemicCreditMisallocationIndex[ok]))<1e-10,
          if(any(ok))max(abs(calc_mis[ok]-PANEL_ALL$EpistemicCreditMisallocationIndex[ok])) else 'no defined index')

# From step 2 onward RI uses the same limited-exposure engine in FIXED and RENEWED.
ri_long<-PANEL_ALL[PANEL_ALL$process=='RI' & PANEL_ALL$step>=2,,drop=FALSE]
add_check('ri_longitudinal_exposure_budget',!nrow(ri_long) || all(ri_long$ExposureCount==cfg_int('ri_exposure_budget')),
          if(nrow(ri_long))paste(range(ri_long$ExposureCount,na.rm=TRUE),collapse='..') else 'no rows')
cp_long<-PANEL_ALL[PANEL_ALL$process=='COUPLED' & PANEL_ALL$step>=2,,drop=FALSE]
add_check('coupled_RI_longitudinal_exposure_budget',!nrow(cp_long) || all(cp_long$RI_ExposureCount==cfg_int('ri_exposure_budget')),
          if(nrow(cp_long))paste(range(cp_long$RI_ExposureCount,na.rm=TRUE),collapse='..') else 'no rows')
ri_s1<-PANEL_ALL[PANEL_ALL$process=='RI' & PANEL_ALL$step==1,,drop=FALSE]
add_check('ri_step1_full_pool_anchor',!nrow(ri_s1) || all(ri_s1$ExposureCount==CORE_N_ITEMS),
          if(nrow(ri_s1))paste(unique(ri_s1$ExposureCount),collapse=';') else 'no rows')

# Pool-size logic: FIXED always 20; RENEWED grows by new_items_per_cycle from step 2.
fx<-PANEL_ALL[PANEL_ALL$info_regime=='FIXED',]
add_check('fixed_pool_constant_core',all(fx$PoolSize==CORE_N_ITEMS),paste(unique(fx$PoolSize),collapse=';'))
rn<-PANEL_ALL[PANEL_ALL$info_regime=='RENEWED',]
if(nrow(rn)) {
  exp_pool<-ifelse(rn$step==0,CORE_N_ITEMS,CORE_N_ITEMS+cfg_int('new_items_per_cycle')*pmax(rn$step-1,0))
  add_check('renewed_pool_growth_exact',all(rn$PoolSize==exp_pool),paste(range(rn$PoolSize),collapse='..'))
}

# Exogenous state additions are only allowed in standalone RENEWED Debate.
nonseed<-PANEL_ALL[!(PANEL_ALL$process=='DEBATE' & PANEL_ALL$info_regime=='RENEWED'),]
add_check('state_additions_only_debate_renewed',all(nonseed$CumulativeStateAdditions==0,na.rm=TRUE),
          max(nonseed$CumulativeStateAdditions,na.rm=TRUE))

# Cumulative learning counters must be non-negative and non-decreasing across reported horizons.
for(met in c('CumulativeLearningAcquisitions','CumulativeLearningLosses','CumulativeExposureCount','CumulativeStateAdditions')) {
  add_check(paste0(met,'_nonnegative'),all(PANEL_ALL[[met]]>=-1e-12,na.rm=TRUE))
  ord<-order(PANEL_ALL$process,PANEL_ALL$info_regime,PANEL_ALL$run,PANEL_ALL$ID_MOVICI,PANEL_ALL$step)
  q<-PANEL_ALL[ord,c('process','info_regime','run','ID_MOVICI','step',met)]
  grp<-interaction(q$process,q$info_regime,q$run,q$ID_MOVICI,drop=TRUE)
  bad<-FALSE
  for(ix in split(seq_len(nrow(q)),grp)) {
    v<-q[[met]][ix]
    if(any(diff(v[is.finite(v)]) < -1e-12)) { bad<-TRUE; break }
  }
  add_check(paste0(met,'_nondecreasing'),!bad)
}

expected_primary<-nrow(PRIMARY_SCENARIOS)*N_RUNS*(length(REPORT_STEPS)+1)*nrow(AGENTS)
actual_primary<-nrow(PANEL_ALL[PANEL_ALL$process!='DEBATE_FROZEN',])
add_check('primary_panel_row_count',actual_primary==expected_primary,paste(actual_primary,'vs',expected_primary))
add_check('all_primary_scenarios_present',all(paste(PRIMARY_SCENARIOS$process,PRIMARY_SCENARIOS$info_regime) %in%
                                               unique(paste(PANEL_ALL$process,PANEL_ALL$info_regime))))

# RI has no direct COOP/COMP social-source outputs.
ri<-PANEL_ALL[PANEL_ALL$process=='RI' & PANEL_ALL$step>0,]
add_check('RI_social_metrics_undefined',all(!is.finite(ri$MeanOtherCredit)) && all(!is.finite(ri$EpistemicCreditMisallocationIndex)))

# Counterfactual design must contain paired COOP/COMP copies of every agent when enabled.
if(exists('CF_PANEL_ALL') && nrow(CF_PANEL_ALL)) {
  cfkey<-paste(CF_PANEL_ALL$process,CF_PANEL_ALL$info_regime,CF_PANEL_ALL$run,CF_PANEL_ALL$step,CF_PANEL_ALL$ID_MOVICI,CF_PANEL_ALL$condition_scenario,sep='|')
  add_check('counterfactual_unique_keys',!anyDuplicated(cfkey),sum(duplicated(cfkey)))
  tab<-table(CF_PANEL_ALL$condition_scenario)
  add_check('counterfactual_two_arms',all(c('COOP','COMP')%in%names(tab)),paste(names(tab),collapse=';'))
  add_check('counterfactual_balanced_arms',length(tab)>=2 && tab['COOP']==tab['COMP'],paste(tab,collapse=';'))
  required_cf_learning<-c('CumulativeLearningAcquisitions','CumulativeLearningLosses','CumulativeLearningBalance')
  add_check('counterfactual_learning_counters_present',all(required_cf_learning %in% names(CF_PANEL_ALL)),
            paste(intersect(required_cf_learning,names(CF_PANEL_ALL)),collapse=';'))
  if(all(required_cf_learning %in% names(CF_PANEL_ALL))) {
    okcf<-is.finite(CF_PANEL_ALL$CumulativeLearningAcquisitions) & is.finite(CF_PANEL_ALL$CumulativeLearningLosses) &
          is.finite(CF_PANEL_ALL$CumulativeLearningBalance)
    errcf<-if(any(okcf)) max(abs(CF_PANEL_ALL$CumulativeLearningBalance[okcf] -
                                (CF_PANEL_ALL$CumulativeLearningAcquisitions[okcf]-CF_PANEL_ALL$CumulativeLearningLosses[okcf]))) else 0
    add_check('counterfactual_learning_balance_identity',is.finite(errcf) && errcf<1e-10,errcf)
  }
}

QA<-rbind_fill(checks)
write.csv(QA,file.path('validation','REGRESSION_CHECKS.csv'),row.names=FALSE)
if(any(!QA$pass)) {
  print(QA[!QA$pass,,drop=FALSE])
  stop('Regression checks failed. See validation/REGRESSION_CHECKS.csv')
}
cat('Regression checks: PASS\n')


# ============================================================================
# 14_figures.R
# ============================================================================
# Dependency-free diagnostic figures. Tables remain the primary scientific outputs.
if(exists('POP_MC') && nrow(POP_MC)) {
  draw_metric<-function(metric,filename,ylab,title,processes=c('RI','DEBATE','COUPLED')) {
    sel<-POP_MC[POP_MC$metric==metric & POP_MC$process%in%processes,,drop=FALSE]
    if(!nrow(sel))return(invisible(NULL))
    yr<-range(c(sel$MC_q025,sel$MC_q975),na.rm=TRUE)
    png(file.path('figures',filename),width=1200,height=800,res=120)
    plot(range(sel$step),yr,type='n',xlab='Step / cycle',ylab=ylab,main=title)
    combos<-unique(sel[,c('process','info_regime')])
    for(i in seq_len(nrow(combos))) {
      q<-sel[sel$process==combos$process[i] & sel$info_regime==combos$info_regime[i],]
      q<-q[order(q$step),]
      lines(q$step,q$estimate_mean,lty=i,pch=i,type='b')
    }
    legend('topleft',legend=paste(combos$process,combos$info_regime,sep=' / '),lty=seq_len(nrow(combos)),pch=seq_len(nrow(combos)),cex=.75)
    dev.off()
  }
  draw_metric('KnowledgeStock_mean','KnowledgeStock_by_step.png','Mean known atoms','Absolute knowledge stock')
  draw_metric('KnowledgeDensity_mean','KnowledgeDensity_by_step.png','Share of active world mastered','Knowledge density')
  draw_metric('MeanCalibrationImprovement','CalibrationImprovement_by_step.png','Calibration improvement','Metacognitive calibration')
  draw_metric('Social_EpistemicCreditMisallocationIndex','EpistemicCreditMisallocation_by_step.png','Epistemic credit misallocation index','Epistemic credit misallocation',c('DEBATE','COUPLED'))
}



# ============================================================================
# 15_PUBLICATION_EXTENSIONS.R — JASSS calibration, convergence, robustness
# ============================================================================
if(!dir.exists(file.path('results','publication'))) dir.create(file.path('results','publication'),recursive=TRUE)

# --- 15a. Empirical calibration / structural validation targets at step 1 ---
# Canonical MOVICI factual scoring: the article-level K_GLOBAL variables implement
# the deposited scoring rule (including missing item responses scored as 0).
# Using them here guarantees exact agreement with the empirical preprints/packages.
emp_k1<-as.numeric(P$K_GLOBAL_T1)*20
emp_k2<-as.numeric(P$K_GLOBAL_T2)*20
emp_k3<-as.numeric(P$K_GLOBAL_T3)*20
emp_df<-data.frame(K1=emp_k1,K2=emp_k2,K3=emp_k3,SES_raw=SES_RAW,COOP=as.numeric(AGENTS$condition=='COOP'))
fit_ri_emp<-lm(K2~K1+SES_raw+COOP,data=emp_df)

emp_source<-DYADS_EMP
emp_source$z_expertise<-zscore(as.numeric(emp_source$perceived_expertise))
emp_source$z_benevolence<-zscore(as.numeric(emp_source$perceived_benevolence))
agg_exp<-aggregate(z_expertise~evaluator_ID+condition,data=emp_source,FUN=safe_mean)
agg_ben<-aggregate(z_benevolence~evaluator_ID+condition,data=emp_source,FUN=safe_mean)
agg_exp$COOP<-as.numeric(agg_exp$condition=='COOP'); agg_ben$COOP<-as.numeric(agg_ben$condition=='COOP')
fit_exp<-lm(z_expertise~COOP,data=agg_exp)
fit_ben<-lm(z_benevolence~COOP,data=agg_ben)

EMP_TARGETS<-data.frame(
  target_id=c('RI_GAIN_20','DEBATE_GAIN_20','RI_SES_BETA_20','RI_COOP_BETA_20','DEBATE_COOP_RECOGNIZED_EXPERTISE','DEBATE_COOP_BENEVOLENCE'),
  empirical_estimate=c(safe_mean(emp_k2-emp_k1),safe_mean(emp_k3-emp_k2),coef(fit_ri_emp)['SES_raw'],coef(fit_ri_emp)['COOP'],coef(fit_exp)['COOP'],coef(fit_ben)['COOP']),
  role=c('CALIBRATION','STRUCTURAL_CHECK','CALIBRATION','STRUCTURAL_CHECK','CALIBRATION','CALIBRATION'),
  empirical_definition=c('Mean T2-T1 factual score on /20 scale','Mean T3-T2 factual score on /20 scale','K2 /20 ~ K1 /20 + SES + COOP','K2 /20 ~ K1 /20 + SES + COOP','Evaluator-level mean z perceived expertise ~ COOP','Evaluator-level mean z perceived benevolence ~ COOP'),
  stringsAsFactors=FALSE)
write.csv(EMP_TARGETS,file.path('results','publication','empirical_step1_targets.csv'),row.names=FALSE,na='')

sim_target_rows<-list(); tk<-0L
add_sim_target<-function(id,x) { tk<<-tk+1L; sim_target_rows[[tk]]<<-data.frame(target_id=id,simulation_estimate=x,stringsAsFactors=FALSE) }
q<-POP_MC[POP_MC$process=='RI'&POP_MC$info_regime=='FIXED'&POP_MC$step==1&POP_MC$metric=='NetKnowledgeStockGain_mean',]
if(nrow(q)) add_sim_target('RI_GAIN_20',q$estimate_mean[1])
q<-POP_MC[POP_MC$process=='DEBATE'&POP_MC$info_regime=='FIXED'&POP_MC$step==1&POP_MC$metric=='NetKnowledgeStockGain_mean',]
if(nrow(q)) add_sim_target('DEBATE_GAIN_20',q$estimate_mean[1])
q<-INTER_MC[INTER_MC$process=='RI'&INTER_MC$info_regime=='FIXED'&INTER_MC$step==1&INTER_MC$metric=='KnowledgeStock'&INTER_MC$term=='SES_raw',]
if(nrow(q)) add_sim_target('RI_SES_BETA_20',q$estimate_mean[1])
q<-INTER_MC[INTER_MC$process=='RI'&INTER_MC$info_regime=='FIXED'&INTER_MC$step==1&INTER_MC$metric=='KnowledgeStock'&INTER_MC$term=='COOP',]
if(nrow(q)) add_sim_target('RI_COOP_BETA_20',q$estimate_mean[1])
q<-INTER_MC[INTER_MC$process=='DEBATE'&INTER_MC$info_regime=='FIXED'&INTER_MC$step==1&INTER_MC$metric=='MeanRecognizedExpertise'&INTER_MC$term=='COOP',]
if(nrow(q)) add_sim_target('DEBATE_COOP_RECOGNIZED_EXPERTISE',q$estimate_mean[1])
q<-INTER_MC[INTER_MC$process=='DEBATE'&INTER_MC$info_regime=='FIXED'&INTER_MC$step==1&INTER_MC$metric=='MeanBenevolenceSignal'&INTER_MC$term=='COOP',]
if(nrow(q)) add_sim_target('DEBATE_COOP_BENEVOLENCE',q$estimate_mean[1])
SIM_TARGETS<-rbind_fill(sim_target_rows)
CALIBRATION_TABLE<-merge(EMP_TARGETS,SIM_TARGETS,by='target_id',all.x=TRUE,sort=FALSE)
CALIBRATION_TABLE$absolute_difference<-abs(CALIBRATION_TABLE$simulation_estimate-CALIBRATION_TABLE$empirical_estimate)
write.csv(CALIBRATION_TABLE,file.path('results','publication','Table_CALIBRATION_VALIDATION_STEP1.csv'),row.names=FALSE,na='')

# --- 15a2. Empirical mechanism check: ExpertiseAllocationGain -> factual progression ---
# This analysis is not used to fit the long-run SMA. It reproduces the complementary
# empirical mechanism check discussed in the manuscript from the two public article files.
emp_eag_dyad<-DYADS_EMP
emp_eag_dyad$z_perceived_expertise<-zscore(as.numeric(emp_eag_dyad$perceived_expertise))

# Reconstruct debate groups as connected components of the directed evaluation graph.
# This is robust to a small number of missing dyadic evaluations.
emp_nodes<-unique(c(as.character(emp_eag_dyad$evaluator_ID),as.character(emp_eag_dyad$evaluatee_ID)))
emp_component<-setNames(seq_along(emp_nodes),emp_nodes)
repeat {
  changed<-FALSE
  for(rr in seq_len(nrow(emp_eag_dyad))) {
    a<-as.character(emp_eag_dyad$evaluator_ID[rr]); b<-as.character(emp_eag_dyad$evaluatee_ID[rr])
    ca<-emp_component[a]; cb<-emp_component[b]
    if(is.finite(ca) && is.finite(cb) && ca!=cb) {
      lo<-min(ca,cb); hi<-max(ca,cb)
      emp_component[emp_component==hi]<-lo
      changed<-TRUE
    }
  }
  if(!changed) break
}
emp_component<-match(emp_component,unique(emp_component))
names(emp_component)<-emp_nodes

emp_eag_rows<-list(); ee<-0L
for(id in unique(emp_eag_dyad$evaluator_ID)) {
  g<-emp_eag_dyad[emp_eag_dyad$evaluator_ID==id &
                  is.finite(emp_eag_dyad$z_perceived_expertise) &
                  is.finite(emp_eag_dyad$evaluatee_T2_knowledge),,drop=FALSE]
  if(nrow(g)<2) next
  sw<-softmax_vec(g$z_perceived_expertise)
  alloc<-sum(sw*as.numeric(g$evaluatee_T2_knowledge))-mean(as.numeric(g$evaluatee_T2_knowledge))
  ee<-ee+1L
  emp_eag_rows[[ee]]<-data.frame(
    ID_MOVICI=as.character(id),
    ExpertiseAllocationGain=alloc,
    DebateGroupID=as.integer(emp_component[as.character(id)]),
    N_partners=nrow(g),
    stringsAsFactors=FALSE)
}
EMP_EAG<-if(length(emp_eag_rows))rbind_fill(emp_eag_rows) else data.frame()

if(nrow(EMP_EAG)) {
  emp_agent<-data.frame(
    ID_MOVICI=as.character(P$ID_MOVICI),
    K2=as.numeric(P$K_GLOBAL_T2)*20,
    K3=as.numeric(P$K_GLOBAL_T3)*20,
    condition=as.character(P$QP_GrCondition),
    stringsAsFactors=FALSE)
  EMP_EAG<-merge(EMP_EAG,emp_agent,by='ID_MOVICI',all.x=TRUE,sort=FALSE)
  EMP_EAG$ExpertiseAllocationGain_z<-zscore(EMP_EAG$ExpertiseAllocationGain)
  EMP_EAG$COOP<-as.numeric(EMP_EAG$condition=='COOP')
  EMP_EAG<-EMP_EAG[complete.cases(EMP_EAG[,c('K2','K3','ExpertiseAllocationGain_z','COOP','DebateGroupID')]),,drop=FALSE]

  fit_eag<-lm(K3~K2+ExpertiseAllocationGain_z+COOP,data=EMP_EAG)
  eag_ols<-summary(fit_eag)$coefficients
  eag_hc1<-cluster_coef_table(fit_eag,EMP_EAG$DebateGroupID)

  main_eag<-data.frame(
    analysis='K3 ~ K2 + ExpertiseAllocationGain_z + COOP',
    N=nrow(EMP_EAG),
    clusters=length(unique(EMP_EAG$DebateGroupID)),
    term='ExpertiseAllocationGain_z',
    estimate=unname(coef(fit_eag)['ExpertiseAllocationGain_z']),
    OLS_SE=eag_ols['ExpertiseAllocationGain_z','Std. Error'],
    OLS_p=eag_ols['ExpertiseAllocationGain_z','Pr(>|t|)'],
    cluster_HC1_SE=if(!is.null(eag_hc1))eag_hc1$SE[eag_hc1$term=='ExpertiseAllocationGain_z'] else NA_real_,
    cluster_HC1_p=if(!is.null(eag_hc1))eag_hc1$p[eag_hc1$term=='ExpertiseAllocationGain_z'] else NA_real_,
    CR2_Satterthwaite_available=requireNamespace('clubSandwich',quietly=TRUE),
    stringsAsFactors=FALSE)

  write.csv(EMP_EAG,file.path('results','publication','empirical_expertise_allocation_agent_data.csv'),row.names=FALSE,na='')
  write.csv(main_eag,file.path('results','publication','Table_EMPIRICAL_EXPERTISE_ALLOCATION_CHECK.csv'),row.names=FALSE,na='')

  if(requireNamespace('clubSandwich',quietly=TRUE)) {
    cr2<-clubSandwich::coef_test(fit_eag,vcov='CR2',cluster=EMP_EAG$DebateGroupID,test='Satterthwaite')
    write.csv(as.data.frame(cr2),file.path('results','publication','EMPIRICAL_EXPERTISE_ALLOCATION_CR2.csv'),row.names=TRUE,na='')
  } else {
    writeLines(c(
      'Optional exact CR2/Satterthwaite output not produced because package clubSandwich is not installed.',
      'The main simulation pipeline does not require external R packages.',
      'To reproduce the manuscript CR2/Satterthwaite inference, install.packages("clubSandwich") and rerun RUN_STANDARD.R.'
    ),file.path('results','publication','EMPIRICAL_EXPERTISE_ALLOCATION_CR2_README.txt'))
  }
}

# --- 15b. Empirical debate-size target and feasible within-condition primary partition ---
size_target<-data.frame(condition='ALL',group_size=c(2,3,4),empirical_participants=as.integer(EMP_GROUP_SIZE_COUNTS),empirical_share=EMP_GROUP_SIZE_SHARE)
for(cc in rownames(EMP_GROUP_SIZE_COUNTS_BY_CONDITION)) {
  size_target<-rbind(size_target,data.frame(condition=cc,group_size=c(2,3,4),empirical_participants=as.integer(EMP_GROUP_SIZE_COUNTS_BY_CONDITION[cc,]),empirical_share=as.numeric(EMP_GROUP_SIZE_SHARE_BY_CONDITION[cc,])))
}
part_rows<-list(); ii<-0L
for(cc in c('COOP','COMP')) {
  ncc<-sum(AGENTS$condition==cc)
  targ<-as.numeric(EMP_GROUP_SIZE_SHARE_BY_CONDITION[cc,]); names(targ)<-c('2','3','4'); ct<-best_group_size_counts(ncc,targ)
  for(j in seq_along(ct)) { ii<-ii+1L; gs<-c(2,3,4)[j]; part_rows[[ii]]<-data.frame(condition=cc,N_agents=ncc,group_size=gs,n_groups=ct[j],participants=gs*ct[j],share=gs*ct[j]/ncc) }
}
PRIMARY_PARTITION<-rbind_fill(part_rows)
write.csv(size_target,file.path('results','publication','empirical_group_size_target.csv'),row.names=FALSE)
write.csv(PRIMARY_PARTITION,file.path('results','publication','primary_feasible_group_size_partition.csv'),row.names=FALSE)

# --- 15c. Counterfactual TOTAL-EFFECT-PROXY summaries ---
cf_panel_summary<-function(panel,label) {
  if(is.null(panel)||!nrow(panel)) return(list(by_run=data.frame(),mc=data.frame()))
  mets<-c('KnowledgeStock','CumulativeLearningAcquisitions','SelfCredit_z','SelfBias_z','MeanOtherCredit','ExpertUseEfficiency',
          'MissedCorrectiveOpportunityRate','CreditRankReversalRate','UnderweightMoreExpertRate','EpistemicCreditMisallocationIndex')
  rr<-list(); k<-0L
  for(pr in unique(panel$process)) for(info in unique(panel$info_regime[panel$process==pr])) for(run in unique(panel$run)) for(st in REPORT_STEPS) {
    co<-panel[panel$process==pr&panel$info_regime==info&panel$run==run&panel$step==st&panel$condition_scenario=='COOP',]
    cp<-panel[panel$process==pr&panel$info_regime==info&panel$run==run&panel$step==st&panel$condition_scenario=='COMP',]
    if(!nrow(co)||!nrow(cp)) next
    for(m in mets) if(m%in%names(panel)) {
      q<-merge(co[,c('ID_MOVICI',m),drop=FALSE],cp[,c('ID_MOVICI',m),drop=FALSE],by='ID_MOVICI',suffixes=c('_COOP','_COMP'))
      z<-paired_stats(q[[paste0(m,'_COOP')]],q[[paste0(m,'_COMP')]])
      k<-k+1L; rr[[k]]<-cbind(data.frame(effect_design=label,process=pr,info_regime=info,run=run,step=st,metric=m,contrast='COOP_MINUS_COMP'),z)
    }
  }
  byrun<-rbind_fill(rr)
  list(by_run=byrun,mc=mc_summary(byrun,c('effect_design','process','info_regime','step','metric','contrast')))
}
if(exists('CF_TOTAL_PANEL_ALL')&&nrow(CF_TOTAL_PANEL_ALL)) {
  TOT<-cf_panel_summary(CF_TOTAL_PANEL_ALL,'TOTAL_EFFECT_PROXY')
  write.csv(TOT$by_run,file.path('results','publication','counterfactual_total_effect_proxy_by_run.csv'),row.names=FALSE,na='')
  write.csv(TOT$mc,file.path('results','publication','Table_TOTAL_EFFECT_PROXY_COOP_COMP.csv'),row.names=FALSE,na='')
}

# --- 15d. Monte Carlo convergence diagnostics at configured prefixes ---
mc_prefix_summary<-function(d,keys,estimate_col='estimate',prefixes=c(25L,50L,75L,100L),source='') {
  if(is.null(d)||!nrow(d)||!estimate_col%in%names(d)) return(data.frame())
  maxr<-max(d$run,na.rm=TRUE); prefixes<-prefixes[prefixes<=maxr]
  if(!length(prefixes)) return(data.frame())
  full<-aggregate(d[[estimate_col]],d[keys],safe_mean); names(full)[ncol(full)]<-'full_estimate'
  out<-list(); k<-0L
  for(nn in prefixes) {
    q<-d[d$run<=nn,,drop=FALSE]
    grp<-do.call(interaction,c(unname(q[,keys,drop=FALSE]),list(drop=TRUE,lex.order=TRUE)))
    for(ix in split(seq_len(nrow(q)),grp)) {
      z<-q[ix,,drop=FALSE]; x<-z[[estimate_col]]; x<-x[is.finite(x)]
      if(!length(x)) next
      row<-z[1,keys,drop=FALSE]
      ff<-merge(row,full,by=keys,all.x=TRUE,sort=FALSE)
      k<-k+1L; out[[k]]<-cbind(row,data.frame(source=source,N_runs=length(x),prefix=nn,estimate=safe_mean(x),MC_SD=safe_sd(x),MC_SE=if(length(x)>1)safe_sd(x)/sqrt(length(x)) else NA_real_,full_estimate=ff$full_estimate[1],abs_change_vs_full=abs(safe_mean(x)-ff$full_estimate[1]),stringsAsFactors=FALSE))
    }
  }
  rbind_fill(out)
}
conv_prefix<-as.integer(strsplit(cfg('convergence_prefixes'),';',fixed=TRUE)[[1]])
conv<-list(); ck<-0L
pop_key<-POP_ALL[POP_ALL$step==50 & POP_ALL$process%in%c('RI','DEBATE','COUPLED'),]
for(m in c('NetKnowledgeStockGain_mean','MeanCumulativeLearningBalance','KnowledgeDensity_mean','Social_EpistemicCreditMisallocationIndex')) if(m%in%names(pop_key)) {
  z<-data.frame(process=pop_key$process,info_regime=pop_key$info_regime,run=pop_key$run,metric=m,estimate=pop_key[[m]])
  ck<-ck+1L; conv[[ck]]<-mc_prefix_summary(z,c('process','info_regime','metric'),'estimate',conv_prefix,'POPULATION_STEP50')
}
if(nrow(INTER_BY_RUN)) {
  q<-INTER_BY_RUN[INTER_BY_RUN$step==50 & INTER_BY_RUN$term%in%c('SES_raw','COOP') & INTER_BY_RUN$metric%in%c('KnowledgeStock','ExpertUseEfficiency','EpistemicCreditMisallocationIndex'),]
  if(nrow(q)) { ck<-ck+1L; conv[[ck]]<-mc_prefix_summary(q,c('process','info_regime','metric','term'),'estimate',conv_prefix,'INTER_EFFECT_STEP50') }
}
if(nrow(CF_CONDITION_BY_RUN)) {
  q<-CF_CONDITION_BY_RUN[CF_CONDITION_BY_RUN$step==50 & CF_CONDITION_BY_RUN$metric%in%c('KnowledgeStock','MeanOtherCredit','ExpertUseEfficiency','EpistemicCreditMisallocationIndex'),]
  if(nrow(q)) { ck<-ck+1L; conv[[ck]]<-mc_prefix_summary(q,c('process','info_regime','metric','contrast'),'estimate',conv_prefix,'CONTROLLED_CF_STEP50') }
}
MC_CONVERGENCE<-rbind_fill(conv)
write.csv(MC_CONVERGENCE,file.path('results','publication','MC_CONVERGENCE.csv'),row.names=FALSE,na='')

# --- 15e. Publication sensitivity / ablation / robustness suites ---
run_extensions<-exists('RUN_PUBLICATION_EXTENSIONS_OVERRIDE',inherits=TRUE) && isTRUE(RUN_PUBLICATION_EXTENSIONS_OVERRIDE)

key_signature<-function(panel,process,info,run,label,design) {
  q<-panel[panel$step==50,,drop=FALSE]
  if(!nrow(q)) return(data.frame())
  rows<-list(); k<-0L
  for(m in c('KnowledgeStock','KnowledgeDensity','NetKnowledgeStockGain','CumulativeLearningAcquisitions','CumulativeLearningLosses','CumulativeLearningBalance',
               'SelfCredit_z','RecognitionAccuracy','MeanOtherCredit','MeanUnderCreditMagnitude','MeanOverCreditMagnitude',
               'WeightMoreExpert','WeightLessExpert','UnderweightMoreExpertRate','OverweightLessExpertRate',
               'ExpertUseEfficiency','MissedCorrectiveOpportunityRate','EpistemicCreditMisallocationIndex')) {
    if(m%in%names(q)) { k<-k+1L; rows[[k]]<-data.frame(label=label,design=design,process=process,info_regime=info,run=run,metric=m,signature='MEAN_STEP50',estimate=safe_mean(q[[m]])) }
  }
  if(sum(is.finite(q$SES_raw))>20 && process%in%c('RI','COUPLED')) {
    for(outcome in c('KnowledgeStock','KnowledgeDensity')) {
      fit<-lm(q[[outcome]]~q$SES_raw+I(q$condition=='COOP'))
      k<-k+1L; rows[[k]]<-data.frame(label=label,design=design,process=process,info_regime=info,run=run,metric=outcome,signature='SES_EFFECT_STEP50',estimate=coef(fit)[2])
    }
  }
  rbind_fill(rows)
}

cf_signature<-function(process,info,run,label,profile_mode='OBSERVED') {
  eligible<-AGENTS$ID_MOVICI[AGENTS$condition%in%c('COOP','COMP')]
  co<-run_one_scenario(process,info,run,condition_override='COOP',eligible_ids=eligible,design='EXT_CF',condition_scenario='COOP',profile_mode=profile_mode)$panel
  cp<-run_one_scenario(process,info,run,condition_override='COMP',eligible_ids=eligible,design='EXT_CF',condition_scenario='COMP',profile_mode=profile_mode)$panel
  co<-co[co$step==50,]; cp<-cp[cp$step==50,]
  mets<-c('KnowledgeStock','KnowledgeDensity','CumulativeLearningAcquisitions','CumulativeLearningLosses','CumulativeLearningBalance',
          'SelfCredit_z','RecognitionAccuracy','MeanOtherCredit','MeanUnderCreditMagnitude','MeanOverCreditMagnitude',
          'WeightMoreExpert','WeightLessExpert','UnderweightMoreExpertRate','OverweightLessExpertRate',
          'ExpertUseEfficiency','MissedCorrectiveOpportunityRate','EpistemicCreditMisallocationIndex')
  out<-list(); k<-0L
  for(m in mets) if(m%in%names(co)) {
    q<-merge(co[,c('ID_MOVICI',m)],cp[,c('ID_MOVICI',m)],by='ID_MOVICI',suffixes=c('_COOP','_COMP'))
    d<-q[[paste0(m,'_COOP')]]-q[[paste0(m,'_COMP')]]
    k<-k+1L; out[[k]]<-data.frame(label=label,design='CF_CONTROLLED',process=process,info_regime=info,run=run,metric=m,signature='COOP_MINUS_COMP_STEP50',estimate=safe_mean(d))
  }
  rbind_fill(out)
}

if(run_extensions) {
  cat('Running JASSS publication extensions...\n')
  # Sensitivity: one-at-a-time, low and high vs unchanged central main model.
  SENS<-read.csv(file.path('config','sensitivity_plan.csv'),stringsAsFactors=FALSE,check.names=FALSE)
  sens_rows<-list(); sk<-0L; nr<-cfg_int('sensitivity_runs')
  for(i in seq_len(nrow(SENS))) for(level in c('low','high')) {
    cat('  - sensitivity ',SENS$analysis_id[i],' / ',level,'\n',sep='')
    RUNTIME_CFG_OVERRIDE<-list(); RUNTIME_RI_OVERRIDE<-list(); RUNTIME_DEB_OVERRIDE<-list(); RUNTIME_ABLATION<-'FULL'
    val<-as.numeric(SENS[[level]][i]); src<-toupper(SENS$source[i]); par<-SENS$parameter[i]
    if(src=='CFG') RUNTIME_CFG_OVERRIDE[[par]]<-val else if(src=='RI') RUNTIME_RI_OVERRIDE[[par]]<-val else if(src=='DEB') RUNTIME_DEB_OVERRIDE[[par]]<-val
    prs<-strsplit(SENS$processes[i],';',fixed=TRUE)[[1]]; design<-SENS$design[i]
    lab<-paste(SENS$analysis_id[i],level,sep='__')
    for(pr in prs) for(run in seq_len(nr)) {
      if(design=='INTER') {
        z<-run_one_scenario(pr,SENS$info_regime[i],run,design='SENS_INTER',condition_scenario='EMPIRICAL')
        sk<-sk+1L; sens_rows[[sk]]<-key_signature(z$panel,pr,SENS$info_regime[i],run,lab,'INTER')
      } else {
        sk<-sk+1L; sens_rows[[sk]]<-cf_signature(pr,SENS$info_regime[i],run,lab)
      }
    }
  }
  SENS_BY_RUN<-rbind_fill(sens_rows)
  SENS_MC<-mc_summary(SENS_BY_RUN,c('label','design','process','info_regime','metric','signature'))
  write.csv(SENS_BY_RUN,file.path('results','publication','sensitivity_by_run.csv'),row.names=FALSE,na='')
  write.csv(SENS_MC,file.path('results','publication','Table_SENSITIVITY.csv'),row.names=FALSE,na='')

  # Ablations.
  ABL<-read.csv(file.path('config','ablation_plan.csv'),stringsAsFactors=FALSE,check.names=FALSE)
  abl_rows<-list(); ak<-0L; nr<-cfg_int('ablation_runs')
  for(i in seq_len(nrow(ABL))) {
    cat('  - ablation ',ABL$ablation_id[i],'\n',sep='')
    RUNTIME_CFG_OVERRIDE<-list(); RUNTIME_RI_OVERRIDE<-list(); RUNTIME_DEB_OVERRIDE<-list(); RUNTIME_ABLATION<-ABL$ablation_id[i]
    prs<-strsplit(ABL$processes[i],';',fixed=TRUE)[[1]]; design<-ABL$design[i]
    for(pr in prs) for(run in seq_len(nr)) {
      if(design=='INTER') {
        z<-run_one_scenario(pr,ABL$info_regime[i],run,design='ABL_INTER',condition_scenario='EMPIRICAL')
        ak<-ak+1L; abl_rows[[ak]]<-key_signature(z$panel,pr,ABL$info_regime[i],run,ABL$ablation_id[i],'INTER')
      } else {
        ak<-ak+1L; abl_rows[[ak]]<-cf_signature(pr,ABL$info_regime[i],run,ABL$ablation_id[i])
      }
    }
  }
  ABL_BY_RUN<-rbind_fill(abl_rows); ABL_MC<-mc_summary(ABL_BY_RUN,c('label','design','process','info_regime','metric','signature'))
  write.csv(ABL_BY_RUN,file.path('results','publication','ablation_by_run.csv'),row.names=FALSE,na='')
  write.csv(ABL_MC,file.path('results','publication','Table_ABLATIONS.csv'),row.names=FALSE,na='')

  # Robustness: partner rotation/fixed and empirical sizes vs legacy all-4.
  ROB<-read.csv(file.path('config','robustness_plan.csv'),stringsAsFactors=FALSE,check.names=FALSE)
  rob_rows<-list(); rk<-0L; nr<-cfg_int('robustness_runs')
  for(i in seq_len(nrow(ROB))) {
    cat('  - robustness ',ROB$robustness_id[i],'\n',sep='')
    RUNTIME_CFG_OVERRIDE<-list(debate_partner_mode=ROB$partner_mode[i],group_size_mode=ROB$group_size_mode[i]); RUNTIME_RI_OVERRIDE<-list(); RUNTIME_DEB_OVERRIDE<-list(); RUNTIME_ABLATION<-'FULL'
    for(pr in c('DEBATE','COUPLED')) for(run in seq_len(nr)) {
      z<-run_one_scenario(pr,'RENEWED',run,design='ROB_INTER',condition_scenario='EMPIRICAL')
      rk<-rk+1L; rob_rows[[rk]]<-key_signature(z$panel,pr,'RENEWED',run,ROB$robustness_id[i],'INTER')
      rk<-rk+1L; rob_rows[[rk]]<-cf_signature(pr,'RENEWED',run,ROB$robustness_id[i])
    }
  }
  ROB_BY_RUN<-rbind_fill(rob_rows); ROB_MC<-mc_summary(ROB_BY_RUN,c('label','design','process','info_regime','metric','signature'))
  write.csv(ROB_BY_RUN,file.path('results','publication','robustness_by_run.csv'),row.names=FALSE,na='')
  write.csv(ROB_MC,file.path('results','publication','Table_ROBUSTNESS_PARTNERS_GROUPSIZE.csv'),row.names=FALSE,na='')
  RUNTIME_CFG_OVERRIDE<-list(); RUNTIME_RI_OVERRIDE<-list(); RUNTIME_DEB_OVERRIDE<-list(); RUNTIME_ABLATION<-'FULL'
}

# Session information for reproducibility.
writeLines(capture.output(sessionInfo()),file.path('results','publication','SESSION_INFO.txt'))

cat('\nDONE: MOVICI-CAVL SMA JASSS / OSF RELEASE V3.4 pipeline completed.\n')
