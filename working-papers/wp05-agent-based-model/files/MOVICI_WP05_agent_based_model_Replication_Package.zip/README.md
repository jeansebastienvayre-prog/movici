# MOVICI Article 4 reproducibility package

## Article

**Misallocation of Epistemic Credit in Socially Embedded Learning: An Empirically Anchored Agent-Based Model of Information Search and Debate**

Preprint not peer reviewed. Target journal: *Journal of Artificial Societies and Social Simulation (JASSS)*.

This package contains the final V3.4 article-specific agent-based model, minimized pseudonymized input data, model documentation, frozen parameters, and the deposited STANDARD simulation outputs used in the manuscript.

## Data scope and privacy

`data/article/MOVICI_SMA_ARTICLE_DATA.csv` contains 96 pseudonymized participant rows and only variables required to initialize, calibrate, or check the model.

`data/article/MOVICI_SMA_DYADS.csv` contains 212 directed evaluator→partner observations used for dyadic source-evaluation calibration and the empirical `ExpertiseAllocationGain` check.

Names, email addresses, raw transcripts, free-text responses, raw URLs, workstation identifiers, exact dates/times, and other direct identifiers are omitted. Public identifiers are pseudonymous study identifiers. See `DATA_AUDIT.txt` and `data/article/README.md`.

## Contents

- `MOVICI_Article4_OSF.Rproj`: RStudio project.
- `RUN_FAST.R`: technical verification launcher; FAST estimates must not be reported as publication results.
- `RUN_STANDARD.R`: publication launcher.
- `R/SMA_JASSS_PIPELINE.R`: consolidated simulation and analysis pipeline.
- `config/`: frozen model parameters, scenario registry, ablation, robustness, and sensitivity plans.
- `data/article/`: minimized pseudonymized article datasets.
- `docs/ODD_ODD+D.md`: full model description using ODD/ODD+D.
- `docs/VARIABLE_DICTIONARY.csv` and `docs/OUTPUT_DICTIONARY.csv`: variable/output dictionaries.
- `docs/MODEL_DIAGRAM.png` and `.svg`: model diagram.
- `docs/REPRODUCIBILITY.md`: detailed reproduction notes.
- `results/`: final V3.4 STANDARD outputs archived with the package.
- `results/publication/SESSION_INFO.txt`: R session information from the final STANDARD run.
- `DATA_AUDIT.txt`: data-minimization and privacy summary.
- `CHANGELOG.md` and `VERSION.txt`: release history and version status.
- `SHA256SUMS.txt`: integrity hashes for package files.
- `LICENSE_DATA_CC_BY_4.0.txt`: data/documentation license.
- `LICENSE_CODE_MIT.txt`: code license.

## Reproduction

1. Open `MOVICI_Article4_OSF.Rproj` in RStudio.
2. Run the technical verification first:

```r
source("RUN_FAST.R")
```

3. For the publication simulation and result tables:

```r
source("RUN_STANDARD.R")
```

`RUN_STANDARD.R` executes 30 Monte Carlo runs for RI / DEBATE / COUPLED × FIXED / RENEWED and 30 paired same-agent COOP-vs-COMP counterfactual runs for RENEWED DEBATE and COUPLED. Targeted sensitivity, ablation, and robustness extensions use five runs per variant to keep the package computationally tractable.

The core simulation uses base R. `clubSandwich` is used only for the complementary empirical CR2/Satterthwaite `ExpertiseAllocationGain` check when available.

## Empirical anchoring and longitudinal simulation

Episode 1 is an empirical anchoring step on the original 20 MOVICI factual items. From episode 2 onward, FIXED and RENEWED search use the same limited-exposure engine. The regimes differ because RENEWED introduces new information over time; the 0.80 encounter-reliability setting is a scenario assumption, not an empirical estimate of Web reliability.

The manuscript distinguishes values used in calibration from structural checks that were not used as independent validation targets.

## Interpretation notes

- MOVICI did not strictly randomize the human COOP/COMP condition. Human condition differences are therefore observational constraints, not randomized causal estimates.
- Causal language is reserved for interventions inside the simulation, especially the same-agent counterfactual and explicit ablations.
- Simulation replications are never treated as additional human participants. Monte Carlo quantiles describe variability across simulated worlds, not confidence intervals for a human population.
- In RENEWED scenarios, report `KnowledgeStock` together with `KnowledgeDensity`.
- For standalone RENEWED DEBATE, `CumulativeLearningBalance` is the endogenous learning measure because raw stock also includes exogenously seeded information required to maintain an expanding social-information environment.
- `EpistemicCreditMisallocationIndex` is intentionally directional: it captures underuse of available corrective expertise. Over-crediting of less knowledgeable partners is reported separately as a calibration/receptivity diagnostic.
- The operational index is **epistemic credit misallocation**. The present model does not directly operationalize identity-based epistemic injustice.
- The Article 4 analysis was not preregistered; the model is theory-guided and empirically anchored.

## Final archived results

The `results/` directory contains the final V3.4 STANDARD outputs used to revise the manuscript, including:

- `results/publication/Table_CALIBRATION_VALIDATION_STEP1.csv`
- `results/publication/Table_EMPIRICAL_EXPERTISE_ALLOCATION_CHECK.csv`
- `results/publication/MC_CONVERGENCE.csv`
- `results/publication/Table_SENSITIVITY.csv`
- `results/publication/Table_ABLATIONS.csv`
- `results/publication/Table_ROBUSTNESS_PARTNERS_GROUPSIZE.csv`
- `results/statistics/Table_MAIN_SES_stock_density_RENEWED.csv`
- `results/statistics/Table_MAIN_social_receptivity_diagnostics.csv`
- `results/publication/SESSION_INFO.txt`

## Licenses

Data and documentation: CC BY 4.0. R code: MIT License.

## Citation metadata

Add the final author list and permanent OSF DOI/URL when fixed. Do not replace those fields with provisional information.
