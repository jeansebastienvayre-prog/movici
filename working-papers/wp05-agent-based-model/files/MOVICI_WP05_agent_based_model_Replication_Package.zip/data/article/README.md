# Minimal article data

This folder contains only variables required to initialize, calibrate, or check the MOVICI–CAVL SMA used in the JASSS article.

## `MOVICI_SMA_ARTICLE_DATA.csv`
96 pseudonymous participant rows: condition and debate size; SES components; RI source-evaluation/navigation variables; subjective-knowledge measures; debate source profiles; 20 factual items at T1/T2/T3; and canonical global factual scores `K_GLOBAL_T1/T2/T3`.

## `MOVICI_SMA_DYADS.csv`
Directed evaluator→partner observations used for source-recognition/benevolence calibration and the empirical `ExpertiseAllocationGain` mechanism check.

No names, email addresses, free-text transcripts, or direct identifiers are included. `ID_MOVICI` is a pseudonymous study identifier.
