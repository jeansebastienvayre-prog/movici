# MOVICI-CAVL SMA — JASSS / OSF V3.4 — MINIMAL PUBLICATION RUN
# -----------------------------------------------------------------------------
# Main INTER SMA: 30 runs for RI / DEBATE / COUPLED × FIXED / RENEWED.
# Controlled same-agent COOP vs COMP counterfactual: 30 runs, RENEWED only,
# for DEBATE and COUPLED with rotating partners and empirical group sizes.
# No total-effect proxy and no frozen historical control in the primary run.
# Publication extensions are deliberately lean: 3 targeted sensitivities,
# 4 mechanistic ablations, and 2 social-design robustness checks. Extension
# variants use 5 runs by default; selectively increase a variant only if its
# qualitative result is unstable. MC convergence: 10 / 20 / 30 main runs.
# -----------------------------------------------------------------------------

N_RUNS_OVERRIDE <- 30L
N_CF_RUNS_OVERRIDE <- 30L
CF_INFO_REGIMES_OVERRIDE <- "RENEWED"
N_TOTAL_CF_RUNS_OVERRIDE <- 0L
RUN_COUNTERFACTUAL_OVERRIDE <- TRUE
RUN_TOTAL_CF_OVERRIDE <- FALSE
RUN_PUBLICATION_EXTENSIONS_OVERRIDE <- TRUE
INCLUDE_FROZEN_OVERRIDE <- FALSE
AGENT_EXPORT_RUNS_OVERRIDE <- 2L
DYAD_EXPORT_RUNS_OVERRIDE <- 0L

source(file.path("R", "SMA_JASSS_PIPELINE.R"))
