# CHANGELOG

## V3.4 FINAL — 2026-09-28 — Article 4 OSF deposit package
No model equation, empirical coefficient, random seed, or reported V3.4 STANDARD result was changed in this finalization step.

- Archived the final V3.4 STANDARD outputs used in the manuscript.
- Harmonized file naming with the MOVICI Article 1–3 reproducibility packages.
- Added Article 4 code/data licenses, a root data audit, and `SHA256SUMS.txt`.
- Updated deposit documentation from release-candidate status to final article-specific deposit status.

## V3.4 — 2026-09-27 — JASSS-audit / OSF release candidate
Core empirical coefficient values are unchanged from V3.3.

- Harmonized longitudinal RI after step 1: FIXED and RENEWED now use the same limited-exposure engine from step 2 onward.
- Retained the full-pool step-1 RI transition as the empirical MOVICI anchor.
- Added `WeightLessExpert`, `OverweightLessExpertRate`, and `LessExpertEncounterCount` to distinguish general social receptivity from source-specific allocation.
- Kept `EpistemicCreditMisallocationIndex` intentionally directional; over-credit remains a separate calibration/receptivity diagnostic.
- Added `NO_DIFFERENTIAL_CREDIT_ALLOCATION`, which equalizes current partner weights while preserving each evaluator's mean pre-ablation receptivity.
- Added dedicated stock-versus-density SES and social-receptivity publication tables.
- Added targeted `alpha_B` sensitivity (`0 / 0.169 / 0.338`).
- Reduced complementary sensitivity/ablation/robustness variants to 5 runs by default; main and controlled counterfactual estimands remain at 30 runs.
- Added automated checks for longitudinal RI exposure budgets and the directional misallocation-index identity.
- Clarified that Monte-Carlo intervals describe simulated-world variability, not human-population uncertainty.
- Rewrote ODD, reproducibility notes, release checklist, and OSF deposit notes to match V3.4 exactly.


## V3.3 — 2026-09-24 — OSF release candidate
No substantive model retuning.

- Canonical empirical factual targets now use `K_GLOBAL_T1/T2/T3`.
- Updated precomputed RI raw-SES and COOP step-1 coefficients from the deposited article dataset.
- Added `MeanBenevolenceSignal` to inter-subject metrics.
- Added reproducible empirical `ExpertiseAllocationGain` analysis.
- Removed legacy operational aliases `EpistemicInjusticeIndex` / `EpistemicJusticeIndex`.
- Harmonized public terminology around `EpistemicCreditMisallocationIndex`.
- Corrected ODD sensitivity/ablation documentation.
- Rewrote OSF/JASSS release checklist and reproducibility notes.
- Added minimal-data documentation and SHA-256 manifest workflow.

## V3.2 — 2026-09-24
First minimal JASSS publication run: 30 main Monte-Carlo runs, 30 controlled same-agent counterfactual runs, targeted convergence/sensitivity/ablation/robustness suite.

### Pre-release FAST validation patch — 2026-09-27
- Added `CumulativeLearningLosses` and `CumulativeLearningBalance` to the controlled same-agent counterfactual export. These variables were already computed by the simulation engine but were inadvertently omitted from the reduced counterfactual panel used for publication tables.
- Added regression checks verifying that counterfactual acquisition, loss, and balance counters are exported and satisfy `balance = acquisitions - losses`.
- No model equation, parameter, random seed, empirical target, or primary scenario was changed by this patch.
