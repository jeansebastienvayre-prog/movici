# MOVICI Article 2 reproducibility package

## Article

**Epistemic Credit in Cooperative and Competitive Debate**

Preprint not peer reviewed.

This package reproduces the article analyses from two minimized analytic datasets: one participant-level table and one ordered evaluator-to-evaluatee dyad table.

## Data scope and privacy

The participant table contains 96 pseudonymized participants in 34 pseudonymized debate clusters. The dyad table contains 212 ordered ratings involving 91 evaluators across 29 debates.

Every released variable is required by the main analyses, a reported secondary analysis, a robustness check, or a supplement referenced in the manuscript. Exact dates and times, workstation identifiers, demographics, raw transcripts, free-text responses, questionnaire trait scores unrelated to the article, and other MOVICI variables are omitted. Public identifiers have no mapping to the internal identifiers and differ from those used in the Article 1 package.

`Competition` and `Cooperation` refer only to the experimental social-interdependence condition.

## Contents

- `MOVICI_Debat_OSF.Rproj`: RStudio project.
- `MOVICI_Debat_Analysis.R`: analysis script.
- `data/MOVICI_Debat_Participant_Data.csv`: participant-level analytic dataset.
- `data/MOVICI_Debat_Dyad_Data.csv`: ordered dyad analytic dataset.
- `documentation/MOVICI_Debat_Data_Dictionary.xlsx`: variable dictionary and analysis map.
- `materials/MOVICI_Debat_Measures_and_Coding.xlsx`: measures, scoring provenance, coding rules, and reliability audit.
- `results/MOVICI_Debat_Core_Results.xlsx`: all non-bootstrap results.
- `results/MOVICI_Debat_Check_Results.xlsx`: complete manuscript-facing results, including the retained exploratory indirect path.
- `results/README.txt`: output instructions.
- `DATA_AUDIT.txt`: data-minimization and integrity summary.
- `SHA256SUMS.txt`: integrity hashes.
- `LICENSE_DATA_CC_BY_4.0.txt`: data and documentation license.
- `LICENSE_CODE_MIT.txt`: code license.

## Reproduction

1. Open `MOVICI_Debat_OSF.Rproj` in RStudio.
2. Source `MOVICI_Debat_Analysis.R` with the distributed settings:

```r
RUN_MODE <- "CHECK"
RUN_PRIMARY_MEDIATION <- TRUE
RUN_SUPPLEMENTARY_MEDIATIONS <- FALSE
```

The script first writes `results/MOVICI_Debat_Core_Results.xlsx`, then runs the retained 500-resample debate-cluster bootstrap and writes `results/MOVICI_Debat_Check_Results.xlsx`.

The script requires `clubSandwich` and `openxlsx`.

## Interpretation notes

- T3 objective knowledge is measured after the full debate → partner evaluation → argument recall/evaluation sequence and is the primary endpoint/anchor for post-debate partner ratings. T2→T3 must not be interpreted as a causal estimate of the 20-minute debate alone.
- Under-credit and calibration indices compare standardized relative standing; they are not direct normative measures of deserved credit.
- The indirect path is exploratory and does not establish causal mediation.
- The study was not preregistered.

## Licenses

Data and documentation: CC BY 4.0. R code: MIT License.
