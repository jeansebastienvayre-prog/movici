MOVICI Article 2 results

MOVICI_Debat_Core_Results.xlsx contains all non-bootstrap analyses.

MOVICI_Debat_Check_Results.xlsx contains the same analyses plus the retained exploratory condition to benevolence to partner under-credit path based on 500 debate-cluster bootstrap resamples. This is the manuscript-facing complete workbook.

Running MOVICI_Debat_Analysis.R with the distributed CHECK settings recreates both workbooks and writes sessionInfo_CHECK.txt. The script stops before inference if its structural, linkage, missingness, or coding checks fail.
