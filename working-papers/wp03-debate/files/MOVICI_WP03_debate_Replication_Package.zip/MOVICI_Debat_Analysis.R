# ==============================================================================
# MOVICI — DEBATE ARTICLE
# Reproducible analysis pipeline for the article-specific OSF package
# ==============================================================================
# Public data:
#   data/MOVICI_Debat_Participant_Data.csv
#   data/MOVICI_Debat_Dyad_Data.csv
#
# Main theory-guided analyses:
#   H1  No substantial positive factual gain after debate (CR2 estimate + one-sided upper bound + threshold sensitivity)
#   H2a Epistemic under-credit of interaction partners by condition
#   H2b Self-miscalibration by condition (absolute discrepancy primary; signed overcredit secondary)
#   H3  Objective expertise × condition predicting subjective self-expertise at T3
#
# Secondary analyses:
#   - Discrimination of partners' actual expertise
#   - Does the evaluator's own objective expertise improve discrimination/accuracy of partner expertise?
#   - Condition effects on perceived expertise, benevolence, argument evaluation
#
# Exploratory / supplementary analyses:
#   - Statistical indirect paths through perceived benevolence
#   - Attack rate
#   - Questions, doubt, polarization
#   - Conversational visibility as an expertise cue
#   - Epistemic rank reversal
#
# Robust inference uses CR2 standard errors clustered by debate, with
# Satterthwaite degrees of freedom. The package contains only article-relevant,
# pseudonymized variables.
# ============================================================================== 

rm(list = ls())
options(stringsAsFactors = FALSE, scipen = 999)
set.seed(20260910)
SCRIPT_VERSION <- "OSF_PREPRINT_FINAL_2026-09-13"

# Run mode ---------------------------------------------------------------------
# CHECK is the distributed default and reproduces the manuscript-facing outputs.
# FINAL uses the same analysis settings and bootstrap size, but writes FINAL-named output files for archival use.
RUN_MODE <- "CHECK"  # allowed: "FINAL", "CHECK"
if (!RUN_MODE %in% c("FINAL", "CHECK")) stop("RUN_MODE must be 'FINAL' or 'CHECK'.")

# Bootstrap settings ------------------------------------------------------------
# The manuscript-facing indirect path is condition -> benevolence -> under-credit.
# The two other benevolence paths are supplementary and are OFF by default.
# The retained exploratory indirect path uses 500 debate-cluster bootstrap resamples,
# as reported in the manuscript. CHECK and FINAL use the same bootstrap size.
RUN_PRIMARY_MEDIATION <- TRUE
RUN_SUPPLEMENTARY_MEDIATIONS <- FALSE
BOOT_REPS_PRIMARY <- 500L
BOOT_REPS_SUPPLEMENTARY <- 500L
BOOT_SEED <- 20260910L

# H1 estimation and gain-threshold sensitivity --------------------------------
# No single post-hoc substantive threshold is treated as the unique decision rule. The main
# H1 output is the CR2 estimate of T3-T2 change plus its one-sided 95% upper
# confidence bound. A transparent sensitivity grid then tests several candidate
# positive-gain thresholds on the raw 0-20 scale.
H1_GAIN_THRESHOLDS <- c(0.10, 0.25, 0.50, 1.00)
ALPHA <- 0.05

# 1. Dependencies and paths ----------------------------------------------------
required_packages <- c("clubSandwich", "openxlsx")
options(repos = c(CRAN = "https://cloud.r-project.org"))
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]
if (length(missing_packages) > 0L) install.packages(missing_packages)
invisible(lapply(required_packages, library, character.only = TRUE))

PROJECT_ROOT <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
PARTICIPANT_FILE <- file.path(PROJECT_ROOT, "data", "MOVICI_Debat_Participant_Data.csv")
DYAD_FILE <- file.path(PROJECT_ROOT, "data", "MOVICI_Debat_Dyad_Data.csv")
OUT_DIR <- file.path(PROJECT_ROOT, "results")
dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)
CORE_RESULTS_FILE <- file.path(OUT_DIR, "MOVICI_Debat_Core_Results.xlsx")
RESULTS_FILE <- file.path(
  OUT_DIR,
  if (RUN_MODE == "FINAL") "MOVICI_Debat_Final_Results.xlsx" else "MOVICI_Debat_Check_Results.xlsx"
)
SESSION_FILE <- file.path(
  OUT_DIR,
  if (RUN_MODE == "FINAL") "sessionInfo_FINAL.txt" else "sessionInfo_CHECK.txt"
)

if (!file.exists(PARTICIPANT_FILE)) stop("Participant data file not found: ", PARTICIPANT_FILE,
                                         "\nOpen MOVICI_Debat_OSF.Rproj before sourcing this script.")
if (!file.exists(DYAD_FILE)) stop("Dyad data file not found: ", DYAD_FILE,
                                  "\nOpen MOVICI_Debat_OSF.Rproj before sourcing this script.")

cat("\nMOVICI Debate — article-specific reproducible analysis\n")
cat("Script version:", SCRIPT_VERSION, "\n")
cat("Run mode:", RUN_MODE, "\n")
cat("H1 positive-gain sensitivity thresholds: ", paste(H1_GAIN_THRESHOLDS, collapse = ", "), " factual-knowledge points\n", sep = "")
cat("Primary mediation bootstrap:", RUN_PRIMARY_MEDIATION,
    " (", BOOT_REPS_PRIMARY, " resamples)\n", sep = "")
cat("Supplementary mediation bootstraps:", RUN_SUPPLEMENTARY_MEDIATIONS,
    " (", BOOT_REPS_SUPPLEMENTARY, " resamples/path)\n", sep = "")

# 2. Helper functions ----------------------------------------------------------
num <- function(x) suppressWarnings(as.numeric(x))

z <- function(x) {
  x <- as.numeric(x)
  m <- mean(x, na.rm = TRUE)
  s <- sd(x, na.rm = TRUE)
  if (!is.finite(s) || s == 0) return(rep(NA_real_, length(x)))
  (x - m) / s
}

pct_rank <- function(x) {
  x <- as.numeric(x)
  out <- rep(NA_real_, length(x))
  ok <- is.finite(x)
  if (!any(ok)) return(out)
  n <- sum(ok)
  out[ok] <- (rank(x[ok], ties.method = "average") - 0.5) / n
  out
}

assert_qc <- function(condition, message) {
  if (!isTRUE(condition)) stop("QC failure: ", message, call. = FALSE)
}

safe_mean <- function(x) {
  x <- as.numeric(x)
  if (!any(is.finite(x))) return(NA_real_)
  mean(x, na.rm = TRUE)
}

bind_fill <- function(...) {
  dfs <- list(...)
  dfs <- dfs[vapply(dfs, function(x) !is.null(x) && nrow(as.data.frame(x)) > 0L, logical(1))]
  if (!length(dfs)) return(data.frame())
  dfs <- lapply(dfs, function(x) as.data.frame(x, check.names = FALSE, stringsAsFactors = FALSE))
  all_names <- unique(unlist(lapply(dfs, names), use.names = FALSE))
  dfs <- lapply(dfs, function(d) {
    miss <- setdiff(all_names, names(d))
    for (m in miss) d[[m]] <- NA
    d[, all_names, drop = FALSE]
  })
  ans <- do.call(rbind, dfs)
  rownames(ans) <- NULL
  ans
}

add_terms <- function(x, model) {
  x <- as.data.frame(x, check.names = FALSE)
  if ("Coef." %in% names(x)) names(x)[names(x) == "Coef."] <- "term"
  if ("Coef" %in% names(x)) names(x)[names(x) == "Coef"] <- "term"
  if (!"term" %in% names(x)) {
    x <- data.frame(term = names(coef(model)), x, check.names = FALSE, row.names = NULL)
  }
  x
}

cr2_analysis <- function(model, data, cluster_col = "debate_id", label = "") {
  cl <- data[[cluster_col]]
  if (any(is.na(cl))) stop("Missing cluster IDs in analysis: ", label)
  V <- clubSandwich::vcovCR(model, cluster = cl, type = "CR2")
  tests <- add_terms(clubSandwich::coef_test(model, vcov = V, test = "Satterthwaite"), model)
  if (all(c("beta", "SE", "df_Satt") %in% names(tests))) {
    crit <- qt(0.975, df = tests$df_Satt)
    tests$CI_low <- tests$beta - crit * tests$SE
    tests$CI_high <- tests$beta + crit * tests$SE
  } else {
    tests$CI_low <- NA_real_
    tests$CI_high <- NA_real_
  }
  tests$model <- label
  tests$N <- nobs(model)
  tests$clusters <- length(unique(cl))
  list(V = V, tests = tests, model = model)
}

extract_term <- function(cr2_obj, term) {
  cr2_obj$tests[cr2_obj$tests$term == term, , drop = FALSE]
}

model_fit <- function(model, label) {
  s <- summary(model)
  data.frame(
    analysis = label,
    N = nobs(model),
    R2 = s$r.squared,
    adjusted_R2 = s$adj.r.squared,
    AIC = AIC(model),
    BIC = BIC(model),
    stringsAsFactors = FALSE
  )
}

describe <- function(x, label, group = "All") {
  x <- as.numeric(x)
  ok <- is.finite(x)
  if (!any(ok)) return(data.frame(variable = label, group = group, N = 0L,
                                  mean = NA, SD = NA, median = NA, min = NA, max = NA))
  data.frame(
    variable = label, group = group, N = sum(ok),
    mean = mean(x[ok]), SD = sd(x[ok]), median = median(x[ok]),
    min = min(x[ok]), max = max(x[ok]), stringsAsFactors = FALSE
  )
}

describe_by_condition <- function(data, variable, label = variable) {
  out <- describe(data[[variable]], label, "All")
  for (g in levels(data$condition)) {
    out <- rbind(out, describe(data[data$condition == g, variable], label, g))
  }
  out
}

condition_term <- "conditionCooperation"

make_model_row <- function(obj, term, analysis, status) {
  x <- extract_term(obj, term)
  if (!nrow(x)) return(data.frame())
  x$analysis <- analysis
  x$status <- status
  x
}

cluster_h1_estimate <- function(change, debate_id, alpha = 0.05) {
  d <- data.frame(change = as.numeric(change), debate_id = debate_id)
  d <- d[complete.cases(d), , drop = FALSE]
  m <- lm(change ~ 1, data = d)
  fit <- cr2_analysis(m, d, "debate_id", "H1 CR2 estimate of T3-T2 factual change")
  tt <- extract_term(fit, "(Intercept)")
  if (!all(c("beta", "SE", "df_Satt") %in% names(tt))) {
    stop("Unexpected clubSandwich coefficient-test columns for H1 estimate.")
  }
  est <- tt$beta[1]
  se <- tt$SE[1]
  df <- tt$df_Satt[1]
  crit_two <- qt(1 - alpha/2, df = df)
  crit_one <- qt(1 - alpha, df = df)
  data.frame(
    N = nrow(d), clusters = length(unique(d$debate_id)),
    mean_change = est, CR2_SE = se, df_Satt = df,
    CI95_low = est - crit_two * se,
    CI95_high = est + crit_two * se,
    one_sided_95pct_upper_bound = est + crit_one * se,
    interpretation = paste0(
      "Primary H1 estimation: CR2 mean T3-T2 change and one-sided 95% upper bound. ",
      "No unique post-hoc substantive threshold is treated as the decision rule."
    ),
    stringsAsFactors = FALSE
  )
}

cluster_gain_sensitivity <- function(change, debate_id, thresholds, alpha = 0.05) {
  d <- data.frame(change = as.numeric(change), debate_id = debate_id)
  d <- d[complete.cases(d), , drop = FALSE]
  m <- lm(change ~ 1, data = d)
  fit <- cr2_analysis(m, d, "debate_id", "H1 positive-gain threshold sensitivity")
  tt <- extract_term(fit, "(Intercept)")
  if (!all(c("beta", "SE", "df_Satt") %in% names(tt))) {
    stop("Unexpected clubSandwich coefficient-test columns for H1 sensitivity.")
  }
  est <- tt$beta[1]
  se <- tt$SE[1]
  df <- tt$df_Satt[1]
  do.call(rbind, lapply(as.numeric(thresholds), function(bound) {
    t_stat <- (est - bound) / se
    p_one_sided <- pt(t_stat, df = df) # H0: mean change >= bound
    data.frame(
      N = nrow(d), clusters = length(unique(d$debate_id)),
      mean_change = est, CR2_SE = se, df_Satt = df,
      candidate_positive_gain_points = bound,
      t_vs_candidate_gain = t_stat,
      p_one_sided = p_one_sided,
      candidate_gain_ruled_out_at_alpha_05 = (p_one_sided < alpha),
      interpretation = paste0("Sensitivity test: H0 mean change >= +", bound,
                              "; H1 mean change < +", bound, "."),
      stringsAsFactors = FALSE
    )
  }))
}

aggregate_evaluator <- function(dyad_data) {
  ids <- unique(dyad_data$evaluator_id)
  rows <- lapply(ids, function(id) {
    x <- dyad_data[dyad_data$evaluator_id == id, , drop = FALSE]
    data.frame(
      evaluator_id = id,
      debate_id = x$debate_id[1],
      condition = x$condition[1],
      n_partners_rated = nrow(x),
      mean_perceived_expertise = safe_mean(x$perceived_expertise),
      mean_perceived_benevolence = safe_mean(x$perceived_benevolence),
      mean_argument_evaluation = safe_mean(x$mean_argument_evaluation),
      mean_partner_undercredit_t3 = safe_mean(x$partner_undercredit_t3),
      mean_partner_undercredit_pct_t3 = safe_mean(x$partner_undercredit_pct_t3),
      mean_partner_undercredit_t2 = safe_mean(x$partner_undercredit_t2),
      mean_partner_calibration_abs_t3 = safe_mean(x$partner_calibration_abs_t3),
      mean_partner_calibration_abs_pct_t3 = safe_mean(x$partner_calibration_abs_pct_t3),
      mean_partner_calibration_abs_t2 = safe_mean(x$partner_calibration_abs_t2),
      mean_partner_zknowledge_t3 = safe_mean(x$evaluatee_zknowledge_t3),
      mean_partner_zknowledge_t2 = safe_mean(x$evaluatee_zknowledge_t2),
      mean_partner_zperceived_expertise = safe_mean(x$z_perceived_expertise),
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

cluster_boot_indirect <- function(data, mediator, outcome, reps, seed, label, progress = TRUE) {
  vars <- c("debate_id", "condition", mediator, outcome)
  d <- data[complete.cases(data[, vars]), vars, drop = FALSE]
  d$condition <- factor(d$condition, levels = c("Competition", "Cooperation"))
  d$coop <- as.integer(d$condition == "Cooperation")
  clusters <- unique(d$debate_id)
  if (length(clusters) < 5L) stop("Too few clusters for bootstrap: ", label)

  # Original-sample coefficients.
  ma <- lm.fit(x = cbind("(Intercept)" = 1, conditionCooperation = d$coop), y = d[[mediator]])
  mb <- lm.fit(x = cbind("(Intercept)" = 1, conditionCooperation = d$coop,
                         mediator_value = d[[mediator]]), y = d[[outcome]])
  a <- unname(ma$coefficients[2])
  b <- unname(mb$coefficients[3])
  indirect <- a * b

  # Pre-split once by debate. This is substantially faster than subsetting and
  # rebuilding formula models from scratch at every bootstrap iteration.
  cluster_rows <- split(seq_len(nrow(d)), d$debate_id)
  set.seed(seed)
  boot_ab <- rep(NA_real_, reps)
  tick <- max(1L, floor(reps / 20L))
  t0 <- proc.time()[3]
  if (progress) cat("\nBootstrap:", label, "—", reps, "debate-cluster resamples\n")

  for (r in seq_len(reps)) {
    sampled_names <- sample(names(cluster_rows), length(cluster_rows), replace = TRUE)
    idx <- unlist(cluster_rows[sampled_names], use.names = FALSE)
    bd <- d[idx, , drop = FALSE]

    fa <- try(lm.fit(x = cbind(1, bd$coop), y = bd[[mediator]]), silent = TRUE)
    fb <- try(lm.fit(x = cbind(1, bd$coop, bd[[mediator]]), y = bd[[outcome]]), silent = TRUE)
    if (!inherits(fa, "try-error") && !inherits(fb, "try-error") &&
        length(fa$coefficients) >= 2L && length(fb$coefficients) >= 3L &&
        all(is.finite(c(fa$coefficients[2], fb$coefficients[3])))) {
      boot_ab[r] <- unname(fa$coefficients[2]) * unname(fb$coefficients[3])
    }

    if (progress && (r %% tick == 0L || r == reps)) {
      elapsed <- proc.time()[3] - t0
      pct <- round(100 * r / reps)
      cat(sprintf("  %3d%%  (%d/%d) — elapsed %.1f s\n", pct, r, reps, elapsed))
      flush.console()
    }
  }

  boot_ab <- boot_ab[is.finite(boot_ab)]
  if (!length(boot_ab)) stop("No valid bootstrap replications: ", label)
  ci <- quantile(boot_ab, c(.025, .975), na.rm = TRUE, names = FALSE)
  data.frame(
    analysis = label, N = nrow(d), clusters = length(clusters),
    a_condition_to_mediator = a, b_mediator_to_outcome = b,
    indirect_ab = indirect, boot_reps_requested = reps,
    boot_reps_valid = length(boot_ab), CI95_low = ci[1], CI95_high = ci[2],
    CI95_excludes_zero = (ci[1] > 0 || ci[2] < 0),
    interpretation = "Exploratory statistical indirect path; percentile cluster-bootstrap CI; not causal mediation.",
    stringsAsFactors = FALSE
  )
}


write_workbook <- function(path, sheets) {
  wb <- openxlsx::createWorkbook()
  header <- openxlsx::createStyle(
    fontColour = "#FFFFFF", fgFill = "#1F4E78", textDecoration = "bold",
    halign = "center", valign = "center", wrapText = TRUE
  )
  wrap <- openxlsx::createStyle(wrapText = TRUE, valign = "top")
  num_style <- openxlsx::createStyle(numFmt = "0.000")
  p_style <- openxlsx::createStyle(numFmt = "0.0000")

  for (nm in names(sheets)) {
    df <- as.data.frame(sheets[[nm]], check.names = FALSE, stringsAsFactors = FALSE)
    sh <- substr(nm, 1, 31)
    openxlsx::addWorksheet(wb, sh, gridLines = FALSE)
    if (ncol(df) == 0L) {
      openxlsx::writeData(wb, sh, "No output")
      next
    }
    if (nrow(df) == 0L) {
      openxlsx::writeData(wb, sh, as.list(names(df)), colNames = FALSE)
    } else {
      openxlsx::writeDataTable(wb, sh, df, tableStyle = "TableStyleMedium2", withFilter = TRUE)
    }
    openxlsx::addStyle(wb, sh, header, rows = 1, cols = seq_len(ncol(df)), gridExpand = TRUE)
    if (nrow(df) > 0L) {
      openxlsx::addStyle(wb, sh, wrap, rows = 2:(nrow(df)+1L), cols = seq_len(ncol(df)), gridExpand = TRUE, stack = TRUE)
      numeric_cols <- which(vapply(df, is.numeric, logical(1)))
      p_cols <- grep("(^p$|^q$|p_|p\\.|p_Satt|q_BH|CI95|CI90)", names(df), ignore.case = TRUE)
      if (length(numeric_cols)) openxlsx::addStyle(wb, sh, num_style,
          rows = 2:(nrow(df)+1L), cols = numeric_cols, gridExpand = TRUE, stack = TRUE)
      if (length(p_cols)) openxlsx::addStyle(wb, sh, p_style,
          rows = 2:(nrow(df)+1L), cols = p_cols, gridExpand = TRUE, stack = TRUE)
    }
    openxlsx::freezePane(wb, sh, firstActiveRow = 2)
    widths <- vapply(seq_len(ncol(df)), function(j) {
      vals <- c(names(df)[j], as.character(df[[j]]))
      vals <- vals[!is.na(vals)]
      mx <- if (length(vals)) max(nchar(vals)) else 10
      max(10, min(42, mx + 2))
    }, numeric(1))
    openxlsx::setColWidths(wb, sh, seq_len(ncol(df)), widths)
  }
  openxlsx::saveWorkbook(wb, path, overwrite = TRUE)
}

# 3. Import and automatic QC ---------------------------------------------------
p <- read.csv(PARTICIPANT_FILE, check.names = FALSE, na.strings = c("", "NA"), fileEncoding = "UTF-8")
d <- read.csv(DYAD_FILE, check.names = FALSE, na.strings = c("", "NA"), fileEncoding = "UTF-8")

participant_required <- c(
  "participant_id", "debate_id", "condition", "group_size",
  "knowledge_t2", "knowledge_t3", "subjective_knowledge_t2", "subjective_knowledge_t3",
  "debate_data_available", "debate_sequence_count", "debate_word_count",
  "debate_group_word_share", "argument_sequence_count", "question_n", "doubt_n",
  "attack_n", "support_n", "relation_mixed_neutral_n", "polarized_n", "moderated_n"
)
dyad_required <- c(
  "evaluator_id", "evaluatee_id", "debate_id", "condition", "group_size", "familiarity",
  "perceived_expertise", "perceived_benevolence", "mean_argument_evaluation"
)
miss_p <- setdiff(participant_required, names(p))
miss_d <- setdiff(dyad_required, names(d))
if (length(miss_p)) stop("Missing participant columns: ", paste(miss_p, collapse = ", "))
if (length(miss_d)) stop("Missing dyad columns: ", paste(miss_d, collapse = ", "))

# Strict package-identity checks. These values are fixed characteristics of the
# article-specific public release, not inferential assumptions.
assert_qc(nrow(p) == 96L, "participant table must contain exactly 96 rows")
assert_qc(!anyDuplicated(p$participant_id), "participant_id must be unique")
assert_qc(length(unique(p$debate_id)) == 34L, "participant table must contain 34 debate clusters")
assert_qc(sum(p$condition == "Competition", na.rm = TRUE) == 47L, "expected 47 Competition participants")
assert_qc(sum(p$condition == "Cooperation", na.rm = TRUE) == 49L, "expected 49 Cooperation participants")
assert_qc(sum(num(p$debate_data_available) == 1, na.rm = TRUE) == 85L, "expected 85 participants with verified debate coding")
assert_qc(nrow(d) == 212L, "dyad table must contain exactly 212 ordered dyads")
assert_qc(length(unique(d$evaluator_id)) == 91L, "expected 91 dyad evaluators")
assert_qc(length(unique(d$debate_id)) == 29L, "expected 29 dyad debate clusters")
assert_qc(!any(d$evaluator_id == d$evaluatee_id), "self-evaluations must not appear in the dyad table")
assert_qc(all(d$evaluator_id %in% p$participant_id), "some evaluator IDs are absent from participant data")
assert_qc(all(d$evaluatee_id %in% p$participant_id), "some evaluatee IDs are absent from participant data")

# Numeric conversion after structural checks.
numeric_p <- setdiff(participant_required, c("participant_id", "debate_id", "condition"))
for (v in numeric_p) p[[v]] <- num(p[[v]])
for (v in c("group_size", "familiarity", "perceived_expertise", "perceived_benevolence", "mean_argument_evaluation")) d[[v]] <- num(d[[v]])

p$condition <- factor(p$condition, levels = c("Competition", "Cooperation"))
d$condition <- factor(d$condition, levels = c("Competition", "Cooperation"))
assert_qc(!any(is.na(p$condition)), "unexpected participant condition labels")
assert_qc(!any(is.na(d$condition)), "unexpected dyad condition labels")

# Debate-level consistency in participant table.
by_debate_condition <- tapply(as.character(p$condition), p$debate_id, function(x) length(unique(x)))
by_debate_group <- tapply(p$group_size, p$debate_id, function(x) length(unique(x)))
assert_qc(all(by_debate_condition == 1L), "condition must be constant within each participant debate")
assert_qc(all(by_debate_group == 1L), "group_size must be constant within each participant debate")

# Debate coding completeness and internal arithmetic. Missing debate data remain
# NA; silent but covered participants legitimately have zero counts.
debate_count_vars <- c("debate_sequence_count", "debate_word_count", "debate_group_word_share",
                       "argument_sequence_count", "question_n", "doubt_n", "attack_n", "support_n",
                       "relation_mixed_neutral_n", "polarized_n", "moderated_n")
no_debate <- p$debate_data_available == 0
has_debate <- p$debate_data_available == 1
assert_qc(all(vapply(p[no_debate, debate_count_vars, drop = FALSE], function(x) all(is.na(x)), logical(1))),
          "all debate-derived values must be NA when debate_data_available = 0")
assert_qc(all(vapply(p[has_debate, debate_count_vars, drop = FALSE], function(x) all(!is.na(x)), logical(1))),
          "verified debate rows must contain all retained debate-derived values")
assert_qc(all(p$attack_n[has_debate] + p$support_n[has_debate] + p$relation_mixed_neutral_n[has_debate] ==
              p$argument_sequence_count[has_debate]),
          "Relation counts must sum exactly to argument_sequence_count")
assert_qc(all(p$polarized_n[has_debate] + p$moderated_n[has_debate] ==
              p$argument_sequence_count[has_debate]),
          "Polarization counts must sum exactly to argument_sequence_count")
assert_qc(all(p$question_n[has_debate] <= p$debate_sequence_count[has_debate]),
          "question_n cannot exceed debate_sequence_count")
assert_qc(all(p$doubt_n[has_debate] <= p$debate_sequence_count[has_debate]),
          "doubt_n cannot exceed debate_sequence_count")

# Dyad links must point to participants from the same public debate and condition.
p_debate_map <- setNames(p$debate_id, p$participant_id)
p_condition_map <- setNames(as.character(p$condition), p$participant_id)
p_group_map <- setNames(p$group_size, p$participant_id)
assert_qc(all(unname(p_debate_map[d$evaluator_id]) == d$debate_id), "evaluator debate_id mismatch")
assert_qc(all(unname(p_debate_map[d$evaluatee_id]) == d$debate_id), "evaluatee debate_id mismatch")
assert_qc(all(unname(p_condition_map[d$evaluator_id]) == as.character(d$condition)), "evaluator condition mismatch")
assert_qc(all(unname(p_condition_map[d$evaluatee_id]) == as.character(d$condition)), "evaluatee condition mismatch")
assert_qc(all(unname(p_group_map[d$evaluator_id]) == d$group_size), "evaluator group_size mismatch")
assert_qc(all(unname(p_group_map[d$evaluatee_id]) == d$group_size), "evaluatee group_size mismatch")
assert_qc(sum(is.na(d$perceived_expertise)) == 16L, "expected 16 missing perceived_expertise values")
assert_qc(sum(is.na(d$perceived_benevolence)) == 0L, "expected no missing perceived_benevolence values")
assert_qc(sum(is.na(d$mean_argument_evaluation)) == 20L, "expected 20 missing mean_argument_evaluation values")

# Merge evaluator/evaluatee knowledge and visibility into dyads.
eval_keep <- p[, c("participant_id", "knowledge_t2", "knowledge_t3", "subjective_knowledge_t3"), drop = FALSE]
names(eval_keep) <- c("evaluator_id", "evaluator_knowledge_t2", "evaluator_knowledge_t3", "evaluator_subjective_t3")
d <- merge(d, eval_keep, by = "evaluator_id", all.x = TRUE, sort = FALSE)

evalee_keep <- p[, c("participant_id", "knowledge_t2", "knowledge_t3", "debate_word_count", "debate_group_word_share"), drop = FALSE]
names(evalee_keep) <- c("evaluatee_id", "evaluatee_knowledge_t2", "evaluatee_knowledge_t3",
                        "evaluatee_debate_word_count", "evaluatee_debate_group_word_share")
d <- merge(d, evalee_keep, by = "evaluatee_id", all.x = TRUE, sort = FALSE)

# Derived participant variables. These are standardized relative-standing
# discrepancies, not probability-calibration scores.
p$knowledge_change <- p$knowledge_t3 - p$knowledge_t2
p$z_knowledge_t2 <- z(p$knowledge_t2)
p$z_knowledge_t3 <- z(p$knowledge_t3)
p$z_subjective_t2 <- z(p$subjective_knowledge_t2)
p$z_subjective_t3 <- z(p$subjective_knowledge_t3)
p$self_overcredit_t2 <- p$z_subjective_t2 - p$z_knowledge_t2
p$self_overcredit_t3 <- p$z_subjective_t3 - p$z_knowledge_t3
p$self_calibration_abs_t2 <- abs(p$self_overcredit_t2)
p$self_calibration_abs_t3 <- abs(p$self_overcredit_t3)

# Evaluator expertise for the new partner-recognition analysis is standardized
# once at participant level, then mapped into every ordered evaluator->evaluatee
# dyad. This avoids weighting participants with more rated partners more heavily
# when defining the evaluator-expertise scale.
z_t2_map <- setNames(p$z_knowledge_t2, p$participant_id)
z_t3_map <- setNames(p$z_knowledge_t3, p$participant_id)
d$evaluator_zknowledge_t2 <- unname(z_t2_map[d$evaluator_id])
d$evaluator_zknowledge_t3 <- unname(z_t3_map[d$evaluator_id])
assert_qc(sum(is.na(d$evaluator_zknowledge_t2)) == 0L,
          "all dyad evaluators must map to participant-level T2 expertise")
assert_qc(sum(is.na(d$evaluator_zknowledge_t3)) == 0L,
          "all dyad evaluators must map to participant-level T3 expertise")

p$attack_rate <- ifelse(p$argument_sequence_count > 0, p$attack_n / p$argument_sequence_count, NA_real_)
p$question_rate <- ifelse(p$debate_sequence_count > 0, p$question_n / p$debate_sequence_count, NA_real_)
p$doubt_rate <- ifelse(p$debate_sequence_count > 0, p$doubt_n / p$debate_sequence_count, NA_real_)
p$polarized_prop <- ifelse(p$argument_sequence_count > 0, p$polarized_n / p$argument_sequence_count, NA_real_)

# Dyad-standardized T3 under-credit proxy. Partner evaluation occurs after the
# debate, so T3 objective knowledge is the primary contemporaneous anchor. Both
# quantities are standardized within the exact complete dyad sample.
d$evaluatee_zknowledge_t3 <- NA_real_
d$z_perceived_expertise_t3sample <- NA_real_
ok_t3_credit <- complete.cases(d$evaluatee_knowledge_t3, d$perceived_expertise)
d$evaluatee_zknowledge_t3[ok_t3_credit] <- z(d$evaluatee_knowledge_t3[ok_t3_credit])
d$z_perceived_expertise_t3sample[ok_t3_credit] <- z(d$perceived_expertise[ok_t3_credit])
d$partner_undercredit_t3 <- d$evaluatee_zknowledge_t3 - d$z_perceived_expertise_t3sample
# Absolute discrepancy is a complementary quality/accuracy measure: lower values
# mean closer alignment between the partner's objective and perceived relative
# standing. It is not a probability-calibration score.
d$partner_calibration_abs_t3 <- abs(d$partner_undercredit_t3)

# Rank-based robustness version, less dependent on metric shape.
d$evaluatee_pctknowledge_t3 <- NA_real_
d$pct_perceived_expertise_t3sample <- NA_real_
d$evaluatee_pctknowledge_t3[ok_t3_credit] <- pct_rank(d$evaluatee_knowledge_t3[ok_t3_credit])
d$pct_perceived_expertise_t3sample[ok_t3_credit] <- pct_rank(d$perceived_expertise[ok_t3_credit])
d$partner_undercredit_pct_t3 <- d$evaluatee_pctknowledge_t3 - d$pct_perceived_expertise_t3sample
d$partner_calibration_abs_pct_t3 <- abs(d$partner_undercredit_pct_t3)

# T2 is retained only as a temporal sensitivity anchor: it represents knowledge
# entering the debate, whereas partner ratings themselves are post-debate.
d$evaluatee_zknowledge_t2 <- NA_real_
d$z_perceived_expertise_t2sample <- NA_real_
ok_t2_credit <- complete.cases(d$evaluatee_knowledge_t2, d$perceived_expertise)
d$evaluatee_zknowledge_t2[ok_t2_credit] <- z(d$evaluatee_knowledge_t2[ok_t2_credit])
d$z_perceived_expertise_t2sample[ok_t2_credit] <- z(d$perceived_expertise[ok_t2_credit])
d$partner_undercredit_t2 <- d$evaluatee_zknowledge_t2 - d$z_perceived_expertise_t2sample
d$partner_calibration_abs_t2 <- abs(d$partner_undercredit_t2)

# Generic perceived-expertise z-score for supplementary rank/visibility analyses.
d$z_perceived_expertise <- z(d$perceived_expertise)

agg <- aggregate_evaluator(d)
agg$condition <- factor(agg$condition, levels = c("Competition", "Cooperation"))
self_keep <- p[, c("participant_id", "knowledge_t2", "knowledge_t3", "subjective_knowledge_t3",
                   "z_knowledge_t2", "z_knowledge_t3", "z_subjective_t3", "self_overcredit_t3"), drop = FALSE]
names(self_keep)[1] <- "evaluator_id"
agg <- merge(agg, self_keep, by = "evaluator_id", all.x = TRUE, sort = FALSE)

qc <- data.frame(
  check = c(
    "Participant rows", "Unique participants", "Unique debates (participant table)",
    "Competition participants", "Cooperation participants", "Participants with debate coding",
    "Participants without debate coding", "Ordered canonical dyads", "Unique dyad evaluators",
    "Unique dyad debates", "Competition dyads", "Cooperation dyads",
    "Missing perceived expertise dyads", "Missing benevolence dyads", "Missing argument-evaluation dyads",
    "H1 positive-gain sensitivity thresholds", "Primary bootstrap repetitions",
    "Supplementary bootstrap repetitions", "Run supplementary mediations", "Script version"
  ),
  value = c(
    nrow(p), length(unique(p$participant_id)), length(unique(p$debate_id)),
    sum(p$condition == "Competition"), sum(p$condition == "Cooperation"),
    sum(p$debate_data_available == 1, na.rm = TRUE), sum(p$debate_data_available == 0, na.rm = TRUE),
    nrow(d), length(unique(d$evaluator_id)), length(unique(d$debate_id)),
    sum(d$condition == "Competition"), sum(d$condition == "Cooperation"),
    sum(is.na(d$perceived_expertise)), sum(is.na(d$perceived_benevolence)),
    sum(is.na(d$mean_argument_evaluation)), paste(H1_GAIN_THRESHOLDS, collapse = "; "),
    BOOT_REPS_PRIMARY, BOOT_REPS_SUPPLEMENTARY, RUN_SUPPLEMENTARY_MEDIATIONS, SCRIPT_VERSION
  ),
  stringsAsFactors = FALSE
)

# 4. H1 — factual-change estimation and positive-gain sensitivity --------------
h1_desc <- bind_fill(
  describe_by_condition(p, "knowledge_t2", "Factual knowledge T2"),
  describe_by_condition(p, "knowledge_t3", "Factual knowledge T3"),
  describe_by_condition(p, "knowledge_change", "T3 minus T2")
)

paired_ok <- complete.cases(p$knowledge_t2, p$knowledge_t3)
paired_t <- t.test(p$knowledge_t3[paired_ok], p$knowledge_t2[paired_ok], paired = TRUE)
paired_w <- suppressWarnings(wilcox.test(p$knowledge_t3[paired_ok], p$knowledge_t2[paired_ok], paired = TRUE, exact = FALSE))
dz <- mean(p$knowledge_change[paired_ok]) / sd(p$knowledge_change[paired_ok])
h1_classic <- data.frame(
  N = sum(paired_ok), mean_T2 = mean(p$knowledge_t2[paired_ok]), SD_T2 = sd(p$knowledge_t2[paired_ok]),
  mean_T3 = mean(p$knowledge_t3[paired_ok]), SD_T3 = sd(p$knowledge_t3[paired_ok]),
  mean_change = mean(p$knowledge_change[paired_ok]),
  paired_t = unname(paired_t$statistic), paired_df = unname(paired_t$parameter), paired_p = paired_t$p.value,
  paired_CI95_low = paired_t$conf.int[1], paired_CI95_high = paired_t$conf.int[2],
  dz = dz, Wilcoxon_p = paired_w$p.value, stringsAsFactors = FALSE
)

h1_change_data <- p[complete.cases(p$knowledge_change, p$debate_id), , drop = FALSE]
h1_change_model <- lm(knowledge_change ~ 1, data = h1_change_data)
h1_cr2 <- cr2_analysis(h1_change_model, h1_change_data, label = "H1 mean T2-to-T3 factual change")
h1_estimate <- cluster_h1_estimate(p$knowledge_change, p$debate_id, ALPHA)
h1_gain_sensitivity <- cluster_gain_sensitivity(
  p$knowledge_change, p$debate_id, H1_GAIN_THRESHOLDS, ALPHA
)

# Secondary: whether the condition itself predicts T2-to-T3 factual change.
h1_condition_data <- p[complete.cases(p$knowledge_change, p$condition, p$debate_id), , drop = FALSE]
h1_condition_model <- lm(knowledge_change ~ condition, data = h1_condition_data)
h1_condition_cr2 <- cr2_analysis(h1_condition_model, h1_condition_data, label = "Secondary: condition effect on factual change")

# 5. H2 — self–other epistemic credit allocation -------------------------------
# H2b primary: magnitude of post-debate self-miscalibration. Signed overcredit is
# retained as a directional secondary test because condition need not shift every
# participant's confidence in the same direction.
h2_self_desc <- bind_fill(
  describe_by_condition(p, "self_calibration_abs_t3", "Absolute standardized self-calibration discrepancy T3"),
  describe_by_condition(p, "self_overcredit_t3", "Signed self-overcredit T3 (z subjective - z objective)")
)

h2_abs_data <- p[complete.cases(p$self_calibration_abs_t3, p$condition, p$debate_id), , drop = FALSE]
h2_abs_model <- lm(self_calibration_abs_t3 ~ condition, data = h2_abs_data)
h2_abs_cr2 <- cr2_analysis(h2_abs_model, h2_abs_data, label = "H2b condition effect on absolute self-miscalibration T3")

h2_self_data <- p[complete.cases(p$self_overcredit_t3, p$condition, p$debate_id), , drop = FALSE]
h2_self_model <- lm(self_overcredit_t3 ~ condition, data = h2_self_data)
h2_self_cr2 <- cr2_analysis(h2_self_model, h2_self_data, label = "Secondary directional test: mean signed self-overcredit T3")

# H2a primary: evaluator-level mean partner under-credit using contemporaneous T3
# objective expertise because partner ratings are collected after the debate.
h2_other_t3_data <- agg[complete.cases(agg$mean_partner_undercredit_t3, agg$condition, agg$debate_id), , drop = FALSE]
h2_other_t3_model <- lm(mean_partner_undercredit_t3 ~ condition, data = h2_other_t3_data)
h2_other_t3_cr2 <- cr2_analysis(h2_other_t3_model, h2_other_t3_data, label = "H2a partner epistemic under-credit T3")

# Rank-based metric robustness.
h2_other_pct_data <- agg[complete.cases(agg$mean_partner_undercredit_pct_t3, agg$condition, agg$debate_id), , drop = FALSE]
h2_other_pct_model <- lm(mean_partner_undercredit_pct_t3 ~ condition, data = h2_other_pct_data)
h2_other_pct_cr2 <- cr2_analysis(h2_other_pct_model, h2_other_pct_data, label = "H2a robustness: percentile-rank partner under-credit T3")

# Temporal sensitivity using partner objective knowledge before debate.
h2_other_t2_data <- agg[complete.cases(agg$mean_partner_undercredit_t2, agg$condition, agg$debate_id), , drop = FALSE]
h2_other_t2_model <- lm(mean_partner_undercredit_t2 ~ condition, data = h2_other_t2_data)
h2_other_t2_cr2 <- cr2_analysis(h2_other_t2_model, h2_other_t2_data, label = "Sensitivity: partner under-credit using T2 objective anchor")

h2_other_desc <- bind_fill(
  describe_by_condition(h2_other_t3_data, "mean_partner_undercredit_t3", "Mean partner under-credit T3"),
  describe_by_condition(h2_other_pct_data, "mean_partner_undercredit_pct_t3", "Mean percentile-rank partner under-credit T3"),
  describe_by_condition(h2_other_t2_data, "mean_partner_undercredit_t2", "Mean partner under-credit T2-anchor")
)

# Dyad-level sensitivity for H2a.
h2_dyad_data <- d[complete.cases(d$partner_undercredit_t3, d$condition, d$debate_id), , drop = FALSE]
h2_dyad_model <- lm(partner_undercredit_t3 ~ condition, data = h2_dyad_data)
h2_dyad_cr2 <- cr2_analysis(h2_dyad_model, h2_dyad_data, label = "Sensitivity: dyad-level partner under-credit T3")

# Covariate robustness using only pre-existing/contextual dyad variables.
h2_dyad_adj_data <- d[complete.cases(d$partner_undercredit_t3, d$condition, d$familiarity, d$group_size, d$debate_id), , drop = FALSE]
h2_dyad_adj_model <- lm(partner_undercredit_t3 ~ condition + familiarity + group_size, data = h2_dyad_adj_data)
h2_dyad_adj_cr2 <- cr2_analysis(h2_dyad_adj_model, h2_dyad_adj_data, label = "Sensitivity: dyad under-credit adjusted for familiarity and group size")

# Secondary theory-guided subset: partner objectively more knowledgeable at T3.
more_exp <- d[complete.cases(d$partner_undercredit_t3, d$evaluatee_knowledge_t3,
                             d$evaluator_knowledge_t3, d$condition, d$debate_id) &
                d$evaluatee_knowledge_t3 > d$evaluator_knowledge_t3, , drop = FALSE]
more_exp_agg <- if (nrow(more_exp)) aggregate_evaluator(more_exp) else data.frame()
if (nrow(more_exp_agg)) {
  more_exp_agg$condition <- factor(more_exp_agg$condition, levels = c("Competition", "Cooperation"))
  h2_more_model <- lm(mean_partner_undercredit_t3 ~ condition, data = more_exp_agg)
  h2_more_cr2 <- cr2_analysis(h2_more_model, more_exp_agg, label = "Secondary: under-credit when partner is objectively more knowledgeable at T3")
} else {
  h2_more_cr2 <- NULL
}

# Multiplicity sensitivity across the two H2 headline components: other
# under-credit and absolute self-miscalibration.
h2_component_rows <- bind_fill(
  make_model_row(h2_other_t3_cr2, condition_term, "H2a Other under-credit", "Main theory-guided"),
  make_model_row(h2_abs_cr2, condition_term, "H2b Absolute self-miscalibration", "Main theory-guided")
)
if (nrow(h2_component_rows) && "p_Satt" %in% names(h2_component_rows)) {
  h2_component_rows$q_BH_H2_components <- p.adjust(h2_component_rows$p_Satt, method = "BH")
}

# 6. H3 — expertise-dependent self-calibration -------------------------------
# Primary contemporaneous post-debate model.
h3_data <- p[complete.cases(p$z_subjective_t3, p$z_knowledge_t3, p$condition, p$debate_id), , drop = FALSE]
h3_model <- lm(z_subjective_t3 ~ z_knowledge_t3 * condition, data = h3_data)
h3_cr2 <- cr2_analysis(h3_model, h3_data, label = "H3 objective expertise × condition predicting subjective expertise T3")

# T3 simple slopes use the same full-sample z metrics.
h3_simple <- list()
for (g in levels(p$condition)) {
  dg <- h3_data[h3_data$condition == g, , drop = FALSE]
  mg <- lm(z_subjective_t3 ~ z_knowledge_t3, data = dg)
  og <- cr2_analysis(mg, dg, label = paste0("H3 T3 simple slope — ", g))
  tmp <- extract_term(og, "z_knowledge_t3")
  tmp$condition_group <- g
  h3_simple[[g]] <- tmp
}
h3_simple <- do.call(rbind, h3_simple)
rownames(h3_simple) <- NULL

# Pre-debate benchmark: the analogous T2 relationship. This does not replace T3;
# it documents the pre-debate state against which post-debate interpretation is made.
h3_t2_data <- p[complete.cases(p$z_subjective_t2, p$z_knowledge_t2, p$condition, p$debate_id), , drop = FALSE]
h3_t2_model <- lm(z_subjective_t2 ~ z_knowledge_t2 * condition, data = h3_t2_data)
h3_t2_cr2 <- cr2_analysis(h3_t2_model, h3_t2_data, label = "H3 sensitivity: objective expertise × condition at T2")

# Longitudinal slope-change sensitivity. z-scores are calculated separately at
# each occasion before stacking. Clustering by debate contains both repeated
# observations from every participant and all participants sharing a debate.
h3_long <- rbind(
  data.frame(participant_id = p$participant_id, debate_id = p$debate_id, condition = p$condition,
             time = "T2", z_objective = p$z_knowledge_t2, z_subjective = p$z_subjective_t2),
  data.frame(participant_id = p$participant_id, debate_id = p$debate_id, condition = p$condition,
             time = "T3", z_objective = p$z_knowledge_t3, z_subjective = p$z_subjective_t3)
)
h3_long$condition <- factor(h3_long$condition, levels = c("Competition", "Cooperation"))
h3_long$time <- factor(h3_long$time, levels = c("T2", "T3"))
h3_long <- h3_long[complete.cases(h3_long[, c("z_objective", "z_subjective", "condition", "time", "debate_id")]), , drop = FALSE]
h3_long_model <- lm(z_subjective ~ z_objective * condition * time, data = h3_long)
h3_long_cr2 <- cr2_analysis(h3_long_model, h3_long, label = "H3 sensitivity: objective expertise × condition × time")

# Strong longitudinal calibration test: T3 absolute discrepancy adjusted for T2.
h3_abs_change_data <- p[complete.cases(p$self_calibration_abs_t3, p$self_calibration_abs_t2,
                                       p$condition, p$debate_id), , drop = FALSE]
h3_abs_change_model <- lm(self_calibration_abs_t3 ~ self_calibration_abs_t2 + condition, data = h3_abs_change_data)
h3_abs_change_cr2 <- cr2_analysis(h3_abs_change_model, h3_abs_change_data,
                                  label = "H3 longitudinal sensitivity: T3 absolute calibration controlling T2")

# Descriptive correlations for transparent interpretation of calibration slopes.
h3_corr <- bind_fill(
  data.frame(time = "T2", condition = "Competition", N = sum(p$condition == "Competition"),
             pearson_r = cor(p$knowledge_t2[p$condition == "Competition"], p$subjective_knowledge_t2[p$condition == "Competition"], use = "complete.obs"),
             spearman_rho = cor(p$knowledge_t2[p$condition == "Competition"], p$subjective_knowledge_t2[p$condition == "Competition"], method = "spearman", use = "complete.obs")),
  data.frame(time = "T2", condition = "Cooperation", N = sum(p$condition == "Cooperation"),
             pearson_r = cor(p$knowledge_t2[p$condition == "Cooperation"], p$subjective_knowledge_t2[p$condition == "Cooperation"], use = "complete.obs"),
             spearman_rho = cor(p$knowledge_t2[p$condition == "Cooperation"], p$subjective_knowledge_t2[p$condition == "Cooperation"], method = "spearman", use = "complete.obs")),
  data.frame(time = "T3", condition = "Competition", N = sum(p$condition == "Competition"),
             pearson_r = cor(p$knowledge_t3[p$condition == "Competition"], p$subjective_knowledge_t3[p$condition == "Competition"], use = "complete.obs"),
             spearman_rho = cor(p$knowledge_t3[p$condition == "Competition"], p$subjective_knowledge_t3[p$condition == "Competition"], method = "spearman", use = "complete.obs")),
  data.frame(time = "T3", condition = "Cooperation", N = sum(p$condition == "Cooperation"),
             pearson_r = cor(p$knowledge_t3[p$condition == "Cooperation"], p$subjective_knowledge_t3[p$condition == "Cooperation"], use = "complete.obs"),
             spearman_rho = cor(p$knowledge_t3[p$condition == "Cooperation"], p$subjective_knowledge_t3[p$condition == "Cooperation"], method = "spearman", use = "complete.obs"))
)

# 7. Secondary — partner credit and actual-expertise discrimination ------------
# Additive discrimination model: does perceived expertise track actual T3 expertise?
sec_discr_data <- d[complete.cases(d$perceived_expertise, d$evaluatee_zknowledge_t3,
                                   d$condition, d$debate_id), , drop = FALSE]
sec_discr_model <- lm(perceived_expertise ~ evaluatee_zknowledge_t3 + condition, data = sec_discr_data)
sec_discr_cr2 <- cr2_analysis(sec_discr_model, sec_discr_data,
                              label = "Secondary: actual partner expertise discrimination T3")

# Interaction model: does discrimination itself differ by condition?
sec_discr_int_model <- lm(perceived_expertise ~ evaluatee_zknowledge_t3 * condition, data = sec_discr_data)
sec_discr_int_cr2 <- cr2_analysis(sec_discr_int_model, sec_discr_data,
                                  label = "Secondary: actual partner expertise × condition discrimination T3")
sec_discr_simple <- list()
for (g in levels(d$condition)) {
  ddg <- sec_discr_data[sec_discr_data$condition == g, , drop = FALSE]
  mmg <- lm(perceived_expertise ~ evaluatee_zknowledge_t3, data = ddg)
  oog <- cr2_analysis(mmg, ddg, label = paste0("Secondary partner-expertise simple slope — ", g))
  rr <- extract_term(oog, "evaluatee_zknowledge_t3")
  rr$condition_group <- g
  sec_discr_simple[[g]] <- rr
}
sec_discr_simple <- do.call(rbind, sec_discr_simple)
rownames(sec_discr_simple) <- NULL

# T2 temporal sensitivity.
sec_discr_t2_data <- d[complete.cases(d$perceived_expertise, d$evaluatee_zknowledge_t2,
                                      d$condition, d$debate_id), , drop = FALSE]
sec_discr_t2_model <- lm(perceived_expertise ~ evaluatee_zknowledge_t2 + condition, data = sec_discr_t2_data)
sec_discr_t2_cr2 <- cr2_analysis(sec_discr_t2_model, sec_discr_t2_data,
                                 label = "Sensitivity: actual partner expertise discrimination T2 anchor")

# 7b. Secondary theory-guided — does evaluator expertise improve recognition? ---
# This analysis directly tests the theoretical question motivated by the expertise
# literature: are more knowledgeable evaluators more sensitive to differences in
# their partners' actual expertise? The crucial coefficient is the interaction
# actual partner expertise x evaluator expertise, not the evaluator-expertise
# main effect. A positive interaction means that the slope linking actual partner
# expertise to perceived expertise becomes steeper as the evaluator knows more.

sec_evalexpert_data <- d[complete.cases(d$perceived_expertise, d$evaluatee_zknowledge_t3,
                                        d$evaluator_zknowledge_t3, d$condition, d$debate_id), ,
                         drop = FALSE]
sec_evalexpert_model <- lm(
  perceived_expertise ~ evaluatee_zknowledge_t3 * evaluator_zknowledge_t3 + condition,
  data = sec_evalexpert_data
)
sec_evalexpert_cr2 <- cr2_analysis(
  sec_evalexpert_model, sec_evalexpert_data,
  label = "Secondary: evaluator expertise moderates actual-partner-expertise discrimination T3"
)

# Simple slopes of actual partner expertise at low (-1 SD), mean (0), and high
# (+1 SD) evaluator expertise. Recentring gives the focal slope directly and
# preserves CR2/Satterthwaite inference.
sec_evalexpert_slopes <- list()
for (v in c(-1, 0, 1)) {
  ddv <- sec_evalexpert_data
  ddv$evaluator_expertise_centered <- ddv$evaluator_zknowledge_t3 - v
  mmv <- lm(
    perceived_expertise ~ evaluatee_zknowledge_t3 * evaluator_expertise_centered + condition,
    data = ddv
  )
  oov <- cr2_analysis(
    mmv, ddv,
    label = paste0("Evaluator-expertise discrimination simple slope at evaluator z = ", v)
  )
  rrv <- extract_term(oov, "evaluatee_zknowledge_t3")
  rrv$evaluator_expertise_z <- v
  rrv$condition_group <- "Adjusted across conditions"
  sec_evalexpert_slopes[[paste0("overall_", v)]] <- rrv
}
sec_evalexpert_slopes <- do.call(bind_fill, sec_evalexpert_slopes)

# Pre-debate evaluator expertise / partner expertise sensitivity.
sec_evalexpert_t2_data <- d[complete.cases(d$perceived_expertise, d$evaluatee_zknowledge_t2,
                                           d$evaluator_zknowledge_t2, d$condition, d$debate_id), ,
                            drop = FALSE]
sec_evalexpert_t2_model <- lm(
  perceived_expertise ~ evaluatee_zknowledge_t2 * evaluator_zknowledge_t2 + condition,
  data = sec_evalexpert_t2_data
)
sec_evalexpert_t2_cr2 <- cr2_analysis(
  sec_evalexpert_t2_model, sec_evalexpert_t2_data,
  label = "Sensitivity: evaluator expertise moderates partner-expertise discrimination T2 anchor"
)

# Complementary quality metric: does evaluator expertise predict smaller absolute
# discrepancy between actual and perceived partner standing? The evaluator-level
# model gives each evaluator equal weight. Negative expertise coefficients mean
# better accuracy among more knowledgeable evaluators.
sec_evalexpert_accuracy_data <- agg[
  complete.cases(agg$mean_partner_calibration_abs_t3, agg$z_knowledge_t3,
                 agg$condition, agg$debate_id), , drop = FALSE
]
sec_evalexpert_accuracy_model <- lm(
  mean_partner_calibration_abs_t3 ~ z_knowledge_t3 + condition,
  data = sec_evalexpert_accuracy_data
)
sec_evalexpert_accuracy_cr2 <- cr2_analysis(
  sec_evalexpert_accuracy_model, sec_evalexpert_accuracy_data,
  label = "Secondary: evaluator expertise predicts mean absolute partner-evaluation error T3"
)

# Rank-based robustness for the absolute-error result.
sec_evalexpert_accuracy_pct_data <- agg[
  complete.cases(agg$mean_partner_calibration_abs_pct_t3, agg$z_knowledge_t3,
                 agg$condition, agg$debate_id), , drop = FALSE
]
sec_evalexpert_accuracy_pct_model <- lm(
  mean_partner_calibration_abs_pct_t3 ~ z_knowledge_t3 + condition,
  data = sec_evalexpert_accuracy_pct_data
)
sec_evalexpert_accuracy_pct_cr2 <- cr2_analysis(
  sec_evalexpert_accuracy_pct_model, sec_evalexpert_accuracy_pct_data,
  label = "Robustness: evaluator expertise predicts rank-based absolute partner-evaluation error T3"
)

# Temporal sensitivity using objective knowledge entering the debate.
sec_evalexpert_accuracy_t2_data <- agg[
  complete.cases(agg$mean_partner_calibration_abs_t2, agg$z_knowledge_t2,
                 agg$condition, agg$debate_id), , drop = FALSE
]
sec_evalexpert_accuracy_t2_model <- lm(
  mean_partner_calibration_abs_t2 ~ z_knowledge_t2 + condition,
  data = sec_evalexpert_accuracy_t2_data
)
sec_evalexpert_accuracy_t2_cr2 <- cr2_analysis(
  sec_evalexpert_accuracy_t2_model, sec_evalexpert_accuracy_t2_data,
  label = "Sensitivity: evaluator expertise predicts absolute partner-evaluation error T2 anchor"
)

# Condition effects on the three post-debate partner-evaluation outcomes.
secondary_credit_models <- list()
for (outcome in c("perceived_expertise", "perceived_benevolence", "mean_argument_evaluation")) {
  dd <- d[complete.cases(d[[outcome]], d$condition, d$debate_id), , drop = FALSE]
  mm <- lm(reformulate("condition", response = outcome), data = dd)
  oo <- cr2_analysis(mm, dd, label = paste0("Secondary condition effect: ", outcome))
  rr <- make_model_row(oo, condition_term, paste0("Condition -> ", outcome), "Secondary theory-guided")
  secondary_credit_models[[outcome]] <- rr
}
secondary_credit <- do.call(rbind, secondary_credit_models)
rownames(secondary_credit) <- NULL
if (nrow(secondary_credit) && "p_Satt" %in% names(secondary_credit)) {
  secondary_credit$q_BH_three_credit_outcomes <- p.adjust(secondary_credit$p_Satt, method = "BH")
}

# 8. Exploratory — debate behavior ---------------------------------------------
debate_models <- list()
# Attack rate: theory-consistent behavioral validation.
attack_data <- p[complete.cases(p$attack_rate, p$condition, p$debate_id), , drop = FALSE]
attack_model <- lm(attack_rate ~ condition, data = attack_data)
attack_cr2 <- cr2_analysis(attack_model, attack_data, label = "Exploratory/supporting: attack rate by condition")
debate_models[["attack"]] <- make_model_row(attack_cr2, condition_term,
                                             "Attack rate: Cooperation vs Competition", "Exploratory/supporting")

# Supplementary behavioral indicators.
for (spec in list(c("question_rate", "Question rate"), c("doubt_rate", "Doubt/humility rate"),
                  c("polarized_prop", "Polarized argument proportion"))) {
  v <- spec[1]; lab <- spec[2]
  dd <- p[complete.cases(p[[v]], p$condition, p$debate_id), , drop = FALSE]
  mm <- lm(reformulate("condition", response = v), data = dd)
  oo <- cr2_analysis(mm, dd, label = paste0("Supplement: ", lab))
  debate_models[[v]] <- make_model_row(oo, condition_term, paste0(lab, ": Cooperation vs Competition"), "Supplementary exploratory")
}
exploratory_debate <- do.call(rbind, debate_models)
rownames(exploratory_debate) <- NULL
# BH only for the three explicitly supplementary behavioral indicators; the
# theory-consistent attack result is kept separate.
if ("p_Satt" %in% names(exploratory_debate)) {
  ix <- exploratory_debate$status == "Supplementary exploratory"
  exploratory_debate$q_BH_supplement_behavior <- NA_real_
  exploratory_debate$q_BH_supplement_behavior[ix] <- p.adjust(exploratory_debate$p_Satt[ix], method = "BH")
}

# 8b. Supplement — amount of participation ------------------------------------
# These models test whether condition effects concern interaction regulation rather
# than simply how much participants speak.
quantity_rows <- list()
for (spec in list(c("debate_sequence_count", "Speech-sequence count"),
                  c("debate_word_count", "Word count"),
                  c("debate_group_word_share", "Group word share"))) {
  v <- spec[1]; lab <- spec[2]
  dd <- p[complete.cases(p[[v]], p$condition, p$debate_id), , drop = FALSE]
  mm <- lm(reformulate("condition", response = v), data = dd)
  oo <- cr2_analysis(mm, dd, label = paste0("Supplement quantity: ", lab))
  quantity_rows[[v]] <- make_model_row(oo, condition_term,
                                        paste0(lab, ": Cooperation vs Competition"),
                                        "Supplementary descriptive")
}
supplement_quantity <- do.call(rbind, quantity_rows)
rownames(supplement_quantity) <- NULL
if (nrow(supplement_quantity) && "p_Satt" %in% names(supplement_quantity)) {
  supplement_quantity$q_BH_quantity <- p.adjust(supplement_quantity$p_Satt, method = "BH")
}

# 9. Supplement — conversational visibility as expertise cue -------------------
vis_rows <- list()
for (v in c("evaluatee_debate_word_count", "evaluatee_debate_group_word_share")) {
  dd <- d[complete.cases(d$perceived_expertise, d[[v]], d$condition, d$debate_id), , drop = FALSE]
  dd$z_visibility <- z(dd[[v]])
  mm <- lm(perceived_expertise ~ z_visibility * condition, data = dd)
  oo <- cr2_analysis(mm, dd, label = paste0("Supplement visibility: ", v))
  rr <- oo$tests
  rr$visibility_measure <- v
  vis_rows[[v]] <- rr
}
supplement_visibility <- bind_fill(vis_rows[[1]], vis_rows[[2]])

# 10. Supplement — epistemic rank reversal ------------------------------------
# Epistemic rank reversal: among dyads where the partner has higher objective T3
# knowledge, compute for each evaluator the share in which standardized self-rated
# knowledge is >= standardized perceived partner expertise. This comparison is
# scale-dependent and is therefore strictly supplementary.
rank_d <- d[complete.cases(d$evaluator_knowledge_t3, d$evaluatee_knowledge_t3,
                           d$evaluator_subjective_t3, d$perceived_expertise,
                           d$condition, d$debate_id) &
              d$evaluatee_knowledge_t3 > d$evaluator_knowledge_t3, , drop = FALSE]
if (nrow(rank_d) > 0L) {
  # Use the participant-level self-subjective standardization and the dyad-level
  # perceived-expertise standardization already constructed above.
  self_z_map <- setNames(p$z_subjective_t3, p$participant_id)
  rank_d$evaluator_zsubjective_t3 <- unname(self_z_map[rank_d$evaluator_id])
  rank_d$rank_reversal <- as.numeric(rank_d$evaluator_zsubjective_t3 >= rank_d$z_perceived_expertise)
  rid <- unique(rank_d$evaluator_id)
  rank_agg <- do.call(rbind, lapply(rid, function(id) {
    x <- rank_d[rank_d$evaluator_id == id, , drop = FALSE]
    data.frame(evaluator_id = id, debate_id = x$debate_id[1], condition = x$condition[1],
               n_more_expert_partner_dyads = nrow(x), rank_reversal_rate = mean(x$rank_reversal),
               stringsAsFactors = FALSE)
  }))
  rank_agg$condition <- factor(rank_agg$condition, levels = c("Competition", "Cooperation"))
  rank_model <- lm(rank_reversal_rate ~ condition, data = rank_agg)
  rank_cr2 <- cr2_analysis(rank_model, rank_agg, label = "Supplement: epistemic rank reversal rate")
  rank_result <- make_model_row(rank_cr2, condition_term,
                                "Epistemic rank reversal rate", "Supplementary exploratory / scale-sensitive")
  rank_desc <- describe_by_condition(rank_agg, "rank_reversal_rate", "Epistemic rank reversal rate")
} else {
  rank_result <- data.frame()
  rank_desc <- data.frame()
}

supplement_rank_reversal <- rank_result

# 11. Compact manuscript-facing synthesis -------------------------------------
h1_key <- h1_estimate
h1_key$analysis <- "H1 primary: CR2 factual-change estimate and one-sided upper bound"
h1_key$status <- "Main theory-guided"

key_results <- bind_fill(
  h1_key,
  make_model_row(h1_cr2, "(Intercept)", "H1: mean factual change T3-T2", "Descriptive/inferential context"),
  make_model_row(h2_other_t3_cr2, condition_term, "H2a: partner under-credit T3", "Main theory-guided"),
  make_model_row(h2_abs_cr2, condition_term, "H2b: absolute self-miscalibration T3", "Main theory-guided"),
  make_model_row(h2_self_cr2, condition_term, "H2b directional: signed self-overcredit T3", "Secondary directional test"),
  make_model_row(h3_cr2, "z_knowledge_t3:conditionCooperation", "H3: objective expertise × condition at T3", "Main theory-guided"),
  make_model_row(h3_abs_change_cr2, condition_term, "H3 longitudinal: T3 calibration controlling T2", "Theory-guided sensitivity"),
  make_model_row(sec_discr_cr2, "evaluatee_zknowledge_t3", "Secondary: actual partner expertise -> perceived expertise", "Secondary theory-guided"),
  make_model_row(sec_evalexpert_cr2, "evaluatee_zknowledge_t3:evaluator_zknowledge_t3",
                 "Secondary: evaluator expertise improves partner-expertise discrimination",
                 "Secondary theory-guided"),
  make_model_row(sec_evalexpert_accuracy_cr2, "z_knowledge_t3",
                 "Secondary: evaluator expertise -> absolute partner-evaluation error",
                 "Secondary theory-guided complementary"),
  exploratory_debate[exploratory_debate$analysis == "Attack rate: Cooperation vs Competition", , drop = FALSE]
)

# 12. Write core/checkpoint outputs BEFORE any bootstrap ------------------------
# This workbook is deliberately saved before the potentially slow mediation
# bootstrap. It lets users inspect H1-H3 and every non-bootstrap result even if a
# later FINAL bootstrap is interrupted.
core_results_sheets <- list(
  QC = qc,
  H1_Descriptives = h1_desc,
  H1_Classical = h1_classic,
  H1_CR2 = h1_cr2$tests,
  H1_Estimate = h1_estimate,
  H1_GainSensitivity = h1_gain_sensitivity,
  H1_Condition = h1_condition_cr2$tests,
  H2_Self_Desc = h2_self_desc,
  H2_Self = bind_fill(h2_abs_cr2$tests, h2_self_cr2$tests),
  H2_Multiplicity = h2_component_rows,
  H2_Other_Desc = h2_other_desc,
  H2_Other = bind_fill(h2_other_t3_cr2$tests, h2_other_pct_cr2$tests, h2_other_t2_cr2$tests,
                       h2_dyad_cr2$tests, h2_dyad_adj_cr2$tests,
                       if (!is.null(h2_more_cr2)) h2_more_cr2$tests else NULL),
  H3_T3_Expertise = h3_cr2$tests,
  H3_T3_SimpleSlopes = h3_simple,
  H3_T2_Benchmark = h3_t2_cr2$tests,
  H3_Longitudinal = h3_long_cr2$tests,
  H3_CalibLongitudinal = h3_abs_change_cr2$tests,
  H3_Correlations = h3_corr,
  Secondary_Discrimination = bind_fill(sec_discr_cr2$tests, sec_discr_int_cr2$tests, sec_discr_t2_cr2$tests),
  Secondary_DiscrSlopes = sec_discr_simple,
  EvalExpert_Discrimination = bind_fill(sec_evalexpert_cr2$tests, sec_evalexpert_t2_cr2$tests),
  EvalExpert_Slopes = sec_evalexpert_slopes,
  EvalExpert_Accuracy = bind_fill(sec_evalexpert_accuracy_cr2$tests,
                                  sec_evalexpert_accuracy_pct_cr2$tests,
                                  sec_evalexpert_accuracy_t2_cr2$tests),
  Secondary_Credit = secondary_credit,
  Exploratory_Debate = exploratory_debate,
  Supplement_Quantity = supplement_quantity,
  Supplement_Visibility = supplement_visibility,
  Supplement_RankReversal = supplement_rank_reversal,
  Supplement_RankDesc = rank_desc,
  Key_Results = key_results
)
write_workbook(CORE_RESULTS_FILE, core_results_sheets)
cat("\nCore results written BEFORE bootstrap:\n  ", CORE_RESULTS_FILE, "\n", sep = "")

# 12b. Exploratory — statistical indirect paths through benevolence ------------
# Primary manuscript-facing path: condition -> benevolence -> partner under-credit.
# The other two paths are supplementary and can be enabled explicitly.
exploratory_mediation <- data.frame()
agg_med <- agg

if (RUN_PRIMARY_MEDIATION) {
  med_under <- cluster_boot_indirect(
    agg_med, mediator = "mean_perceived_benevolence", outcome = "mean_partner_undercredit_t3",
    reps = BOOT_REPS_PRIMARY, seed = BOOT_SEED + 2L,
    label = "Condition -> benevolence -> partner under-credit T3"
  )
  exploratory_mediation <- bind_fill(exploratory_mediation, med_under)
}

if (RUN_SUPPLEMENTARY_MEDIATIONS) {
  med_exp <- cluster_boot_indirect(
    agg_med, mediator = "mean_perceived_benevolence", outcome = "mean_perceived_expertise",
    reps = BOOT_REPS_SUPPLEMENTARY, seed = BOOT_SEED + 1L,
    label = "Condition -> benevolence -> perceived expertise"
  )
  med_arg <- cluster_boot_indirect(
    agg_med, mediator = "mean_perceived_benevolence", outcome = "mean_argument_evaluation",
    reps = BOOT_REPS_SUPPLEMENTARY, seed = BOOT_SEED + 3L,
    label = "Condition -> benevolence -> argument evaluation"
  )
  exploratory_mediation <- bind_fill(exploratory_mediation, med_exp, med_arg)
}

# 13. Write run-specific results ------------------------------------------------
results_sheets <- list(
  QC = qc,
  H1_Descriptives = h1_desc,
  H1_Classical = h1_classic,
  H1_CR2 = h1_cr2$tests,
  H1_Estimate = h1_estimate,
  H1_GainSensitivity = h1_gain_sensitivity,
  H1_Condition = h1_condition_cr2$tests,
  H2_Self_Desc = h2_self_desc,
  H2_Self = bind_fill(h2_abs_cr2$tests, h2_self_cr2$tests),
  H2_Multiplicity = h2_component_rows,
  H2_Other_Desc = h2_other_desc,
  H2_Other = bind_fill(h2_other_t3_cr2$tests, h2_other_pct_cr2$tests, h2_other_t2_cr2$tests,
                       h2_dyad_cr2$tests, h2_dyad_adj_cr2$tests,
                       if (!is.null(h2_more_cr2)) h2_more_cr2$tests else NULL),
  H3_T3_Expertise = h3_cr2$tests,
  H3_T3_SimpleSlopes = h3_simple,
  H3_T2_Benchmark = h3_t2_cr2$tests,
  H3_Longitudinal = h3_long_cr2$tests,
  H3_CalibLongitudinal = h3_abs_change_cr2$tests,
  H3_Correlations = h3_corr,
  Secondary_Discrimination = bind_fill(sec_discr_cr2$tests, sec_discr_int_cr2$tests, sec_discr_t2_cr2$tests),
  Secondary_DiscrSlopes = sec_discr_simple,
  EvalExpert_Discrimination = bind_fill(sec_evalexpert_cr2$tests, sec_evalexpert_t2_cr2$tests),
  EvalExpert_Slopes = sec_evalexpert_slopes,
  EvalExpert_Accuracy = bind_fill(sec_evalexpert_accuracy_cr2$tests,
                                  sec_evalexpert_accuracy_pct_cr2$tests,
                                  sec_evalexpert_accuracy_t2_cr2$tests),
  Secondary_Credit = secondary_credit,
  Exploratory_Mediation = exploratory_mediation,
  Exploratory_Debate = exploratory_debate,
  Supplement_Quantity = supplement_quantity,
  Supplement_Visibility = supplement_visibility,
  Supplement_RankReversal = supplement_rank_reversal,
  Supplement_RankDesc = rank_desc,
  Key_Results = key_results
)

write_workbook(RESULTS_FILE, results_sheets)
capture.output(sessionInfo(), file = SESSION_FILE)

cat("\nDone.\n")
cat("Core/checkpoint workbook:", CORE_RESULTS_FILE, "\n")
cat("Run-specific results workbook:", RESULTS_FILE, "\n")
cat("Session information:", SESSION_FILE, "\n")
if (!RUN_SUPPLEMENTARY_MEDIATIONS) {
  cat("Supplementary mediation paths were skipped. Set RUN_SUPPLEMENTARY_MEDIATIONS <- TRUE to reproduce them.\n")
}
cat("The retained exploratory indirect path uses 500 debate-cluster bootstrap resamples in both CHECK and FINAL modes.\n")
